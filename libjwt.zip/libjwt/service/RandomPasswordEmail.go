package service

import (
	"net/http"
	"net/url"
	"os"

	"github.com/MACMREPO/libdb/clientmaster"
	"github.com/MACMREPO/libjwt/model"
)

func PasswordEmail(user interface{}) error {
	data := user.(clientmaster.JwtAuthMaster)

	var objSendMail model.InfobipMailModel
	objSendMail.From = ""
	objSendMail.To = data.Email

	objSendMail.Subject = "Account Password for Nuuu.com"
	objSendMail.Text = "Random Password"
	objSendMail.Html = "<p>Dear <b>" + data.Name + "</b>,</p>" +
		"<p>Greetings from Nuuu!</p>" +
		"<p>You have successfully completed your eKYC process & your login details are as follows.</p>" +
		"<p>UCC : <b>" + data.ClientID + "</b></p>" +
		"<p>Username : <b>" + data.MobileNo + "</b></p>" +
		"<p>Password : <b>" + data.Password + "</b></p>" +
		"<p><b>Use this credentials to login into your account.</b></p>" +
		"<p>Happy Investing!</p>" +
		"<p>Yours Sincerely,</p>" +
		"<p>Nuuu</p>"
	objSendMail.BulkId = ""
	objSendMail.IntermediateReport = ""
	objSendMail.NotifyContentType = ""
	sStage := os.Getenv("STAGE")
	sAncillarypath := ""
	if sStage == "" {
		sAncillarypath = "https://www.nuuu.com"
		// sAncillarypath = "http://localhost:28008"
	} else {
		sAncillarypath = "http://netancillary-" + sStage + "-service:8085"
	}

	Url := sAncillarypath + "/netancillary/InfobipSendMail"
	dataUrl := url.Values{}
	dataUrl.Add("to", objSendMail.To)
	dataUrl.Add("subject", objSendMail.Subject)
	dataUrl.Add("text", objSendMail.Text)
	dataUrl.Add("html", objSendMail.Html)
	_, err := http.PostForm(Url, dataUrl)

	if err != nil {
		Zerologs.Error().Msgf("Error sending mail: %v", err)
	}
	return nil
}
