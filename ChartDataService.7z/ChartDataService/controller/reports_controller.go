package controller

import(
	"chartdataservice/service"
	"github.com/gin-gonic/gin"

)



func ReportsApi(router *gin.Engine) {
	api := router.Group("/reports")
	api.POST("generateTimeframeReport", service.GenerateReport)
	api.POST("generateEODReport", service.GenerateReportEOD)
	api.POST("syncDirectory", service.SyncDirectory)

}