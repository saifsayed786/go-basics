package model

import "encoding/json"

type RedisFriendModel struct {
	Name      string `json:"Name"`
	Guid      string `json:"Guid"`
	UserImage string `json:"UserImage"`
}

func (i RedisFriendModel) MarshalBinary() ([]byte, error) {
	return json.Marshal(i)
}

func (i RedisFriendModel) ToString() string {
	buff, err := json.Marshal(i)
	if err != nil {
		return ""
	}
	return string(buff)
}
