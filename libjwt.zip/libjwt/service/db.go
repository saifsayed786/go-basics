package service

import (
	"errors"

	"github.com/MACMREPO/libdb/clientmaster"
	"github.com/MACMREPO/libjwt/helper"
)

func getJwtAuthMasterDB(searchBy int, inputParam string) (clientmaster.JwtAuthMaster, error) {
	var jwtDbData clientmaster.JwtAuthMaster
	switch searchBy {
	case helper.CLIENT_MOBILE_PARAM:
		err := Db.Client.Where("mobile_no=?", inputParam).First(&jwtDbData).Error
		if err != nil {
			Zerologs.Error().Msg("MobileNo" + ": " + inputParam + " Not Found In clientmaster.JwtAuthMaster " + err.Error())
			return jwtDbData, err
		}
	case helper.CLIENT_EMAIL_PARAM:
		err := Db.Client.Where("email=?", inputParam).First(&jwtDbData).Error
		if err != nil {
			Zerologs.Error().Msg("Email" + ": " + inputParam + " Not Found In clientmaster.JwtAuthMaster " + err.Error())
			return jwtDbData, err
		}
	case helper.CLIENT_ID_PARAM:
		err := Db.Client.Where("client_id=?", inputParam).First(&jwtDbData).Error
		if err != nil {
			Zerologs.Error().Msg("ClientID" + ": " + inputParam + " Not Found In clientmaster.JwtAuthMaster " + err.Error())
			return jwtDbData, err
		}
	case helper.CLIENT_USERGUID:
		err := Db.Client.Where("user_guid=?", inputParam).First(&jwtDbData).Error
		if err != nil {
			Zerologs.Error().Msg("AddMobileHandler():User detalis not found in JwtAuthMaster where user_guid:= " + inputParam + err.Error())
			return jwtDbData, err
		}
	}
	return jwtDbData, nil
}

func deleteJwtAuthMasterDB(condition int, inputParam string) error {
	var JwtUser clientmaster.JwtAuthMaster
	switch condition {
	case helper.CLIENT_MOBILE_PARAM:
		err := Db.Client.Where("mobileNo=?", inputParam).Delete(&JwtUser).Error
		if err != nil {
			Zerologs.Error().Msg("MobileNo" + ": " + inputParam + " Not Found In clientmaster.JwtAuthMaster " + err.Error())
			return err
		}
	case helper.CLIENT_EMAIL_PARAM:
		err := Db.Client.Where("email=?", inputParam).Delete(&JwtUser).Error
		if err != nil {
			Zerologs.Error().Msg("MobileNo" + ": " + inputParam + " Not Found In clientmaster.JwtAuthMaster " + err.Error())
			return err
		}
	case helper.CLIENT_ID_PARAM:
		err := Db.Client.Where("client_id=?", inputParam).Delete(&JwtUser).Error
		if err != nil {
			Zerologs.Error().Msg("client_id" + ": " + inputParam + " Not Found In clientmaster.JwtAuthMaster " + err.Error())
			return err
		}
	}
	return nil
}

func getClientByUserType(UserType int, username, password string) (clientmaster.JwtAuthMaster, error) {
	var clientdbData clientmaster.JwtAuthMaster
	var err error
	switch UserType {
	case helper.CLIENT_MOBILE_PARAM:
		err = Db.Client.Where("mobile_no=? and password=?", username, password).First(&clientdbData).Error
	case helper.CLIENT_EMAIL_PARAM:
		err = Db.Client.Where("email=? and password=?", username, password).First(&clientdbData).Error
	case helper.CLIENT_ID_PARAM:
		err = Db.Client.Where("client_id=? and password=?", username, password).First(&clientdbData).Error
	}
	return clientdbData, err
}

func updateJWTAuthMaster(UserType int, username string, updateValue map[string]any) error {
	switch UserType {
	case helper.CLIENT_MOBILE_PARAM:
		err := Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", username).Updates(updateValue).Error
		return err
	case helper.CLIENT_EMAIL_PARAM:
		err := Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("email=?", username).Updates(updateValue).Error
		return err
	case helper.CLIENT_ID_PARAM:
		err := Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("client_id=?", username).Updates(updateValue).Error
		return err
	}
	return nil

}

func updateJWTAuthMasterModel(UserType int, updateBy string, jwtdbData clientmaster.JwtAuthMaster) error {
	switch UserType {
	case helper.CLIENT_MOBILE_PARAM:
		err := Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", updateBy).Updates(jwtdbData).Error
		return err
	case helper.CLIENT_EMAIL_PARAM:
		err := Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("email=?", updateBy).Updates(jwtdbData).Error
		return err
	case helper.CLIENT_ID_PARAM:
		err := Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("client_id=?", updateBy).Updates(jwtdbData).Error
		return err
	case helper.CLIENT_USERGUID:
		err := Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("user_guid=?", updateBy).Updates(jwtdbData).Error
		return err
	}
	return nil

}
func InsertInTblMobileEmailMapping(MobEmail clientmaster.TblMobileEmailMapping) error {
	err := Db.Client.Create(&MobEmail).Error
	if err != nil {
		Zerologs.Error().Msg("Add_Mobile(): Error in create query for TblMobileEmailMapping for mobileno=" + MobEmail.MobileNo + " and email=" + MobEmail.Email + " and error is " + err.Error())
		return err
	}
	return nil
}

func getTblMobileEmailMapping(searchby int, inputParam string) (clientmaster.TblMobileEmailMapping, error) {
	var MobEmail clientmaster.TblMobileEmailMapping
	switch searchby {
	case helper.CLIENT_MOBILE_PARAM:
		err := Db.Client.Where("mobile_no=?", inputParam).First(&MobEmail).Error
		if err != nil {
			return MobEmail, err
		}
	case helper.CLIENT_EMAIL_PARAM:
		err := Db.Client.Where("email=?", inputParam).First(&MobEmail).Error
		if err != nil {
			return MobEmail, err
		}
	}
	return MobEmail, nil
}

func getEmailAndMobFromEmailMapping(mobile, email string) (clientmaster.TblMobileEmailMapping, error) {
	var EmailMap clientmaster.TblMobileEmailMapping
	err := Db.Client.Where("mobile_no=? AND email=?", mobile, email).First(&EmailMap).Error
	if err != nil {
		return err
	}
	return EmailMap, nil
}
func getMobileGuidMaster(mobile_no string) (clientmaster.MobileGuidMaster, error) {
	var guidData clientmaster.MobileGuidMaster
	err := Db.Client.Where("mobile_no=?", mobile_no).First(&guidData).Error
	if err != nil {
		return guidData, err
	}
	return guidData, nil
}

func findPasswordHistoryLimit(searchBy int, inputParam string) ([]clientmaster.PasswordHistory, error) {
	var passwordhistory []clientmaster.PasswordHistory
	switch searchBy {
	case helper.CLIENT_MOBILE_PARAM:
		Db.Client.Where("mobile_no=?", inputParam).Order("created_at DESC").Limit(3).Find(&passwordhistory)
		if len(passwordhistory) == 0 {
			return nil, errors.New("Password history data not found")
		}
	}
	return nil
}

//CreateQuery
