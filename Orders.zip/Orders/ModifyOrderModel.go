package model

type ModifyOrderModel struct {
	Modtriggerprice      string `json:"modtriggerprice,omitempty"`
	Source               string `json:"source,omitempty"`
	ClientType           string `json:"client_type,omitempty"`
	ClientID             string `json:"client_id,omitempty"`
	ModinstType          string `json:"modinst_type,omitempty"`
	Modproductlist       string `json:"modproductlist,omitempty"`
	UserType             string `json:"user_type,omitempty"`
	TokenID              string `json:"token_id,omitempty"`
	OrdStatus            string `json:"ord_status,omitempty"`
	ModqtyRemng          int64  `json:"modqty_remng,omitempty"`
	Modquantity          string `json:"modquantity,omitempty"`
	ModtradedQty         string `json:"modtraded_qty,omitempty"`
	Modbuysell           string `json:"modbuysell,omitempty"`
	Moddisclosequantity  string `json:" moddisclosequantity,omitempty"`
	ModorderSerialNumber string `json:"modorder_serial_number,omitempty"`
	OfflineFlag          bool   `json:"offline_flag,omitempty"`
	ModOrderType         string `json:"modOrderType ,omitempty"`
	ExchClientID         string `json:"exch_client_id,omitempty"`
	Modsecurityid        string `json:"modsecurityid,omitempty"`
	Modexchange          string `json:"modexchange,omitempty"`
	ModscripnaMe         string `json:"modscripna me,omitempty"`
	UserID               string `json:"user_id,omitempty"`
	ModorderNumber       string `json:"modorder_number,omitempty"`
	Modquantitytype      string `json:"modquantitytype,omitempty"`
	Modprice             string `json:"modprice,omitempty"`
	MarketProflag        string `json:"marketProflag,omitempty"`
	MarketProVal         string `json:"marketProVal,omitempty"`
	ParticipantType      string `json:"ParticipantType,omitempty"`
	Settlor              string `json:"settlor,omitempty"`
	Gtcflag              string `json:"Gtcflag,omitempty"`
	EncashFlag           string `json:"EncashFlag,omitempty"`
	PanID                string `json:"pan_id,omitempty"`
	GTDdate              string `json:"GTDdate,omitempty"`
	Algoid               string `json:"algoid,omitempty"`
	Remarks1             string `json:"remarks1,omitempty"`
	Remarks2             string `json:"remarks2,omitempty"`
}
