package controller

import (
	"fmt"
	"strings"

	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/helper"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/contrib/sessions"
	"github.com/gin-gonic/gin"
)

func ForgotMpinController(c *gin.Context) {
	libhttp.CoreHeader(c)
	session := sessions.Default(c)
	retrievedState := session.Get("state")
	cquery := c.Query("state")
	// fmt.Println("state = " + cquery)
	// fmt.Println("retrievedState = " + retrievedState.(string))
	RetriveState := retrievedState.(string)
	if retrievedState != cquery {
		fmt.Println(retrievedState.(string) + " -- " + cquery)
		// c.AbortWithError(http.StatusUnauthorized, fmt.Errorf("Invalid session state: %s", retrievedState))
		// return
	}

	imgBase64Str := service.CreateCaptcha(RetriveState)
	forgotpasstemp := strings.Replace(string(helper.ForgetPassTemplate), "CAPTCHADATA", imgBase64Str, 1)
	c.Writer.Write([]byte(forgotpasstemp))
	// state = randToken()
	// session := sessions.Default(c)
	// c.Writer.Write(ForgotMpinTemplate)
}

func Forgot_MPin(c *gin.Context) {
	// libhttp.CoreHeader(c)

	// var forgotmpin model.ForgotMPin
	// if err := c.BindJSON(&forgotmpin); err != nil {
	// 	// service.Zerologs.Error().Msg("Forgot_MPin(): Error in c.BindJSON is " + err.Error())
	// 	c.JSON(http.StatusBadRequest, err)
	// 	return
	// }

	// response, err := service.ForgotMpinService(forgotmpin)
	// if err != nil {
	// 	c.JSON(http.StatusInternalServerError, err)
	// 	return
	// }
	// if response["errMsg"] != "" {
	// 	c.JSON(http.StatusInternalServerError, response)
	// 	return
	// }
	// c.JSON(http.StatusOK, response)
}

func ForgotMpinApiHandler(c *gin.Context) {
	// libhttp.CoreHeader(c)
	// session := sessions.Default(c)
	// retrievedState := session.Get("state")
	// if retrievedState == nil {
	// 	service.Zerologs.Info().Msg("ForgotMpinApiHandler(): RetriveState is Nil")
	// 	c.JSON(http.StatusBadRequest, errors.New("RetriveState is Nil"))
	// 	return
	// }
	// cquery := c.Query("state")
	// if retrievedState != cquery {
	// 	//Pending
	// 	//c.AbortWithError(http.StatusUnauthorized, fmt.Errorf("Invalid session state: %s", retrievedState))
	// 	//return
	// }

	// var forgotMpinReq model.ForgotMPin
	// if err := c.BindJSON(&forgotMpinReq); err != nil {
	// 	service.Zerologs.Error().Msg("ForgotMpinApiHandler(): Error c.BindJSON forgotMpinReq model " + err.Error())
	// 	c.JSON(http.StatusBadRequest, err)
	// 	return
	// }

	// response := service.ForgotMpinApiHandlerService(retrievedState, forgotMpinReq)
	// c.JSON(http.StatusOK, response)
}
