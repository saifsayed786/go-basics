package model

type ChangeMpin struct {
	OldMpin string `json:"oldMpin"`
	NewMpin string `json:"newMpin"`
}
