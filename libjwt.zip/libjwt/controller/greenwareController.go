package controller

import (
	"net/http"

	"github.com/MACMREPO/libjwt/model"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/gin"
)

func GreenWareAccessTokenController(c *gin.Context) {
	var GreenwareData model.GreenwareRequestModel
	err := c.BindJSON(&GreenwareData)
	if err != nil {
		c.JSON(http.StatusBadRequest, "")
		return
	}
	response, err := service.GreenWareAccessTokenService(GreenwareData)
	if err != nil {
		c.JSON(500, err.Error())
		return
	}
	c.JSON(200, response)
}
