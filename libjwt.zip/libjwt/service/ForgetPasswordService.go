package service

import (
	"net/http"
	"time"

	"github.com/MACMREPO/libjwt/helper"
	"github.com/MACMREPO/libjwt/model"
)

func ForgetPassword(RetriveState string, forgetpassword model.ForgetPassword) model.ForgotPasswordResponseModel {
	var ResponseModel model.ForgotPasswordResponseModel
	resp := Verify_OTP(forgetpassword.MobileNo, forgetpassword.OTP)
	if !resp.IsErr {
		// var EmailMap clientmaster.TblMobileEmailMapping
		// err := Db.Client.Where("mobile_no=? AND email=?", forgetpassword.MobileNo, forgetpassword.Email).First(&EmailMap).Error
		_, err := getEmailAndMobFromEmailMapping(forgetpassword.MobileNo, forgetpassword.Email)
		if err != nil {
			Zerologs.Error().Msg("ForgetPassword(): User email data not found for MobileNo=" + forgetpassword.MobileNo + " and Email=" + forgetpassword.Email + "and error is " + err.Error())
			ResponseModel.IsErr = true
			ResponseModel.Msg = "Wrong Email"
			ResponseModel.StatusCode = http.StatusInternalServerError
			return ResponseModel
		}
		// var userData clientmaster.JwtAuthMaster
		// err = Db.Client.Where("mobile_no=?", forgetpassword.MobileNo).First(&userData).Error
		userData, err := getJwtAuthMasterDB(helper.CLIENT_MOBILE_PARAM, forgetpassword.MobileNo)
		if err != nil {
			Zerologs.Error().Msg("ForgetPassword(): User data not found where mobileno= " + forgetpassword.MobileNo + err.Error())
			ResponseModel.IsErr = true
			ResponseModel.Msg = "User details not available"
			ResponseModel.StatusCode = http.StatusInternalServerError
			return ResponseModel
		}
		if userData.PasswordFailedCount >= Env.MAX_PASSWORD_ATTEMPT {
			Zerologs.Info().Msg(" User is blocked for mobile no= " + forgetpassword.MobileNo + " please unblock and try again " + err.Error())
			ResponseModel.IsErr = true
			ResponseModel.Msg = "User is blocked, please unblock and try again"
			ResponseModel.StatusCode = http.StatusInternalServerError
			return ResponseModel

		}
		// err = RedisLib.Client.Set(RetriveState, userData.UserGuid, time.Duration(60*time.Second)).Err()
		err = setDataInRedis(RetriveState, userData.UserGuid, time.Duration(60*time.Second))
		if err != nil {
			Zerologs.Error().Msg("ForgetPassword(): User guid not set in redis for guid:= " + userData.UserGuid + err.Error())
			ResponseModel.IsErr = true
			ResponseModel.Msg = err.Error()
			ResponseModel.StatusCode = http.StatusInternalServerError
			return ResponseModel
		}
		//user verify and redirect to set pass page.
		ResponseModel.IsErr = false
		ResponseModel.Url = "/sign/setpassword?state=" + RetriveState
		ResponseModel.StatusCode = http.StatusOK
		return ResponseModel
	} else {
		if ResponseModel.OtpCnt == "2" {
			imgBase64Str := CreateCaptcha(forgetpassword.MobileNo)
			ResponseModel.IsErr = true
			ResponseModel.StatusCode = http.StatusInternalServerError
			ResponseModel.Img64 = imgBase64Str
			ResponseModel.IsOtp = "1"
			return ResponseModel

		} else {
			ResponseModel.IsErr = true
			ResponseModel.Msg = resp.Msg
			ResponseModel.StatusCode = http.StatusInternalServerError
			return ResponseModel

		}
	}
}
