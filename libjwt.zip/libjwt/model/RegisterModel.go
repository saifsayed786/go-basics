package model

type RegisterModel struct {
	Email    string `json:"email"`
	MobileNo string `json:"mobileNo"`
	OTP      string `json:"otp"`
	Password string `json:"password"`
	UserGuid string `json:"userGuid"`
}

type Tbl_WatchList struct {
	MwName string `json:"mwName"`
	Scrips string `json:"scrips"`
	UsrId  string `json:"usrId"`
}

type Tbl_PaperTrade_limit struct {
	Uid               string  `json:"uid"` // user id
	ContestId         uint    `json:"contestid"`
	ActualLimit       float64 `json:"AmtUntilizedPrsnt"`   // total limit - utilized limit
	Utilized          float64 `json:"AmountUtilizedPrsnt"` // Used limit
	MarginActualLimit float64 `json:"MarginUsedPrsnt"`
	MarginUtilized    float64 `json:"MarginUsed"`
	// MarginUtilized  float64 `json:"MarginUtilized"`
	CollateralValue float64 `json:"CollateralValue"`
	AuxAdhocMargin  float64 `json:"AuxAdhocMargin"`
	AdhocMargin     float64 `json:"AdhocMargin"`
	RMSCollateral   float64 `json:"RmsCollateral"`
	SpanMarginPrsnt float64 `json:"SpanMarginPrsnt"`
}

type WatchListModel struct {
	MwName string `json:"mwName"`
	Scrips string `json:"scrips"`
	UsrId  string `json:"usrId"`
	Type   uint16 `json:"type"`
}

type RegisterUserResponseModel struct {
	IsErr        bool   `json:"isErr"`
	Msg          string `json:"msg"`
	AccessToken  string `json:"access_token,omitempty"`
	RefreshToken string `json:"refresh_token,omitempty"`
	Url          string `json:"url,omitempty"`
	StatusCode   int    `json:"statusCode"`
}
