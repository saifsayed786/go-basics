package controller

import (
	"net/http"
	"strconv"

	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/model"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/gin"
)

func New_Password(c *gin.Context) {
	libhttp.CoreHeader(c)
	mobile_no, err := service.GetUser(c)
	if err != nil {
		service.Zerologs.Error().Err(err).Msg("New_Password(): Unauthorized")
		c.JSON(http.StatusUnauthorized, "Unauthorized")
		return
	}
	MobileNo := strconv.FormatUint(uint64(mobile_no), 10)
	var newpassword model.New_Password
	if err := c.BindJSON(&newpassword); err != nil {
		// fmt.Println(err)
		// service.Zerologs.Error().Msg("New_Password(): Error in c.BindJSON is " + err.Error())
		c.JSON(http.StatusBadRequest, err)
		return
	}
	response := service.NewPasswordMobile(MobileNo, newpassword)
	c.JSON(response.StatusCode, response)
}
