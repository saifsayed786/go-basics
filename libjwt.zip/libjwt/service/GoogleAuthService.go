package service

// import (
// 	"time"

// 	"github.com/MACMREPO/libdb/clientmaster"
// 	"github.com/MACMREPO/libjwt/helper"
// 	"github.com/MACMREPO/libjwt/model"
// 	"github.com/google/uuid"
// )

// func GoogleAuthService(user model.User) (map[string]string, error) {
// 	token := make(map[string]string)

// 	var MobEmail clientmaster.TblMobileEmailMapping
// 	err := Db.Client.Where("email=?", user.Email).First(&MobEmail).Error
// 	if err != nil {
// 		var JwtClientData clientmaster.JwtAuthMaster
// 		err = Db.Client.Where("email=?", user.Email).First(&JwtClientData).Error
// 		if err != nil {
// 			guid := uuid.New()
// 			var clientdbData clientmaster.JwtAuthMaster
// 			clientdbData.Email = user.Email
// 			clientdbData.Activated = false
// 			clientdbData.EmailVerified = user.EmailVerified
// 			clientdbData.FamilyName = user.FamilyName
// 			clientdbData.Gender = user.Gender
// 			clientdbData.GivenName = user.GivenName
// 			clientdbData.Name = user.Name
// 			clientdbData.Picture = user.Picture
// 			clientdbData.Profile = user.Profile
// 			clientdbData.UserGuid = helper.UuidToString(guid)
// 			clientdbData.LastMPIN_UpdatedTime = time.Now()
// 			clientdbData.LastPassword_UpdatedTime = time.Now()
// 			clientdbData.UserActivatedTime = time.Now()
// 			err = Db.Client.Create(&clientdbData).Error
// 			if err != nil {
// 				Zerologs.Error().Msg("GoogleAuth(): Error in create query for jwtauthmater table for emailId= " + user.Email + err.Error())
// 				return nil, err
// 				// fmt.Println(err)
// 			}
// 			token["isKyc"] = "false"
// 			token["isActivated"] = "false"
// 			token["isPasswordSet"] = "false"

// 			return token, nil
// 		} else {
// 			token["isKyc"] = "false"
// 			token["isActivated"] = "false"
// 			token["isPasswordSet"] = "false"

// 			return token, nil
// 		}
// 	} else {
// 		var clientdbData clientmaster.JwtAuthMaster
// 		sAccountcode := clientdbData.ClientID + "-" + "NIT" //Samir Pending

// 		err = Db.Client.Where("mobile_no=?", MobEmail.MobileNo).First(&clientdbData).Error
// 		if err != nil {
// 			Zerologs.Error().Msg("GoogleAuth(): User details not found in JwtAuthMaster for mobile = " + MobEmail.MobileNo + err.Error())

// 			return nil, err
// 		}
// 		if clientdbData.PasswordFailedCount >= Env.MAX_PASSWORD_ATTEMPT {
// 			Zerologs.Info().Msg("GoogleAuth(): Mobileno=" + clientdbData.MobileNo + " is blocked, please unblock and try again")
// 			token["errMsg"] = "User is blocked, please unblock and try again"

// 			return token, nil
// 		}
// 		token, err := GenerateJWTWithRefresh(MobEmail.MobileNo, user.Email, sAccountcode)
// 		if err != nil {
// 			Zerologs.Error().Msg("GoogleAuth(): Error in GenerateJWTWithRefresh for mobileno=" + MobEmail.MobileNo + " and email=" + user.Email + " is " + err.Error())
// 			return nil, err
// 		}
// 		// token["refresh_token"] = clientdbData.Refreshtoken //send same refresh token which is save in db during registering
// 		if clientdbData.Password != "" {
// 			if clientdbData.IsPasswordReset {
// 				if clientdbData.KYCDone {
// 					if MobEmail.MobileNo == "9673780788" {
// 						var greenWareReq model.GreenwareRequestModel
// 						greenWareReq.SsoBy = "mobile+user_type"
// 						greenWareReq.Param1 = MobEmail.MobileNo
// 						greenWareReq.Param2 = 1
// 						mfaccesstoken := GreenWareLoginService(greenWareReq)
// 						if mfaccesstoken != "" {
// 							Zerologs.Info().Msg("GoogleAuth() : User " + MobEmail.MobileNo + " successfully login to greenware " + " AT " + time.Now().Format("2006-01-02 15:04:05"))
// 							token["mftoken"] = mfaccesstoken
// 						} else {
// 							token["mftoken"] = mfaccesstoken
// 						}
// 					}
// 					if clientdbData.Activated {
// 						var tbl_mobEmail clientmaster.TblMobileEmailMapping
// 						err = Db.Client.Where("mobile_no=? and email=?", clientdbData.MobileNo, clientdbData.Email).First(&tbl_mobEmail).Error
// 						if err != nil {
// 							Zerologs.Error().Msg("GoogleAuth(): Data not found in clientmaster.TblMobileEmailMapping  where MobileNo=" + clientdbData.MobileNo + " and Email=" + clientdbData.Email + err.Error())
// 							return nil, err
// 						}
// 						if tbl_mobEmail.TotpStatus {
// 							token["isTotpStatus"] = "true"
// 							token["isActivated"] = "true"
// 							token["isKyc"] = "true"
// 							if clientdbData.IsMPIN_Reset {
// 								token["isMpinSet"] = "true"
// 							} else {
// 								token["isMpinSet"] = "false"
// 							}
// 							return token, nil

// 						}

// 						//new hypersync login code ---start--
// 						if clientdbData.IsMPIN_Reset == false {
// 							token["isKyc"] = "true"
// 							token["isActivated"] = "true"
// 							token["isMpinSet"] = "false"
// 							token["isTotpStatus"] = "false"
// 							// token["refresh_token"] = clientdbData.Refreshtoken
// 							return token, nil //show set mpin
// 						} else {
// 							token["isKyc"] = "true"
// 							token["isMpinSet"] = "true"
// 							token["isActivated"] = "true"
// 							token["isTotpStatus"] = "false"
// 							// token["refresh_token"] = clientdbData.Refreshtoken
// 							return token, nil

// 						}
// 						//new hypersync login code -----end

// 						//old hypersync login code -----start
// 						// if clientdbData.IsMPIN_Reset == false {
// 						// 	token["isKyc"] = "true"
// 						// 	token["isActivated"] = "true"
// 						// 	token["isMpinSet"] = "false"
// 						// 	token["refresh_token"] = clientdbData.Refreshtoken
// 						// 	return token,nil //show set mpin
// 						// } else {
// 						// 	loginModel := model.HyperLoginmodel{
// 						// 		UID:        clientdbData.ClientID + "-" + user.BrokerID,
// 						// 		Pwd:        clientdbData.Password,
// 						// 		BrokerID:   user.BrokerID,
// 						// 		Source:     user.Source,
// 						// 		DeviceName: user.DeviceName,
// 						// 		DeviceInfo: user.DeviceInfo,
// 						// 	}
// 						// 	key, IsMPINRequired, err := HypersyncLogin(loginModel)
// 						// 	// fmt.Println("hypersync devicempin key: ", key)
// 						// 	if err == nil {
// 						// 		token["devicekey"] = key
// 						// 		if IsMPINRequired {
// 						// 			token["isKyc"] = "true"
// 						// 			token["isMpinSet"] = "true"
// 						// 			token["isActivated"] = "true"
// 						// 			token["refresh_token"] = clientdbData.Refreshtoken
// 						// 			return token,nil
// 						// 			return
// 						// 		}
// 						// 	} else {
// 						// 		c.JSON(http.StatusInternalServerError, err)
// 						// 	}
// 						//old hypersync login code -----end
// 					} else {
// 						// if clientdbData.IsMPIN_Reset == false {
// 						// 	token["isKyc"] = "true"
// 						// 	token["isActivated"] = "false"
// 						// 	token["isMpinSet"] = "false"
// 						// 	token["refresh_token"] = clientdbData.Refreshtoken
// 						// 	return token,nil //show set mpin
// 						// }
// 						token["isKyc"] = "true"
// 						token["isMpinSet"] = "false"
// 						token["isActivated"] = "false"
// 						token["hyperSyncAccessToken"] = ""
// 						token["isTotpStatus"] = "false"
// 						// token["refresh_token"] = clientdbData.Refreshtoken
// 						return token, nil
// 					}
// 				} else {
// 					// if clientdbData.Password == "" {
// 					// 	token["isKyc"] = "false"
// 					// 	token["isActivated"] = "false"
// 					// 	token["isPasswordSet"] = "false"
// 					// 	token["refresh_token"] = clientdbData.Refreshtoken
// 					// 	return token,nil
// 					// 	return
// 					// } else {
// 					token["isKyc"] = "false"
// 					token["isActivated"] = "false"
// 					token["isPasswordSet"] = "true"
// 					// token["refresh_token"] = clientdbData.Refreshtoken
// 					return token, nil

// 					// }
// 				}
// 			} else {
// 				token["isPasswordReset"] = "false"
// 				token["Msg"] = "Show change password screen"
// 				// token["refresh_token"] = clientdbData.Refreshtoken
// 				return token, nil
// 			}
// 		} else {
// 			token["isKyc"] = "false"
// 			token["isActivated"] = "false"
// 			token["isPasswordSet"] = "false"
// 			return token, nil

// 		}
// 	}
// }
