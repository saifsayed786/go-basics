package controller

import (
	"crypto/rand"
	"encoding/base64"
	"net/http"
	"strings"
	"time"

	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/helper"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/contrib/sessions"
	"github.com/gin-gonic/gin"
)

func GLoginHandler(c *gin.Context) {
	libhttp.CoreHeader(c)
	Referer := c.Request.Header.Get("referer")
	if Referer == "https://www.nuuu.com/" {
		Referer = service.BaseUrl
	}
	service.Zerologs.Info().Msg("GLoginHandler() : Referer " + Referer)
	// fmt.Println("GLoginHandler() : Referer " + Referer)
	if strings.Contains(Referer, "unblockuser") || strings.Contains(Referer, "setpassword") {
		Referer = ""
	}
	service.State = randToken()
	session := sessions.Default(c)
	session.Set("state", service.State)
	session.Save()
	retrievedState := session.Get("state")
	if retrievedState == nil {
		service.Zerologs.Info().Msg("AuthHandler(): RetriveState is Nil")
		return
	}
	err := service.RedisLib.Client.Set(retrievedState.(string)+"-RedirectUrl", Referer, time.Hour).Err()
	if err != nil {
		service.Zerologs.Error().Msg("AuthHandler(): RedirectUrl not set in redis for retrieved state of user mobileNo:= " + retrievedState.(string) + err.Error())
		c.JSON(http.StatusInternalServerError, err)
		return
	}
	loginURL := GetLoginURL(service.State)
	regurl := "/sign/register?state=" + service.State
	unblockurl := "/sign/unblockuser?state=" + service.State
	fpasdurl := "/sign/forgotpass?state=" + service.State
	temprighttemplate := strings.Replace(helper.Righttemplate, "<RegisterURL>", regurl, 1)
	//fmt.Println("temprighttemplate is " + temprighttemplate)
	//temprightUnbtemplate := strings.Replace(temprighttemplate, "<UnblockURL>", unblockurl, 1)
	//fmt.Println("temprightUnbtemplate is " + temprightUnbtemplate)
	//temprighttforgotemplate := strings.Replace(temprighttemplate, "<TestURL>", fpasdurl, -1)
	//fmt.Println("temprighttforgotemplate is " + temprighttforgotemplate)
	stemplate := helper.Lefttemplate + loginURL + temprighttemplate
	stemplate = strings.Replace(stemplate, "<ForgotURL>", fpasdurl, 1)
	stemplate = strings.Replace(stemplate, "<UnblockURL>", unblockurl, 1)
	stemplate = strings.Replace(stemplate, "<RegisterURL>", regurl, 1)
	//fmt.Println("stemplate is " + stemplate)
	// stemplate = Lefttemplate + loginURL + temprighttemplate
	// stemplate = Lefttemplate + loginURL + temprighttemplate
	//fmt.Println("stemplate is " + fpasdurl + " unblockurl " + unblockurl)
	c.Writer.Write([]byte(stemplate))
}
func randToken() string {
	b := make([]byte, 32)
	rand.Read(b)
	return base64.StdEncoding.EncodeToString(b)
}
func GetLoginURL(state string) string {
	return helper.Conf.AuthCodeURL(state)
}
