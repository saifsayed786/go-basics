package controller

import (
	"net/http"
	"strconv"

	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/gin"
)

func GetProfileHandler(c *gin.Context) {
	libhttp.CoreHeader(c)
	mobile_no, err := service.GetUser(c)
	if err != nil {
		service.Zerologs.Error().Err(err).Msg("GetProfileHandler(): Unauthorized")
		c.JSON(http.StatusUnauthorized, "Unauthorized")
		return
	}
	MobileNo := strconv.FormatUint(uint64(mobile_no), 10)
	// fmt.Println("GetProfileHandler(): MobileNo=" + MobileNo)
	response, err := service.GetProfileHandlerService(MobileNo)
	if err != nil {
		c.JSON(500, err)
		return
	}
	c.JSON(200, response)
}
