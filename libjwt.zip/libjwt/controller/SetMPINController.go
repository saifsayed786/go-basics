package controller

import (
	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/helper"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/contrib/sessions"
	"github.com/gin-gonic/gin"
)

func SetMPINHandler(c *gin.Context) {
	libhttp.CoreHeader(c)
	session := sessions.Default(c)
	retrievedState := session.Get("state")
	cquery := c.Query("state")
	if retrievedState != cquery {
		service.Zerologs.Error().Msg("SetMPINApiHandler(): retrievedState and cquery is not equal:=  " + retrievedState.(string) + " -- " + cquery)
		// c.AbortWithError(http.StatusUnauthorized, fmt.Errorf("Invalid session state: %s", retrievedState))
		// return
	}
	c.Writer.Write(helper.SetMpintemplate)
}

func SetMPIN(c *gin.Context) {
	// libhttp.CoreHeader(c)
	// mobile_no, err := service.GetUser(c)
	// if err != nil {
	// 	service.Zerologs.Error().Err(err).Msg("SetMPIN(): Unauthorized")
	// 	c.JSON(http.StatusUnauthorized, "Unauthorized")
	// 	return
	// }
	// MobileNo := strconv.FormatUint(uint64(mobile_no), 10)
	// var setmpinmodel model.SetMpinModel
	// err = c.BindJSON(&setmpinmodel)
	// if err != nil {
	// 	// fmt.Println("Bind Data Failed")
	// 	service.Zerologs.Error().Msg("SetMPIN(): Error in c.BindJSON is " + err.Error())
	// 	c.JSON(http.StatusBadRequest, "")
	// 	return
	// }
	// response, err := service.SetMPINService(MobileNo, setmpinmodel)
	// if err != nil {
	// 	c.JSON(http.StatusInternalServerError, err.Error())
	// 	return
	// }
	// result, ok := response["errMsg"]
	// if ok {
	// 	c.JSON(500, result)
	// 	return
	// }
	// c.JSON(200, response)
}
