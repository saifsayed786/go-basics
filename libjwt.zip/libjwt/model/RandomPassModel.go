package model

type PasswordMail struct {
	Username string `json:"Username"` // Username
	Password string `json:"Password"` // Generated Password
}

type SendMail struct {
	Document   string `json:"Document"`   //Base64
	ReportType string `json:"ReportType"` // report Name
	FileName   string `json:"sFileName"`  // Filename to show user
	ToEmail    string `json:"ToEmail"`    // User Email Id
	Data       string `json:"sData"`      //json data
}
type InfobipMailModel struct {
	From               string   `json:"from"`
	To                 string   `json:"to"`
	Cc                 []string `json:"cc"`
	Subject            string   `json:"subject"`
	Text               string   `json:"text"`
	Html               string   `json:"html"`
	BulkId             string   `json:"bulkId"`
	IntermediateReport string   `json:"intermediateReport"`
	NotifyContentType  string   `json:"notifyContentType"`
	Attachment         []string `json:"attachment"`
}
