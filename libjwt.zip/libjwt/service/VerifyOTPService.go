package service

import (
	"fmt"
	"strconv"
	"time"

	"github.com/MACMREPO/libdb/clientmaster"
	"github.com/MACMREPO/libjwt/model"
)

func VerifyOTPService(VerifyModel model.OtpVerifyModel) (map[string]string, error) {
	token := make(map[string]string)
	rotp, err := RedisLib.Client.Get(VerifyModel.MobileNo).Result()
	var userdata clientmaster.TblMobileOtp
	err = Db.Client.Where("mobile_no=?", VerifyModel.MobileNo).First(&userdata).Error
	if err != nil {
		Zerologs.Error().Msg("Verify_OTP(): User " + VerifyModel.MobileNo + " Not found in  clientmaster.TblMobileOtp")
		return nil, err
	}
	if VerifyModel.Otp != rotp {
		if userdata.OtpAttempt >= Env.MAX_OTP_ATTEMPT {
			Zerologs.Error().Msg(" user " + VerifyModel.MobileNo + " is blocked for 15 minutes ")
			token["errMsg"] = " User is blocked, please try again after 15 minutes "
			return token, nil
		}
		Zerologs.Error().Msg("Verify_OTP(): User " + VerifyModel.MobileNo + " enter invalid OTP ")
		attempt := (userdata.OtpAttempt) + 1
		err := Db.Client.Model(clientmaster.TblMobileOtp{}).Where("mobile_no=?", VerifyModel.MobileNo).Updates(clientmaster.TblMobileOtp{OtpAttempt: attempt, OtpBlockTime: time.Now()}).Error
		if err != nil {
			fmt.Println(err)
			return nil, err
		}
		remainingcount := Env.MAX_OTP_ATTEMPT - attempt
		if remainingcount == 0 {
			token["errMsg"] = "User is blocked for 15 minutes"
		} else {
			if attempt == 2 {
				imgBase64Str := CreateCaptcha(VerifyModel.MobileNo)
				token["img64"] = imgBase64Str
				token["errMsg"] = "Invalid OTP. " + strconv.Itoa(remainingcount) + " attempts remaining "
				token["isOtp"] = "1"
				return token, nil
			} else {
				token["errMsg"] = "Invalid OTP. " + strconv.Itoa(remainingcount) + " attempts remaining "
				// token["otpCnt"] = strconv.Itoa(attempt)
				return token, nil
			}

		}

	}
	if userdata.OtpAttempt >= 3 {
		Zerologs.Error().Msg(" user " + VerifyModel.MobileNo + " is blocked for 15 minutes ")
		token["errMsg"] = "User is blocked for 15 minutes"
		return token, nil
	} else {
		err := Db.Client.Model(clientmaster.TblMobileOtp{}).Updates(clientmaster.TblMobileOtp{OtpAttempt: 0}).Error
		if err != nil {
			fmt.Println(err)
			return nil, err
		}
		var UserData clientmaster.TblMobileEmailMapping
		err = Db.Client.Where("mobile_no=?", VerifyModel.MobileNo).First(&UserData).Error
		if err != nil {
			token["Msg"] = "Success"
			token["Flag2"] = "Newly registered"
			return token, nil
		}
		token["Msg"] = "Success"
		token["Flag1"] = "Already registered"
		return token, nil
	}
}

func Verify_OTP(mobileNo, otp string) model.VerifyOTPResponseModel {
	var ResponseModel model.VerifyOTPResponseModel
	rotp, err := RedisLib.Client.Get(mobileNo).Result()
	if err != nil {
		Zerologs.Error().Err(err).Msg("Verify_OTP(): Error in getting otp from redis for mobileno=" + mobileNo)
		ResponseModel.IsErr = true
		ResponseModel.Msg = err.Error()
		return ResponseModel
	}
	var userdata clientmaster.TblMobileOtp
	err = Db.Client.Where("mobile_no=?", mobileNo).First(&userdata).Error
	if err != nil {
		Zerologs.Error().Msg("Verify_OTP(): User " + mobileNo + " Not found in  clientmaster.TblMobileOtp")
		ResponseModel.IsErr = true
		ResponseModel.Msg = err.Error()
		return ResponseModel
	}
	if otp != rotp {
		if userdata.OtpAttempt >= Env.MAX_OTP_ATTEMPT {
			Zerologs.Error().Msg(" user " + mobileNo + " is blocked for 15 minutes ")
			ResponseModel.IsErr = true
			ResponseModel.Msg = "User is blocked, please try again after 15 minutes."
			return ResponseModel
		}
		Zerologs.Error().Msg("Verify_OTP(): User " + mobileNo + " enter invalid OTP ")
		attempt := (userdata.OtpAttempt) + 1
		err := Db.Client.Model(clientmaster.TblMobileOtp{}).Where("mobile_no=?", mobileNo).Updates(clientmaster.TblMobileOtp{OtpAttempt: attempt, OtpBlockTime: time.Now()}).Error
		if err != nil {
			ResponseModel.IsErr = true
			ResponseModel.Msg = err.Error()
			return ResponseModel
		}
		remainingcount := Env.MAX_OTP_ATTEMPT - attempt
		if remainingcount == 0 {
			ResponseModel.IsErr = true
			ResponseModel.Msg = "User is blocked for 15 minutes"
			return ResponseModel
		} else {
			ResponseModel.IsErr = true
			ResponseModel.Msg = "Invalid OTP. " + strconv.Itoa(remainingcount) + " attempts remaining "
			ResponseModel.OtpCnt = attempt
			return ResponseModel
		}
	}
	if userdata.OtpAttempt >= 3 {
		Zerologs.Error().Msg(" user " + mobileNo + " is blocked for 15 minutes ")
		ResponseModel.IsErr = true
		ResponseModel.Msg = "User is blocked for 15 minutes"
		return ResponseModel
	} else {
		err := Db.Client.Model(clientmaster.TblMobileOtp{}).Where("mobile_no=?", mobileNo).Updates(clientmaster.TblMobileOtp{OtpAttempt: 0}).Error
		if err != nil {
			ResponseModel.IsErr = true
			ResponseModel.Msg = err.Error()
			return ResponseModel
		}

		var UserData clientmaster.TblMobileEmailMapping
		err = Db.Client.Where("mobile_no=?", mobileNo).First(&UserData).Error
		if err != nil {
			ResponseModel.IsErr = false
			ResponseModel.Msg = "Success"
			ResponseModel.Flag = "Newly registered"
			return ResponseModel
		}
		ResponseModel.IsErr = false
		ResponseModel.Msg = "Success"
		ResponseModel.Flag = "Already registered"
		return ResponseModel
	}

}
