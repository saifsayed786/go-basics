package service

import (
	"strings"

	"github.com/MACMREPO/libdb/clientmaster"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/credentials"
	"github.com/aws/aws-sdk-go/aws/session"
)

func RemoveProfilePicService(MobileNo string) (string, error) {
	var clientData clientmaster.JwtAuthMaster
	err := Db.Client.Where("mobile_no=?", MobileNo).First(&clientData).Error
	if err != nil {
		Zerologs.Error().Msg(" RemoveProfilePic() : User data not found in clientmaster.JwtAuthMaster for user " + MobileNo + err.Error())
		return "", err
	}
	filepath := clientData.Picture
	filename := strings.Split(filepath, ".com/")
	session, err := session.NewSession(&aws.Config{
		Region:      aws.String(Env.AWS_S3_REGION),
		Credentials: credentials.NewEnvCredentials(),
	})
	if err != nil {
		Zerologs.Error().Msg("RemoveProfilePic(): error while session.NewSession " + err.Error())
		return "", err
	}
	err = RemoveFile(session, filename[1])
	if err != nil {
		Zerologs.Error().Msg("RemoveProfilePic(): error while remove profilepic on S3 " + err.Error())
		return "", err

	}
	err = Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", MobileNo).Updates(clientmaster.JwtAuthMaster{Picture: "https://img.MACMREPO.com/images/user-profile.svg"}).Error
	if err != nil {
		Zerologs.Error().Msg(" RemoveProfilePic():Remove pic update query failed for user " + MobileNo + err.Error())
		return "", err
	}
	Zerologs.Info().Msg("RemoveProfilePic(): User " + MobileNo + " remove his profile picture successfully...!")
	return "Success", nil
}
