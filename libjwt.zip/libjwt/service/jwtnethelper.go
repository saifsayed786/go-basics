package service

import (
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/MACMREPO/libjwt/helper"
	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt"
	"github.com/golobby/container/v3"
	"github.com/prometheus/client_golang/prometheus"
)

func InitNetJwt() error {
	err := container.Resolve(&Env)
	if err != nil {
		panic("Env Lib is Not register please register with init")
	}

	err = container.NamedResolve(&Zerologs, "zerologs")
	if err != nil {
		panic("Log Lib is Not register please register with init")
	}

	if Env.SECRET == "" {
		panic("Env.SECRET Not FOUND")
	}

	if Env.JWTKEY == "" {
		panic("Env.JWTKEY Not FOUND")
	}

	if Env.JWTISSUER == "" {
		panic("Env.JWTISSUER Not FOUND")
	}

	if Env.JWTAUDIENCE == "" {
		panic("Env.JWTAUDIENCE Not FOUND")
	}

	if Env.MY_POD_NAME == "" {
		panic("Env.MY_POD_NAME Not FOUND")
	}
	hmacSampleSecret = []byte(Env.JWTKEY)

	JwtCounterVecRequested = prometheus.NewCounterVec(
		prometheus.CounterOpts{
			Name: "JWT_RRQUESTED",
			Help: "Total Requested JWT Token .",
		},
		[]string{"jwt"},
	)
	err = prometheus.Register(JwtCounterVecRequested)
	if err != nil {
		Zerologs.Error().Msg("Error while registering promethus " + Env.MY_POD_NAME + "_JWT_RRQUESTED" + "  " + err.Error())
		return err
	}

	JwtCounterVecRequestFailure = prometheus.NewCounterVec(
		prometheus.CounterOpts{
			Name: "JWT_RRQUESTED_FAILURE",
			Help: "Total Requested Failure JWT Token .",
		},
		[]string{"jwt"},
	)
	err = prometheus.Register(JwtCounterVecRequestFailure)
	if err != nil {
		Zerologs.Error().Msg("Error while registering promethus " + Env.MY_POD_NAME + "_JWT_RRQUESTED_FAILURE" + "  " + err.Error())
		return err
	}
	JwtCounterVecSuccess = prometheus.NewCounterVec(
		prometheus.CounterOpts{
			Name: "JWT_SUCCESS",
			Help: "Total Success JWT Token .",
		},
		[]string{"jwt"},
	)
	err = prometheus.Register(JwtCounterVecSuccess)
	if err != nil {
		Zerologs.Error().Msg("Error while registering promethus " + Env.MY_POD_NAME + "_JWT_SUCCESS" + "  " + err.Error())
		return err
	}
	JwtCounterVecFailure = prometheus.NewCounterVec(
		prometheus.CounterOpts{
			Name: "JWT_FAILURE",
			Help: "Total Failure JWT Token .",
		},
		[]string{"jwt"},
	)
	err = prometheus.Register(JwtCounterVecFailure)
	if err != nil {
		Zerologs.Error().Msg("Error while registering promethus " + Env.MY_POD_NAME + "_JWT_FAILURE" + "  " + err.Error())
		return err
	}
	return nil
}

func GetNetUser(c *gin.Context) (string, error) {
	jwttoken := c.GetHeader("Authorization")
	if jwttoken == "" {
		JwtCounterVecFailure.WithLabelValues("jwt").Inc()
		return "", errors.New("token not found")
	}
	strArr := strings.Split(jwttoken, " ")
	if len(strArr) == 2 {
		jwttoken = strArr[1]
	} else {
		JwtCounterVecFailure.WithLabelValues("jwt").Inc()
		err := errors.New("authorization is not in proper format")
		Zerologs.Error().Msg("GetUser  Split  Error Token :=" + jwttoken + ", Error:=" + err.Error())
		return "", err
	}

	token, err := jwt.Parse(jwttoken, func(token *jwt.Token) (interface{}, error) {
		// Don't forget to validate the alg is what you expect:
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			JwtCounterVecFailure.WithLabelValues("jwt").Inc()
			Zerologs.Error().Msg("GetUser  Jwt Parse :=")
			return nil, fmt.Errorf("Unexpected signing method: %v", token.Header["alg"])
		}
		// hmacSampleSecret is a []byte containing your secret, e.g. []byte("my_secret_key")
		return hmacSampleSecret, nil
	})
	var sClaim string
	if claimsm, ok := token.Claims.(jwt.MapClaims); ok && token.Valid {
		isverify := claimsm.VerifyAudience(Env.JWTAUDIENCE, true)
		isissuer := claimsm.VerifyIssuer(Env.JWTISSUER, true)
		if isverify && isissuer {
			sClaim = claimsm[helper.Name].(string)
		} else {
			JwtCounterVecFailure.WithLabelValues("jwt").Inc()
			err := errors.New("claim Not Found")
			Zerologs.Error().Msg("GetUser  Split  Error Token :=" + err.Error())
			return "", err
		}

	} else {
		JwtCounterVecFailure.WithLabelValues("jwt").Inc()
		Zerologs.Error().Msg("GetUser ParseUint  sClaim:=" + sClaim + " " + err.Error())
		return "", err
	}
	JwtCounterVecSuccess.WithLabelValues("jwt").Inc()
	return sClaim, nil
}

func GenerateNetJWT(username string) (string, error) {
	if JwtCounterVecRequested != nil {
		JwtCounterVecRequested.WithLabelValues("jwt").Inc()
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"name": username,
		"iat":  time.Now().Unix(),
		"exp":  time.Now().Add(time.Minute * time.Duration(Env.JWT_REFRESH_TOKEN_TIME_TO_EXPIRE_IN_DAYS)).Unix(),
		"nbf":  time.Date(2015, 10, 10, 12, 0, 0, 0, time.UTC).Unix(),
		"aud":  Env.JWTAUDIENCE,
		"iss":  Env.JWTISSUER,
	})
	tokenString, err := token.SignedString(hmacSampleSecret)
	if err != nil {
		JwtCounterVecRequestFailure.WithLabelValues("jwt").Inc()
		Zerologs.Error().Msg("GenerateJWT  SignedString Error :=" + err.Error())
		return "", err
	}
	return tokenString, nil
}
