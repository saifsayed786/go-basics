package model

type NormalLoginmodel struct {
	UserName   string `json:"UserName" binding:"required"` // New Field Added [Ajay N 20230609]
	Mobileno   string `json:"Mobileno" `                   // Commented Field Added [Ajay N 20230609]
	Password   string `json:"Password"`
	UID        string `json:"uid"`
	Pwd        string `json:"pwd"`
	BrokerID   string `json:"brokerId"`
	Source     string `json:"source"`
	DeviceName string `json:"deviceName"`
	DeviceInfo string `json:"deviceInfo"`
}
type MobileLoginModel struct {
	Mobileno string `json:"Mobileno"`
}

type NormalLoginResponseModel struct {
	IsErr        bool   `json:"isErr"`
	Msg          string `json:"msg"`
	StatusCode   int    `json:"statusCode"`
	AccessToken  string `json:"access_token,omitempty"`
	RefreshToken string `json:"refresh_token,omitempty"`
	Url          string `json:"url,omitempty"`
}
