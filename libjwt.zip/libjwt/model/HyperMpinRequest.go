package model

type HyperMpinRequest struct {
	UID           string `json:"uid"`
	Mpin          string `json:"mpin"`
	BrokerID      string `json:"brokerId"`
	Devicempinkey string `json:"devicempinkey"`
	Source        string `json:"source"`
	DeviceName    string `json:"deviceName"`
	DeviceInfo    string `json:"deviceInfo"`
}
