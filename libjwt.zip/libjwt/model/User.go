package model

type User struct {
	Sub           string `json:"sub"`
	Name          string `json:"name"`
	GivenName     string `json:"given_name"`
	FamilyName    string `json:"family_name"`
	Profile       string `json:"profile"`
	Picture       string `json:"picture"`
	Email         string `json:"email"`
	EmailVerified bool   `json:"email_verified"`
	Gender        string `json:"gender"`
	Hd            string `json:"hd"`
	UID           string `json:"uid"`
	Pwd           string `json:"pwd"`
	BrokerID      string `json:"brokerId"`
	Source        string `json:"source"`
	DeviceName    string `json:"deviceName"`
	DeviceInfo    string `json:"deviceInfo"`
}
