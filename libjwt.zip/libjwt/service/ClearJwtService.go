package service

import (
	"fmt"
	"os"
	"strconv"

	"github.com/MACMREPO/libdb/clientmaster"
	"github.com/MACMREPO/libjwt/helper"
)

func ClearJwtService(MobileNo string) {
	type ClearJwtModel struct {
		MobileNo string `json:"MobileNo"`
	}
	var UrlMobile ClearJwtModel
	UrlMobile.MobileNo = MobileNo
	// var userData clientmaster.JwtAuthMaster
	// err := Db.Client.Where("mobile_no=?", MobileNo).First(&userData).Error
	userData, err := getJwtAuthMasterDB(helper.CLIENT_MOBILE_PARAM, MobileNo)
	if err != nil {
		Zerologs.Error().Msg("ClearJwt(): Userdata not found in JwtAuthMaster for mobileno=" + MobileNo + err.Error())
		return
	}

	var JwtUser []clientmaster.JwtAuthMaster
	err = Db.Client.Model(clientmaster.JwtAuthMaster{}).Where("mobile_no=?", MobileNo).Delete(JwtUser).Error
	if err != nil {
		Zerologs.Error().Msg("ClearJwt(): Error while delete data in JwtAuthMaster for mobileno=" + MobileNo + " is " + err.Error())
		return
	}
	jwtauthaudit := clientmaster.JwtAuthMasterAudit{
		CreatedAtMain:            userData.CreatedAt,
		UpdatedAtMain:            userData.UpdatedAt,
		MobileNo:                 userData.MobileNo,
		MobileOtp:                userData.MobileOtp,
		MobileVerified:           userData.MobileVerified,
		Email:                    userData.Email,
		ClientID:                 userData.ClientID,
		Password:                 userData.Password,
		Activated:                userData.Activated,
		UserActivatedTime:        userData.UserActivatedTime,
		UserActivatedFlag:        userData.UserActivatedFlag,
		UserGuid:                 userData.UserGuid,
		Sub:                      userData.Sub,
		Name:                     userData.Name,
		GivenName:                userData.GivenName,
		FamilyName:               userData.FamilyName,
		Profile:                  userData.Profile,
		Picture:                  userData.Picture,
		EmailVerified:            userData.EmailVerified,
		Gender:                   userData.Gender,
		KYCDone:                  userData.KYCDone,
		MPIN:                     userData.MPIN,
		PasswordFailedCount:      userData.PasswordFailedCount,
		LastPassword_UpdatedTime: userData.LastPassword_UpdatedTime,
		IsPasswordReset:          userData.IsPasswordReset,
		LastMPIN_UpdatedTime:     userData.LastMPIN_UpdatedTime,
		IsMPIN_Reset:             userData.IsMPIN_Reset,
		HyperSyncAccessToken:     userData.HyperSyncAccessToken,
		Pan:                      userData.Pan,
		Default_password:         userData.Default_password,
		Refreshtoken:             userData.Refreshtoken,
		ActionType:               "Delete",
	}
	err = Db.Client.Create(&jwtauthaudit).Error
	if err != nil {
		Zerologs.Error().Msg("ClearJwt(): JWTAUTH data not inserted in clientmaster.JwtAuthMasterAudit, User mobileno=" + MobileNo + err.Error())
		return
	}

	var MobEmail []clientmaster.TblMobileEmailMapping
	err = Db.Client.Model(clientmaster.TblMobileEmailMapping{}).Where("mobile_no=?", MobileNo).Delete(MobEmail).Error
	if err != nil {
		Zerologs.Error().Msg("ClearJwt(): Error while delete data in TblMobileEmailMapping for mobileno=" + MobileNo + " is " + err.Error())
		return
	}

	var Password []clientmaster.PasswordHistory
	err = Db.Client.Model(clientmaster.PasswordHistory{}).Where("mobile_no=?", MobileNo).Delete(Password).Error
	if err != nil {
		Zerologs.Error().Msg("ClearJwt(): Error while delete data in PasswordHistory for mobileno=" + MobileNo + " is " + err.Error())
		return
	}

	sStage := os.Getenv("STAGE")
	Papertradepath := ""
	if sStage == "" {
		Papertradepath = "https://www.nuuu.com"
	} else {
		Papertradepath = "http://papertrade-" + sStage + "-service:8085"
	}
	url := Papertradepath + "/papertrade/api/clearjwt"
	err = DeleteDataUrl(url, UrlMobile)
	if err != nil {
		Zerologs.Error().Msg("ClearJwt(): Error from DeleteDataUrl() while sending request to delete data of papertrade watchlist and limit is " + err.Error())
		return
	}

	Watchlistpath := ""
	if sStage == "" {
		Watchlistpath = "https://www.nuuu.com"
	} else {
		Watchlistpath = "http://watchlist-" + sStage + "-service:8085"
	}
	url = Watchlistpath + "/watchlist/api/clearjwt"
	err = DeleteDataUrl(url, UrlMobile)
	if err != nil {
		Zerologs.Error().Msg("ClearJwt(): Error from DeleteDataUrl() while sending request to delete data of trade watchlist is " + err.Error())
		return
	}

	facetradepath := ""
	if sStage == "" {
		facetradepath = "https://www.nuuu.com"
	} else {
		facetradepath = "http://facetrade-" + sStage + "-service:8085"
	}
	url = facetradepath + "/facetrade/jwtauth/socialclearjwt"
	err = DeleteDataUrl(url, UrlMobile)
	if err != nil {
		Zerologs.Error().Msg("ClearJwt(): Error from DeleteDataUrl() while sending request to delete data of trade watchlist is " + err.Error())
		return
	}
	// err = RedisLib.Client.Del("up:" + userData.UserGuid).Err()
	err = deleteDataFromRedis("up:" + userData.UserGuid)
	if err != nil {
		Zerologs.Error().Msg("ClearJwt():up redis key not deleted for user=" + MobileNo + err.Error())
		return
	}
	uintMobi, _ := strconv.Atoi(MobileNo)
	mobile := float64(uintMobi)
	score := fmt.Sprintf("%f", mobile)
	// err = RedisLib.Client.ZRemRangeByScore("af:", score, score).Err()
	err = deleteRangeDataFromRedis("af:", score, score)
	if err != nil {
		Zerologs.Error().Msg("ClearJwt():af redis key data not deleted for user=" + MobileNo + err.Error())
		return
	}
}
