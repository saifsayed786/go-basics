package service

import (
	"fmt"
	"net/http"
	"time"

	"github.com/MACMREPO/libdb/clientmaster"
	"github.com/MACMREPO/libjwt/helper"
	"github.com/MACMREPO/libjwt/model"
	"github.com/google/uuid"
)

func AddMobileService(mobilemodel model.MobileModel) model.AddMobileResponseModel {
	var ResponseModel model.AddMobileResponseModel
	// res, _ := IsAlreadyRegister(mobilemodel.Mobileno)
	MobEmail, err := getTblMobileEmailMapping(helper.CLIENT_MOBILE_PARAM, mobilemodel.Mobileno)
	// err := Db.Client.Where("mobile_no=?", mobilemodel.Mobileno).First(&MobEmail).Error
	if err != nil {
		resp := Verify_OTP(mobilemodel.Mobileno, mobilemodel.OTP)
		if !resp.IsErr {
			// err = Db.Client.Where("email=?", mobilemodel.Email).First(&MobEmail).Error
			MobEmail, err = getTblMobileEmailMapping(helper.CLIENT_EMAIL_PARAM, mobilemodel.Email)
			if err == nil {
				Zerologs.Info().Msg("Add_Mobile(): Email=" + mobilemodel.Email + " is already registered")
				ResponseModel.IsErr = true
				ResponseModel.Msg = "Email is already registered"
				ResponseModel.StatusCode = http.StatusInternalServerError
				return ResponseModel
			}
			MobEmail.MobileNo = mobilemodel.Mobileno
			MobEmail.Email = mobilemodel.Email
			MobEmail.EmailVerified = true
			// EnqueuToDBChannel(MobEmail)
			err = Db.Client.Create(&MobEmail).Error
			if err != nil {
				Zerologs.Error().Msg("Add_Mobile(): Error in create query for TblMobileEmailMapping for mobileno=" + mobilemodel.Mobileno + " and email=" + mobilemodel.Email + " and error is " + err.Error())
				ResponseModel.IsErr = true
				ResponseModel.Msg = err.Error()
				ResponseModel.StatusCode = http.StatusInternalServerError
				return ResponseModel
			}

			var UserGUID uuid.UUID
			// var guidData clientmaster.MobileGuidMaster
			// err = Db.Client.Where("mobile_no=?", mobilemodel.Mobileno).First(&guidData).Error
			guidData, err := getMobileGuidMaster(mobilemodel.Mobileno)
			if err != nil {
				UserGUID = uuid.New()
				guidData.UserGuid = UserGUID
				guidData.MobileNo = mobilemodel.Mobileno
				err = Db.Client.Create(&guidData).Error
				if err != nil {
					Zerologs.Error().Msg("Add_Mobile(): Error in create query for MobileGuidMaster for mobileno=" + mobilemodel.Mobileno + " and error is " + err.Error())
					ResponseModel.IsErr = true
					ResponseModel.Msg = err.Error()
					ResponseModel.StatusCode = http.StatusInternalServerError
					return ResponseModel
				}
			} else {
				UserGUID = guidData.UserGuid
			}
			UsrmobileNo := mobilemodel.Mobileno
			// var clientdbData clientmaster.JwtAuthMaster
			// err = Db.Client.Where("email=?", mobilemodel.Email).First(&clientdbData).Error
			clientdbData, err := getJwtAuthMasterDB(helper.CLIENT_EMAIL_PARAM, mobilemodel.Email)
			if err == nil {
				sAccountcode := clientdbData.ClientID + "-" + "NIT" //Samir Pending
				token, err := GenerateJWTWithRefresh(UsrmobileNo, mobilemodel.Email, sAccountcode)
				if err != nil {
					Zerologs.Error().Msg("Add_Mobile(): Error in GenerateJWTWithRefresh for mobileno=" + UsrmobileNo + " and email=" + mobilemodel.Email + " is " + err.Error())
					ResponseModel.IsErr = true
					ResponseModel.Msg = err.Error()
					ResponseModel.StatusCode = http.StatusInternalServerError
					return ResponseModel
				}
				err = Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("email=?", mobilemodel.Email).Updates(clientmaster.JwtAuthMaster{MobileNo: mobilemodel.Mobileno, Password: mobilemodel.Password, UserGuid: helper.UuidToString(UserGUID), MobileVerified: true, IsPasswordReset: true, Refreshtoken: token.RefreshToken}).Error
				if err != nil {
					Zerologs.Error().Msg("Add_Mobile(): Error in update refreshToken for email=" + mobilemodel.Email + " is " + err.Error())
					ResponseModel.IsErr = true
					ResponseModel.Msg = err.Error()
					ResponseModel.StatusCode = http.StatusInternalServerError
					return ResponseModel
				}
				var passwordhistory clientmaster.PasswordHistory
				passwordhistory.MobileNo = mobilemodel.Mobileno
				passwordhistory.LastPassword = mobilemodel.Password
				passwordhistory.LastPassword_UpdatedTime = time.Now()
				err = Db.Client.Create(&passwordhistory).Error
				if err != nil {
					Zerologs.Error().Msg("Add_Mobile(): Error while add data in password history for mobileno=" + mobilemodel.Mobileno + " is " + err.Error())
					ResponseModel.IsErr = true
					ResponseModel.Msg = err.Error()
					ResponseModel.StatusCode = http.StatusInternalServerError
					return ResponseModel
				}
				var jwtauthmaster clientmaster.JwtAuthMaster
				err = Db.Client.Where("mobile_no=?", mobilemodel.Mobileno).Find(&jwtauthmaster).Error
				if err != nil {
					Zerologs.Error().Msg("Add_Mobile(): Data not found in JwtAuthMaster for mobileno=" + mobilemodel.Mobileno + " and error is " + err.Error())
					ResponseModel.IsErr = true
					ResponseModel.Msg = err.Error()
					ResponseModel.StatusCode = http.StatusInternalServerError
					return ResponseModel
				}

				// err = AddWatchList(mobilemodel.Mobileno)
				// if err != nil {
				// 	Zerologs.Error().Msg("Add_mobile(): Watchlist not added for mobileNo: " + mobilemodel.Mobileno + err.Error())
				// 	ResponseModel.IsErr = true
				// 	ResponseModel.Msg = err.Error()
				// 	ResponseModel.StatusCode = http.StatusInternalServerError
				// 	return ResponseModel
				// }

				// var socialData model.SocialModel
				// socialData.GUID = UserGUID
				// socialData.Mobileno = mobilemodel.Mobileno
				// socialData.Email = mobilemodel.Email
				// socialData.ID = jwtauthmaster.ID
				// if jwtauthmaster.Name == "" {
				// 	socialData.Name = mobilemodel.Mobileno
				// } else {
				// 	socialData.Name = jwtauthmaster.Name
				// }
				// socialData.Username = mobilemodel.Mobileno
				// socialData.Password = mobilemodel.Password
				// socialData.Avatar = ""
				// err = AddSociaInfo(socialData)
				// if err != nil {
				// 	Zerologs.Error().Msg("Add_mobile():Social data not added for mobileNo: " + mobilemodel.Mobileno + err.Error())
				// 	return
				// }
				ResponseModel.IsErr = false
				ResponseModel.Msg = "Success"
				ResponseModel.StatusCode = http.StatusOK
				ResponseModel.AccessToken = token.AccessToken
				ResponseModel.RefreshToken = token.RefreshToken
				ResponseModel.Url = token.Url
				ResponseModel.IsKyc = false
				ResponseModel.IsActivated = false
				ResponseModel.IsPasswordSet = true
				return ResponseModel
			} else {
				token, err := GenerateJWTWithRefresh(UsrmobileNo, mobilemodel.Email, "")
				if err != nil {
					Zerologs.Error().Msg("Add_Mobile(): Error in GenerateJWTWithRefresh for mobileno=" + UsrmobileNo + " and email=" + mobilemodel.Email + " is " + err.Error())
					ResponseModel.IsErr = true
					ResponseModel.Msg = err.Error()
					ResponseModel.StatusCode = http.StatusInternalServerError
					return ResponseModel
				}
				var usermodel model.JwtMaster
				usermodel.MobileNo = mobilemodel.Mobileno
				usermodel.Email = mobilemodel.Email
				usermodel.Refreshtoken = token.RefreshToken
				usermodel.MobileVerified = true
				usermodel.Password = mobilemodel.Password
				usermodel.EmailVerified = true
				usermodel.MobileOtp = mobilemodel.OTP
				usermodel.UserGuid = helper.UuidToString(UserGUID)
				usermodel.IsPasswordReset = true
				_, err = AddJwtMaster(usermodel)
				if err != nil {
					Zerologs.Error().Msg("Add_Mobile(): Error while add data in JwtMaster for mobileno=" + mobilemodel.Mobileno + " and error is " + err.Error())
					ResponseModel.IsErr = true
					ResponseModel.Msg = err.Error()
					ResponseModel.StatusCode = http.StatusInternalServerError
					return ResponseModel
				}
				var passwordhistory clientmaster.PasswordHistory
				passwordhistory.MobileNo = mobilemodel.Mobileno
				passwordhistory.LastPassword = mobilemodel.Password
				passwordhistory.LastPassword_UpdatedTime = time.Now()
				err = Db.Client.Create(&passwordhistory).Error
				if err != nil {
					Zerologs.Error().Msg("Add_Mobile(): Error while add data in password history for mobileno=" + mobilemodel.Mobileno + " is " + err.Error())
					ResponseModel.IsErr = true
					ResponseModel.Msg = err.Error()
					ResponseModel.StatusCode = http.StatusInternalServerError
					return ResponseModel
				}
				// var jwtauthmaster clientmaster.JwtAuthMaster
				// err = Db.Client.Where("mobile_no=?", mobilemodel.Mobileno).Find(&jwtauthmaster).Error
				_, err = getJwtAuthMasterDB(helper.CLIENT_MOBILE_PARAM, mobilemodel.Mobileno)
				if err != nil {
					Zerologs.Error().Msg("Add_Mobile(): Data not found in JwtAuthMaster for mobileno=" + mobilemodel.Mobileno + " and error is " + err.Error())
					ResponseModel.IsErr = true
					ResponseModel.Msg = err.Error()
					ResponseModel.StatusCode = http.StatusInternalServerError
					return ResponseModel
				}

				// err = AddWatchList(mobilemodel.Mobileno)
				// if err != nil {
				// 	Zerologs.Error().Msg("Add_mobile(): Watchlist not added for mobileNo: " + mobilemodel.Mobileno + err.Error())
				// 	ResponseModel.IsErr = true
				// 	ResponseModel.Msg = err.Error()
				// 	ResponseModel.StatusCode = http.StatusInternalServerError
				// 	return ResponseModel
				// }

				// var socialData model.SocialModel
				// socialData.GUID = UserGUID
				// socialData.Mobileno = mobilemodel.Mobileno
				// socialData.Email = mobilemodel.Email
				// socialData.ID = jwtauthmaster.ID
				// if jwtauthmaster.Name == "" {
				// 	socialData.Name = mobilemodel.Mobileno
				// } else {
				// 	socialData.Name = jwtauthmaster.Name
				// }
				// socialData.Username = mobilemodel.Mobileno
				// socialData.Password = mobilemodel.Password
				// socialData.Avatar = ""
				// err = AddSociaInfo(socialData)
				// if err != nil {
				// 	Zerologs.Error().Msg("Add_mobile():Social data not added for mobileNo: " + mobilemodel.Mobileno + err.Error())
				// 	return
				// }
				ResponseModel.IsErr = false
				ResponseModel.Msg = "Success"
				ResponseModel.StatusCode = http.StatusOK
				ResponseModel.AccessToken = token.AccessToken
				ResponseModel.RefreshToken = token.RefreshToken
				ResponseModel.Url = token.Url
				ResponseModel.IsKyc = false
				ResponseModel.IsActivated = false
				ResponseModel.IsPasswordSet = true
				return ResponseModel
			}
		} else {
			ResponseModel.IsErr = true
			ResponseModel.Msg = resp.Msg
			ResponseModel.StatusCode = http.StatusInternalServerError
			return ResponseModel
		}
	} else {
		resp := Verify_OTP(mobilemodel.Mobileno, mobilemodel.OTP)
		if !resp.IsErr {
			// err = Db.Client.Where("email=?", mobilemodel.Email).First(&MobEmail).Error
			_, err = getTblMobileEmailMapping(helper.CLIENT_EMAIL_PARAM, mobilemodel.Email)
			if err != nil {
				var MobEmailModel clientmaster.TblMobileEmailMapping
				MobEmailModel.MobileNo = mobilemodel.Mobileno
				MobEmailModel.Email = mobilemodel.Email
				MobEmailModel.EmailVerified = true
				err = Db.Client.Create(&MobEmailModel).Error
				if err != nil {
					Zerologs.Error().Msg("Add_Mobile(): Error in create query for TblMobileEmailMapping for mobileno=" + mobilemodel.Mobileno + " and email=" + mobilemodel.Email + " and error is " + err.Error())
					ResponseModel.IsErr = true
					ResponseModel.Msg = err.Error()
					ResponseModel.StatusCode = http.StatusInternalServerError
					return ResponseModel
				}

				// var JwtUser clientmaster.JwtAuthMaster
				// Db.Client.Where("email=?", mobilemodel.Email).Delete(&JwtUser)
				err := deleteJwtAuthMasterDB(helper.CLIENT_EMAIL_PARAM, mobilemodel.Email)
				if err != nil {
					fmt.Println(err)
				}
				token, err := GenerateJWTWithRefresh(mobilemodel.Mobileno, mobilemodel.Email, "")
				if err != nil {
					Zerologs.Error().Msg("Add_Mobile(): Error in GenerateJWTWithRefresh for mobileno=" + mobilemodel.Mobileno + " and email=" + mobilemodel.Email + " is " + err.Error())
					ResponseModel.IsErr = true
					ResponseModel.Msg = err.Error()
					ResponseModel.StatusCode = http.StatusInternalServerError
					return ResponseModel
				}
				updateData := make(map[string]interface{})
				updateData["refreshtoken"] = token.RefreshToken
				err = updateJWTAuthMaster(helper.CLIENT_MOBILE_PARAM, mobilemodel.Mobileno, updateData)
				// err = Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", mobilemodel.Mobileno).Update("refreshtoken", token.RefreshToken).Error
				if err != nil {
					Zerologs.Error().Msg("Add_Mobile(): Error in update refreshToken in JwtAuthMaster for mobileno=" + mobilemodel.Mobileno + " and error is " + err.Error())
					ResponseModel.IsErr = true
					ResponseModel.Msg = err.Error()
					ResponseModel.StatusCode = http.StatusInternalServerError
					return ResponseModel
				}

				// var UserDetails clientmaster.JwtAuthMaster
				// err = Db.Client.Where("mobile_no=?", mobilemodel.Mobileno).First(&UserDetails).Error
				UserDetails, err := getJwtAuthMasterDB(helper.CLIENT_MOBILE_PARAM, mobilemodel.Mobileno)
				if err != nil {
					Zerologs.Error().Msg("Add_Mobile(): UserDetails not found in JwtAuthMaster for mobile = " + mobilemodel.Mobileno + " and error is " + err.Error())
					ResponseModel.IsErr = true
					ResponseModel.Msg = err.Error()
					ResponseModel.StatusCode = http.StatusInternalServerError
					return ResponseModel
				}
				if UserDetails.KYCDone {
					// if mobilemodel.Mobileno == "9673780788" {
					// 	var greenWareReq model.GreenwareRequestModel
					// 	greenWareReq.SsoBy = "mobile+user_type"
					// 	greenWareReq.Param1 = mobilemodel.Mobileno
					// 	greenWareReq.Param2 = 1
					// 	mfaccesstoken := GreenWareLoginService(greenWareReq)
					// 	if mfaccesstoken != "" {
					// 		Zerologs.Info().Msg("Add_Mobile() : User " + mobilemodel.Mobileno + " successfully login to greenware " + " AT " + time.Now().Format("2006-01-02 15:04:05"))
					// 		token["mftoken"] = mfaccesstoken
					// 	} else {
					// 		token["mftoken"] = mfaccesstoken
					// 	}
					// }
					if UserDetails.Activated {
						if !UserDetails.IsMPIN_Reset {
							ResponseModel.IsErr = false
							ResponseModel.Msg = "show setmpin screen"
							ResponseModel.StatusCode = http.StatusOK
							ResponseModel.AccessToken = token.AccessToken
							ResponseModel.RefreshToken = token.RefreshToken
							ResponseModel.Url = token.Url
							ResponseModel.IsKyc = true
							ResponseModel.IsActivated = true
							return ResponseModel
						}
						// loginModel := model.HyperLoginmodel{
						// 	UID:        UserDetails.ClientID + "-" + mobilemodel.BrokerID,
						// 	Pwd:        mobilemodel.Pwd,
						// 	BrokerID:   mobilemodel.BrokerID,
						// 	Source:     mobilemodel.Source,
						// 	DeviceName: mobilemodel.DeviceName,
						// 	DeviceInfo: mobilemodel.DeviceInfo,
						// }
						// key, IsMPINRequired, err := HypersyncLogin(loginModel)
						// if err == nil {
						// 	token["devicekey"] = key
						// 	if IsMPINRequired {
						// 		token["isKyc"] = "true"
						// 		token["isActivated"] = "true"
						// 		token["isMpinSet"] = "true"
						// 		token["url"] = "redirect to mpin login page"
						// 	}
						// }
						ResponseModel.IsErr = false
						ResponseModel.StatusCode = http.StatusOK
						ResponseModel.AccessToken = token.AccessToken
						ResponseModel.RefreshToken = token.RefreshToken
						ResponseModel.Url = token.Url
						ResponseModel.IsKyc = true
						ResponseModel.IsActivated = true
						return ResponseModel
					} else {
						ResponseModel.IsErr = false
						ResponseModel.StatusCode = http.StatusOK
						ResponseModel.AccessToken = token.AccessToken
						ResponseModel.RefreshToken = token.RefreshToken
						ResponseModel.Url = token.Url
						ResponseModel.IsKyc = true
						ResponseModel.IsActivated = false
						ResponseModel.IsPasswordSet = true
						return ResponseModel
					}
				} else {
					ResponseModel.IsErr = false
					ResponseModel.StatusCode = http.StatusOK
					ResponseModel.AccessToken = token.AccessToken
					ResponseModel.RefreshToken = token.RefreshToken
					ResponseModel.Url = token.Url
					ResponseModel.IsKyc = false
					ResponseModel.IsActivated = false
					ResponseModel.IsPasswordSet = true
					return ResponseModel
				}
			} else {
				ResponseModel.IsErr = true
				ResponseModel.Msg = "Mobile Number is already registered with same email"
				ResponseModel.StatusCode = http.StatusInternalServerError
				return ResponseModel
			}
		} else {
			ResponseModel.IsErr = true
			ResponseModel.Msg = resp.Msg
			ResponseModel.StatusCode = http.StatusInternalServerError
			return ResponseModel
		}
	}
}

// func AddMobileService_New(mobilemodel model.MobileModel) (model.AddMobileModelRes, error) {
// 	token := make(map[string]string)
// 	// res, _ := IsAlreadyRegister(mobilemodel.Mobileno)
// 	var MobEmail clientmaster.TblMobileEmailMapping
// 	err := Db.Client.Where("mobile_no=?", mobilemodel.Mobileno).First(&MobEmail).Error
// 	if err != nil {
// 		resp := Verify_OTP(mobilemodel.Mobileno, mobilemodel.OTP)
// 		if resp["Msg"] == "Success" {
// 			err = Db.Client.Where("email=?", mobilemodel.Email).First(&MobEmail).Error
// 			if err == nil {
// 				Zerologs.Info().Msg("Add_Mobile(): Email=" + mobilemodel.Email + " is already registered")
// 				token["errMsg"] = "Email is already registered"
// 				return token, nil
// 			}
// 			MobEmail.MobileNo = mobilemodel.Mobileno
// 			MobEmail.Email = mobilemodel.Email
// 			MobEmail.EmailVerified = true
// 			err = Db.Client.Create(&MobEmail).Error
// 			if err != nil {
// 				Zerologs.Error().Msg("Add_Mobile(): Error in create query for TblMobileEmailMapping for mobileno=" + mobilemodel.Mobileno + " and email=" + mobilemodel.Email + " and error is " + err.Error())
// 				return nil, err
// 			}

// 			var UserGUID uuid.UUID
// 			var guidData clientmaster.MobileGuidMaster
// 			err := Db.Client.Where("mobile_no=?", mobilemodel.Mobileno).First(&guidData).Error
// 			if err != nil {
// 				UserGUID = uuid.New()
// 				guidData.UserGuid = UserGUID
// 				guidData.MobileNo = mobilemodel.Mobileno
// 				err = Db.Client.Create(&guidData).Error
// 				if err != nil {
// 					Zerologs.Error().Msg("Add_Mobile(): Error in create query for MobileGuidMaster for mobileno=" + mobilemodel.Mobileno + " and error is " + err.Error())
// 					return nil, err
// 				}
// 			} else {
// 				UserGUID = guidData.UserGuid
// 			}
// 			UsrmobileNo := mobilemodel.Mobileno
// 			var clientdbData clientmaster.JwtAuthMaster
// 			err = Db.Client.Where("email=?", mobilemodel.Email).First(&clientdbData).Error
// 			if err == nil {
// 				sAccountcode := clientdbData.ClientID + "-" + "NIT" //Samir Pending
// 				token, err := GenerateJWTWithRefresh(UsrmobileNo, mobilemodel.Email, sAccountcode)
// 				if err != nil {
// 					Zerologs.Error().Msg("Add_Mobile(): Error in GenerateJWTWithRefresh for mobileno=" + UsrmobileNo + " and email=" + mobilemodel.Email + " is " + err.Error())
// 					return nil, err
// 				}
// 				refreshToken := token["refresh_token"]
// 				err = Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("email=?", mobilemodel.Email).Updates(clientmaster.JwtAuthMaster{MobileNo: mobilemodel.Mobileno, Password: mobilemodel.Password, UserGuid: helper.UuidToString(UserGUID), MobileVerified: true, IsPasswordReset: true, Refreshtoken: refreshToken}).Error
// 				if err != nil {
// 					Zerologs.Error().Msg("Add_Mobile(): Error in update refreshToken for email=" + mobilemodel.Email + " is " + err.Error())
// 					return nil, err
// 				}
// 				var passwordhistory clientmaster.PasswordHistory
// 				passwordhistory.MobileNo = mobilemodel.Mobileno
// 				passwordhistory.LastPassword = mobilemodel.Password
// 				passwordhistory.LastPassword_UpdatedTime = time.Now()
// 				err = Db.Client.Create(&passwordhistory).Error
// 				if err != nil {
// 					Zerologs.Error().Msg("Add_Mobile(): Error while add data in password history for mobileno=" + mobilemodel.Mobileno + " is " + err.Error())
// 					return nil, err
// 				}
// 				var jwtauthmaster clientmaster.JwtAuthMaster
// 				err = Db.Client.Where("mobile_no=?", mobilemodel.Mobileno).Find(&jwtauthmaster).Error
// 				if err != nil {
// 					Zerologs.Error().Msg("Add_Mobile(): Data not found in JwtAuthMaster for mobileno=" + mobilemodel.Mobileno + " and error is " + err.Error())
// 					return nil, err
// 				}

// 				err = AddWatchList(mobilemodel.Mobileno)
// 				if err != nil {
// 					Zerologs.Error().Msg("Add_mobile(): Watchlist not added for mobileNo: " + mobilemodel.Mobileno + err.Error())
// 					return nil, err
// 				}

// 				var socialData model.SocialModel
// 				socialData.GUID = UserGUID
// 				socialData.Mobileno = mobilemodel.Mobileno
// 				socialData.Email = mobilemodel.Email
// 				socialData.ID = jwtauthmaster.ID
// 				if jwtauthmaster.Name == "" {
// 					socialData.Name = mobilemodel.Mobileno
// 				} else {
// 					socialData.Name = jwtauthmaster.Name
// 				}
// 				socialData.Username = mobilemodel.Mobileno
// 				socialData.Password = mobilemodel.Password
// 				socialData.Avatar = ""
// 				// err = AddSociaInfo(socialData)
// 				// if err != nil {
// 				// 	Zerologs.Error().Msg("Add_mobile():Social data not added for mobileNo: " + mobilemodel.Mobileno + err.Error())
// 				// 	return
// 				// }
// 				token["isKyc"] = "false"
// 				token["isActivated"] = "false"
// 				token["isPasswordSet"] = "true"
// 				return token, nil
// 			} else {
// 				token, err := GenerateJWTWithRefresh(UsrmobileNo, mobilemodel.Email, "")
// 				if err != nil {
// 					Zerologs.Error().Msg("Add_Mobile(): Error in GenerateJWTWithRefresh for mobileno=" + UsrmobileNo + " and email=" + mobilemodel.Email + " is " + err.Error())
// 					return nil, err
// 				}
// 				refreshToken := token["refresh_token"]
// 				var usermodel model.JwtMaster
// 				usermodel.MobileNo = mobilemodel.Mobileno
// 				usermodel.Email = mobilemodel.Email
// 				usermodel.Refreshtoken = refreshToken
// 				usermodel.MobileVerified = true
// 				usermodel.Password = mobilemodel.Password
// 				usermodel.EmailVerified = true
// 				usermodel.MobileOtp = mobilemodel.OTP
// 				usermodel.UserGuid = helper.UuidToString(UserGUID)
// 				usermodel.IsPasswordReset = true
// 				_, err = AddJwtMaster(usermodel)
// 				if err != nil {
// 					Zerologs.Error().Msg("Add_Mobile(): Error while add data in JwtMaster for mobileno=" + mobilemodel.Mobileno + " and error is " + err.Error())
// 					return nil, err
// 				}
// 				var passwordhistory clientmaster.PasswordHistory
// 				passwordhistory.MobileNo = mobilemodel.Mobileno
// 				passwordhistory.LastPassword = mobilemodel.Password
// 				passwordhistory.LastPassword_UpdatedTime = time.Now()
// 				err = Db.Client.Create(&passwordhistory).Error
// 				if err != nil {
// 					Zerologs.Error().Msg("Add_Mobile(): Error while add data in password history for mobileno=" + mobilemodel.Mobileno + " is " + err.Error())
// 					return nil, err
// 				}
// 				var jwtauthmaster clientmaster.JwtAuthMaster
// 				err = Db.Client.Where("mobile_no=?", mobilemodel.Mobileno).Find(&jwtauthmaster).Error
// 				if err != nil {
// 					Zerologs.Error().Msg("Add_Mobile(): Data not found in JwtAuthMaster for mobileno=" + mobilemodel.Mobileno + " and error is " + err.Error())
// 					return nil, err
// 				}

// 				err = AddWatchList(mobilemodel.Mobileno)
// 				if err != nil {
// 					Zerologs.Error().Msg("Add_mobile(): Watchlist not added for mobileNo: " + mobilemodel.Mobileno + err.Error())
// 					return nil, err
// 				}

// 				var socialData model.SocialModel
// 				socialData.GUID = UserGUID
// 				socialData.Mobileno = mobilemodel.Mobileno
// 				socialData.Email = mobilemodel.Email
// 				socialData.ID = jwtauthmaster.ID
// 				if jwtauthmaster.Name == "" {
// 					socialData.Name = mobilemodel.Mobileno
// 				} else {
// 					socialData.Name = jwtauthmaster.Name
// 				}
// 				socialData.Username = mobilemodel.Mobileno
// 				socialData.Password = mobilemodel.Password
// 				socialData.Avatar = ""
// 				// err = AddSociaInfo(socialData)
// 				// if err != nil {
// 				// 	Zerologs.Error().Msg("Add_mobile():Social data not added for mobileNo: " + mobilemodel.Mobileno + err.Error())
// 				// 	return
// 				// }
// 				token["isKyc"] = "false"
// 				token["isActivated"] = "false"
// 				token["isPasswordSet"] = "true"
// 				return token, nil
// 			}
// 		} else {
// 			token["errMsg"] = resp["errMsg"]
// 			return token, nil
// 		}
// 	} else {
// 		resp := Verify_OTP(mobilemodel.Mobileno, mobilemodel.OTP)
// 		if resp["Msg"] == "Success" {
// 			err = Db.Client.Where("email=?", mobilemodel.Email).First(&MobEmail).Error
// 			if err != nil {
// 				var MobEmailModel clientmaster.TblMobileEmailMapping
// 				MobEmailModel.MobileNo = mobilemodel.Mobileno
// 				MobEmailModel.Email = mobilemodel.Email
// 				MobEmailModel.EmailVerified = true
// 				err = Db.Client.Create(&MobEmailModel).Error
// 				if err != nil {
// 					Zerologs.Error().Msg("Add_Mobile(): Error in create query for TblMobileEmailMapping for mobileno=" + mobilemodel.Mobileno + " and email=" + mobilemodel.Email + " and error is " + err.Error())
// 					return nil, err
// 				}

// 				var JwtUser clientmaster.JwtAuthMaster
// 				Db.Client.Where("email=?", mobilemodel.Email).Delete(&JwtUser)

// 				token, err := GenerateJWTWithRefresh(mobilemodel.Mobileno, mobilemodel.Email, "")
// 				if err != nil {
// 					Zerologs.Error().Msg("Add_Mobile(): Error in GenerateJWTWithRefresh for mobileno=" + mobilemodel.Mobileno + " and email=" + mobilemodel.Email + " is " + err.Error())
// 					return nil, err
// 				}
// 				refreshToken := token["refresh_token"]
// 				err = Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", mobilemodel.Mobileno).Update("refreshtoken", refreshToken).Error
// 				if err != nil {
// 					Zerologs.Error().Msg("Add_Mobile(): Error in update refreshToken in JwtAuthMaster for mobileno=" + mobilemodel.Mobileno + " and error is " + err.Error())
// 					return nil, err
// 				}

// 				var UserDetails clientmaster.JwtAuthMaster
// 				err = Db.Client.Where("mobile_no=?", mobilemodel.Mobileno).First(&UserDetails).Error
// 				if err != nil {
// 					Zerologs.Error().Msg("Add_Mobile(): UserDetails not found in JwtAuthMaster for mobile = " + mobilemodel.Mobileno + " and error is " + err.Error())
// 					return nil, err
// 				}
// 				if UserDetails.KYCDone {
// 					if mobilemodel.Mobileno == "9673780788" {
// 						var greenWareReq model.GreenwareRequestModel
// 						greenWareReq.SsoBy = "mobile+user_type"
// 						greenWareReq.Param1 = mobilemodel.Mobileno
// 						greenWareReq.Param2 = 1
// 						mfaccesstoken := GreenWareLoginService(greenWareReq)
// 						if mfaccesstoken != "" {
// 							Zerologs.Info().Msg("Add_Mobile() : User " + mobilemodel.Mobileno + " successfully login to greenware " + " AT " + time.Now().Format("2006-01-02 15:04:05"))
// 							token["mftoken"] = mfaccesstoken
// 						} else {
// 							token["mftoken"] = mfaccesstoken
// 						}
// 					}
// 					if UserDetails.Activated {
// 						if !UserDetails.IsMPIN_Reset {
// 							token["isKyc"] = "true"
// 							token["isActivated"] = "true"
// 							token["isMpinSet"] = "false"
// 							token["Msg"] = "show setmpin screen"
// 							return token, nil
// 						}
// 						loginModel := model.HyperLoginmodel{
// 							UID:        UserDetails.ClientID + "-" + mobilemodel.BrokerID,
// 							Pwd:        mobilemodel.Pwd,
// 							BrokerID:   mobilemodel.BrokerID,
// 							Source:     mobilemodel.Source,
// 							DeviceName: mobilemodel.DeviceName,
// 							DeviceInfo: mobilemodel.DeviceInfo,
// 						}
// 						key, IsMPINRequired, err := HypersyncLogin(loginModel)
// 						if err == nil {
// 							token["devicekey"] = key
// 							if IsMPINRequired {
// 								token["isKyc"] = "true"
// 								token["isActivated"] = "true"
// 								token["isMpinSet"] = "true"
// 								token["url"] = "redirect to mpin login page"
// 							}
// 						}
// 						return token, nil
// 					} else {
// 						token["isKyc"] = "true"
// 						token["isActivated"] = "false"
// 						token["isMpinSet"] = "false"
// 						token["isPasswordSet"] = "true"

// 						return token, nil
// 					}
// 				} else {
// 					token["isKyc"] = "false"
// 					token["isActivated"] = "false"
// 					token["isMpinSet"] = "false"
// 					token["isPasswordSet"] = "true"
// 					return token, nil
// 				}
// 			} else {
// 				token["errMsg"] = "Mobile Number is already registered with same email"
// 				return token, nil
// 			}
// 		} else {
// 			token["errMsg"] = resp["errMsg"]
// 			return token, nil
// 		}
// 	}
// }
