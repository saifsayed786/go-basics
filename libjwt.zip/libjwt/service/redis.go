package service

import (
	"fmt"
)

func getDataFromRedis(key string) (string, error) {
	val, err := RedisLib.Client.Get(key).Result()
	if err != nil {
		fmt.Println(err)
		return "", err
	}
	return val, nil
}

func setDataInRedis(key, value string, timeDuration int64) error {
	err := RedisLib.Client.Set(key, value, timeDuration).Err()
	if err != nil {
		return err
	}
	return nil
}

func deleteDataFromRedis(key string) error {
	err := RedisLib.Client.Del(key).Err()
	if err != nil {
		return err
	}
	return nil
}

func deleteRangeDataFromRedis(key, val1, val2 string) error {
	err := RedisLib.Client.ZRemRangeByScore(key, val1, val2).Err()
	if err != nil {
		return err
	}
	return nil
}
