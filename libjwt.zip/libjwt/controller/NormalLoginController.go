package controller

import (
	"net/http"

	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/model"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/contrib/sessions"
	"github.com/gin-gonic/gin"
)

func NormalLoginHandler(c *gin.Context) {
	libhttp.CoreHeader(c)
	session := sessions.Default(c)
	retrievedState := session.Get("state")
	if retrievedState == nil {
		service.Zerologs.Info().Msg("NormalLoginHandler(): RetriveState is Nil")
		return
	}
	cquery := c.Query("state")
	if retrievedState != cquery {
		//Pending
		service.Zerologs.Error().Msg("NormalLoginHandler(): retrievedState and cquery is not equal:=  " + retrievedState.(string) + " -- " + cquery)
		//c.AbortWithError(http.StatusUnauthorized, fmt.Errorf("Invalid session state: %s", retrievedState))
		//return
	}
	RedirectUrl, err := service.RedisLib.Client.Get(retrievedState.(string) + "-RedirectUrl").Result()
	if err != nil {
		service.Zerologs.Error().Msg("NormalLoginHandler(): RedirectUrl not getting from redis by using retrieved state for user mobileNo:= " + retrievedState.(string) + err.Error())
		c.JSON(http.StatusInternalServerError, "RedirectUrl null")
		return
	}
	var mobilemodel model.NormalLoginmodel
	err = c.BindJSON(&mobilemodel)
	if err != nil {
		service.Zerologs.Error().Msg("NormalLoginHandler(): Error while json binding model= " + mobilemodel.Mobileno + mobilemodel.Password + mobilemodel.UID + mobilemodel.Pwd + mobilemodel.DeviceInfo + mobilemodel.DeviceName + err.Error())
		c.JSON(http.StatusBadRequest, "")
		return
	}
	response := service.NormalLoginHandlerServicve(mobilemodel, retrievedState, RedirectUrl)
	c.JSON(response.StatusCode, response)

}

func NormalLogin(c *gin.Context) {
	libhttp.CoreHeader(c)
	var mobilemodel model.MobileLoginModel
	err := c.BindJSON(&mobilemodel)
	if err != nil {
		service.Zerologs.Error().Msg("NormalLogin(): Error in c.BindJSON is " + err.Error())
		c.JSON(http.StatusBadRequest, "")
		return
	}
	response, err := service.NormalLoginService(mobilemodel)
	if err != nil {
		c.JSON(http.StatusInternalServerError, err.Error())
		return
	}
	result, ok := response["errMsg"]
	if ok {
		c.JSON(500, result)
		return
	}
	c.JSON(200, response)

}
