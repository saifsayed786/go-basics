package model

type SSBAModel struct {
	Country string `json:"country"`
	Pincode string `json:"pincode"`
	Address string `json:"address"`
	Phone   string `json:"phone"`
	City    string `json:"city"`
	Name    string `json:"name"`
	State   string `json:"state"`
	Email   string `json:"email"`
}
