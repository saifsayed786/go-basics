package controller

import (
	"github.com/gin-gonic/gin"
)

func Register(c *gin.Context) {
	// libhttp.CoreHeader(c)
	// session := sessions.Default(c)
	// retrievedState := session.Get("state")
	// if retrievedState == nil {
	// 	service.Zerologs.Info().Msg("Register(): RetriveState is Nil")
	// 	return
	// }
	// RetriveState := retrievedState.(string)
	// cquery := c.Query("state")
	// if retrievedState != cquery {
	// 	//Pending
	// 	//c.AbortWithError(http.StatusUnauthorized, fmt.Errorf("Invalid session state: %s", retrievedState))
	// 	//return
	// }
	// RedirectUrl, err := service.RedisLib.Client.Get(retrievedState.(string) + "-RedirectUrl").Result()
	// if err != nil {
	// 	service.Zerologs.Error().Msg("Register(): RedirectUrl not getting from redis by using retrieved state for user mobileNo:= " + retrievedState.(string) + err.Error())
	// 	c.JSON(http.StatusInternalServerError, "RedirectUrl null")
	// 	return
	// }
	// var usermodel model.JwtMaster
	// if err := c.BindJSON(&usermodel); err != nil {
	// 	service.Zerologs.Error().Msg("Register(): Error while json binding model= " + usermodel.MobileNo + usermodel.MobileOtp + usermodel.Password + usermodel.Email + err.Error())
	// 	c.JSON(http.StatusBadRequest, "")
	// 	return
	// }
	// response, err := service.RegisterService(RetriveState, RedirectUrl, usermodel)
	// if err != nil {
	// 	c.JSON(500, err)
	// 	return
	// }
	// result, ok := response["errMsg"]
	// if ok {
	// 	c.JSON(500, result)
	// 	return
	// }
	// c.JSON(200, response)

}
