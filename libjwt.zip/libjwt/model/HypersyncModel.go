package model

type HypersyncModel struct {
	Uid      string `json:"uid"`
	BrokerId string `json:"brokerId"`
	System   string `json:"system"`
}

type HyperSyncReqModel struct {
	SystemName    string `json:"systemName"`
	EncryptedData string `json:"encryptedData"`
}

type HyperResModel struct {
	Status string `json:"status"`
	Code   int    `json:"code"`
	Data   struct {
		Status     string `json:"status"`
		SessionKey string `json:"sessionKey"`
		Server     string `json:"server"`
	} `json:"data"`
}

type HyperErrResModel struct {
	Status  string `json:"status"`
	Code    int    `json:"code"`
	Message string `json:"message"`
}
