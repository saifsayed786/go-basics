package controller

import (
	"net/http"
	"strconv"

	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/model"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/gin"
)

func ChangeMpin(c *gin.Context) {
	libhttp.CoreHeader(c)
	mobile_no, err := service.GetUser(c)
	if err != nil {
		service.Zerologs.Error().Err(err).Msg("ChangeMpin(): Unauthorized")
		c.JSON(http.StatusUnauthorized, "Unauthorized")
		return
	}
	MobileNo := strconv.FormatUint(uint64(mobile_no), 10)

	var changempin model.ChangeMpin
	err = c.BindJSON(&changempin)
	if err != nil {
		// fmt.Println("Bind Data Failed")
		service.Zerologs.Error().Msg("ChangeMpin(): Error in c.BindJSON is " + err.Error())
		c.JSON(http.StatusBadRequest, err)
		return
	}
	response, err := service.ChangeMPINService(MobileNo, changempin)
	if err != nil {
		c.JSON(http.StatusInternalServerError, err.Error())
		return
	}
	result, ok := response["errMsg"]
	if ok {
		c.JSON(500, result)
		return
	}
	c.JSON(200, response)

}
