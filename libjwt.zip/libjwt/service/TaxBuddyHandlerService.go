package service

import (
	"bytes"
	"encoding/json"
	"io/ioutil"
	"net/http"
	"strconv"

	"github.com/MACMREPO/libjwt/model"
)

func TaxBuddyHandlerService(SsbaModel model.SSBAModel) (model.TaxBuddyResponse, error) {
	var TaxapiResponse model.TaxBuddyResponse
	request, err := json.Marshal(SsbaModel)
	if err != nil {
		Zerologs.Error().Msg("TaxBuddyHandler(): Error while marshalling SSBAModel: " + err.Error())
		// c.JSON(http.StatusInternalServerError, "")
		return TaxapiResponse, err
	}
	jsonrequest := string(request)
	ecrptAuthToken := Encrypt(jsonrequest, Env.TB_SECRET_KEY, Env.TB_SECRETIV_KEY)
	expireTokenTimeInmilli := strconv.Itoa(3000)
	taxBuddyUrl := "https://uat-api.finbingo.com/user/v1/partner-clients/token?authToken=" + ecrptAuthToken + "&tokenValidityInMillisec=" + expireTokenTimeInmilli
	reqeust, err := http.NewRequest("GET", taxBuddyUrl, bytes.NewBuffer(request))
	if err != nil {
		Zerologs.Error().Msg("TaxBuddyHandler(): failed to build taxBuddy request: " + err.Error())
		return TaxapiResponse, err
	}
	reqeust.Header.Set("Content-Type", "application/json")
	reqeust.Header.Set("partner_id", Env.TB_PARTNERID_KEY)
	clients := &http.Client{}
	resp, err := clients.Do(reqeust)
	if err != nil {
		Zerologs.Error().Msg("TaxBuddyHandler():Taxbuddy HTTP call failed , url:=  " + taxBuddyUrl + err.Error())
		return TaxapiResponse, err
	}
	defer resp.Body.Close()
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		//Failed to read response.
		Zerologs.Error().Msg("TaxBuddyHandler():Failed to read Taxbuddy call response.: " + err.Error())
		return TaxapiResponse, err
	}
	//Convert bytes to Response model and return

	err = json.Unmarshal(body, &TaxapiResponse)
	if err != nil {
		Zerologs.Error().Msg("TaxBuddyHandler(): Failed to unmarshal taxbuddy response into TaxBuddyResponse model " + err.Error())
		return TaxapiResponse, err
	}
	return TaxapiResponse, nil
}
