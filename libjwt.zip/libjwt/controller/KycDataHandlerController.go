package controller

import (
	"github.com/gin-gonic/gin"
)

func KycDataHandler(c *gin.Context) {
	// libhttp.CoreHeader(c)
	// var UserDataModel clientmaster.JwtAuthMaster
	// if err := c.BindJSON(&UserDataModel); err != nil {
	// 	service.Zerologs.Error().Msg("KycDataHandler(): Error in c.BindJSON is " + err.Error())
	// 	c.JSON(http.StatusInternalServerError, err)
	// 	return
	// }
	// response, err := service.KycDataHandlerService(UserDataModel)
	// if err != nil {
	// 	c.JSON(500, err.Error())
	// 	return
	// }
	// result, ok := response["errMsg"]
	// if ok {
	// 	c.JSON(500, result)
	// 	return
	// }
	// c.JSON(200, response)
}
