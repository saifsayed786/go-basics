package controller

import (
	"chartdataservice/models"

	"github.com/TecXLab/liblogs"
	"github.com/gin-gonic/gin"
	"github.com/golobby/container/v3"
	"github.com/rs/zerolog"
)

func MarketStatusController(c *gin.Context) {
	var zerologs zerolog.Logger
	err := container.NamedResolve(&zerologs, "zerologs")
	if err != nil {
		Logger("Log Lib Not Initialize", err, liblogs.Error, liblogs.ZEROLOG)
	}
	var request models.NSEMarketStatusModel
	err = c.ShouldBindJSON(&request)
	if err != nil {
		Logger("Message: ", err, liblogs.Error, liblogs.PRINT)

		return
	}
	// service.SaveHistory(request)
	Logger("Exiting SaveChartHistory Controller", nil, liblogs.Info, liblogs.ZEROLOG)

}
