package service

import (
	"bytes"
	"encoding/base64"
	"image/png"

	"github.com/MACMREPO/libdb/clientmaster"
	"github.com/pquerna/otp/totp"
)

func GenerateTotpSecret(email string) (string, string, error) {
	key, err := totp.Generate(totp.GenerateOpts{
		Issuer:      "nuuu.com",
		AccountName: email,
	})
	if err != nil {
		// panic(err)
		return "nil", "nil", err
	}
	var buf bytes.Buffer
	img, err := key.Image(200, 200)
	if err != nil {
		return "nil", "nil", err
		// panic(err)
	}
	png.Encode(&buf, img)
	secretKey := key.Secret()
	imgBase64Str := base64.StdEncoding.EncodeToString(buf.Bytes())
	// totptemplate := strings.Replace(TOTPTemplate, "<PNGDATA>", imgBase64Str, 1)
	// totptemplate = strings.Replace(totptemplate, "<Secret>", secretKey, 1)
	err = Db.Client.Model(&clientmaster.TblMobileEmailMapping{}).Where("email=?", email).Update("totp_secret_key", secretKey).Error
	if err != nil {
		Zerologs.Error().Msg("GenerateTotpSecret(): secret key update query failed where email:=  " + email + err.Error())
		return "nil", "nil", err
	}
	return imgBase64Str, secretKey, nil
	//display(key, buf.Bytes())
	//c.JSON(http.StatusOK, "")
}
