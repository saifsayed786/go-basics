package service

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"io/ioutil"
	"net/http"

	"github.com/MACMREPO/libjwt/model"
)

func GreenWareLoginService(LoginData model.GreenwareRequestModel) string {
	jsonStr, err := json.Marshal(&LoginData)
	if err != nil {
		Zerologs.Error().Err(err).Msg("GreenWareLogin(): Error While marshalling model")
		return err.Error()
	}
	byteJson := make([]byte, base64.StdEncoding.EncodedLen(len(jsonStr)))
	base64.StdEncoding.Encode(byteJson, jsonStr)
	var ENcrModel model.GreenwareEncrReq
	ENcrModel.EncrInput = string(byteJson)
	byteEcr, err := json.Marshal(&ENcrModel)
	if err != nil {
		Zerologs.Error().Err(err).Msg("GreenWareLogin(): Error While json.Marshal(&ENcrModel)")
		return err.Error()
	}
	// url := "https://fundcore-nu.azurewebsites.net/api/sso/v1/for-acc-tkn"
	url := "http://192.168.5.170:8087/api/sso/v1/for-acc-tkn"
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(byteEcr))
	if err != nil {
		Zerologs.Error().Err(err).Msgf("GreenWareLogin():Error While Sending POST Request %s", url)
		return err.Error()
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("ClientKey", "nu_investor")
	req.Header.Set("SsoV1ApiKey", "uim#zYtj$lM4C@rD3h")
	client := &http.Client{}
	rep, err := client.Do(req)
	if err != nil {
		Zerologs.Error().Err(err).Msgf("GreenWareLogin():Error in client.Do(req)", url)
		return err.Error()
	}
	var GreenwareResp model.GreenwareResponse
	if rep.StatusCode == http.StatusOK {
		defer rep.Body.Close()
		response, err := ioutil.ReadAll(rep.Body)
		if err != nil {
			Zerologs.Error().Err(err).Msg("GreenWareLogin():Error While ioutil.ReadAll(rep.Body)")
			return err.Error()
		}
		err = json.Unmarshal(response, &GreenwareResp)
		if err != nil {
			Zerologs.Error().Err(err).Msg("GreenWareLogin():Error While ioutil.ReadAll(rep.Body)")
			return err.Error()
		}
		return GreenwareResp.AccessToken
	} else {
		Zerologs.Info().Msg("GreenWareLogin()= Unauthorized User MobileNO= " + LoginData.Param1)
		GreenwareResp.AccessToken = ""
		return GreenwareResp.AccessToken
	}
}

func GreenWareAccessTokenService(GreenwareData model.GreenwareRequestModel) (string, error) {
	jsonStr, err := json.Marshal(&GreenwareData)
	if err != nil {
		Zerologs.Error().Err(err).Msg("GreenWareAccessToken(): Error While marshalling model")
		return err.Error(), err
	}

	dst := make([]byte, base64.StdEncoding.EncodedLen(len(jsonStr)))
	base64.StdEncoding.Encode(dst, jsonStr)
	var ENcrModel model.GreenwareEncrReq
	ENcrModel.EncrInput = string(dst)
	byteEcr, err := json.Marshal(&ENcrModel)
	if err != nil {
		Zerologs.Error().Err(err).Msg("GreenWareAccessToken(): Error While json.Marshal(&ENcrModel)")

		return err.Error(), err
	}
	url := Env.GW_URL // as discuss with amey sir, url value set.
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(byteEcr))
	if err != nil {
		Zerologs.Error().Err(err).Msgf("GreenWareAccessToken():Error While Sending POST Request %s", url)

		return err.Error(), err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("ClientKey", "nu_investor")
	req.Header.Set("SsoV1ApiKey", Env.GW_KEY)
	client := &http.Client{}
	rep, err := client.Do(req)
	if err != nil {
		Zerologs.Error().Err(err).Msgf("GreenWareAccessToken():Error in client.Do(req)", url)

		return err.Error(), err
	}
	defer rep.Body.Close()
	response, err := ioutil.ReadAll(rep.Body)
	if err != nil {
		Zerologs.Error().Err(err).Msg("GreenWareAccessToken():Error While ioutil.ReadAll(rep.Body)")

		return err.Error(), err
	}
	var GreenwareResp model.GreenwareResponse
	err = json.Unmarshal(response, &GreenwareResp)
	if err != nil {
		Zerologs.Error().Err(err).Msg("GreenWareAccessToken():Error While Unmarshalling model.GreenwareResponse")
		return err.Error(), err
	}
	return GreenwareResp.AccessToken, nil

}
