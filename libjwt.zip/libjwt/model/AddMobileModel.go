package model

type AddMobileResponseModel struct {
	IsErr         bool   `json:"isErr"`
	Msg           string `json:"msg"`
	AccessToken   string `json:"access_token,omitempty"`
	RefreshToken  string `json:"refresh_token,omitempty"`
	Url           string `json:"url,omitempty"`
	StatusCode    int    `json:"statusCode"`
	IsKyc         bool   `json:"isKyc,omitempty"`
	IsActivated   bool   `json:"isActivated,omitempty"`
	IsPasswordSet bool   `json:"isPasswordSet,omitempty"`
}
