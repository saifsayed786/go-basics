package models

type ChartRequestModel struct {
	Timestamp  uint64 `json:"TimeStamp"`
	Symbol     string `json:"Symbol"`
	Resolution string `json:"Resolution"`
	Id         string `json:"Id"`
	Name       string `json:"Name"`
}

type DeleteChartModel struct {
	Timestamp  uint64 `json:"TimeStamp"`
	Symbol     string `json:"Symbol"`
	Resolution string `json:"Resolution"`
	Id         int    `json:"Id"`
	Name       string `json:"Name"`
}

type ChartIDWiseModel struct {
	Name       string `json:"name"`
	Content    string `json:"content"`
	Symbol     string `json:"symbol"`
	Resolution string `json:"resolution"`
}
