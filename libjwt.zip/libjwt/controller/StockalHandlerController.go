package controller

import (
	"net/http"

	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/model"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/gin"
)

func StockalHandler(c *gin.Context) {
	libhttp.CoreHeader(c)
	var stockalreq model.StockalRequest
	if err := c.BindJSON(&stockalreq); err != nil {
		service.Zerologs.Error().Msg("StockalHandler(): Error c.BindJSON stockalreq model " + err.Error())
		c.JSON(http.StatusBadRequest, err)
		return
	}
	response, err := service.StockalHandlerService(stockalreq)
	if err != nil {
		c.JSON(http.StatusInternalServerError, err)
		return
	}
	c.JSON(http.StatusOK, response)
}
