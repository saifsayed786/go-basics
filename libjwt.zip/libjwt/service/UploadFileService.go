package service

import (
	"bytes"
	"net/http"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/s3"
)

func uploadFile(session *session.Session, fileBuffer []byte, filename string) error {
	_, err := s3.New(session).PutObject(&s3.PutObjectInput{
		Bucket:               aws.String(Env.AWS_S3_BUCKET),
		Key:                  aws.String("gojwt/image/" + filename),
		ACL:                  aws.String("public-read"),
		Body:                 bytes.NewReader(fileBuffer),
		ContentLength:        aws.Int64(int64(len(fileBuffer))),
		ContentType:          aws.String(http.DetectContentType(fileBuffer)),
		ContentDisposition:   aws.String("inline"),
		ServerSideEncryption: aws.String("AES256"),
	})
	return err
}
