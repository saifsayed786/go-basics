package controller

import (
	"fmt"

	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/helper"
	"github.com/gin-gonic/contrib/sessions"
	"github.com/gin-gonic/gin"
)

func RegisterTempController(c *gin.Context) {
	libhttp.CoreHeader(c)
	session := sessions.Default(c)
	retrievedState := session.Get("state")
	cquery := c.Query("state")
	fmt.Println("state = " + cquery)
	fmt.Println("retrievedState = " + retrievedState.(string))

	if retrievedState != cquery {
		fmt.Println(retrievedState.(string) + " -- " + cquery)
		// c.AbortWithError(http.StatusUnauthorized, fmt.Errorf("Invalid session state: %s", retrievedState))
		// return
	}
	// state = randToken()
	// session := sessions.Default(c)
	c.Writer.Write(helper.RegisterTemplate)
}
