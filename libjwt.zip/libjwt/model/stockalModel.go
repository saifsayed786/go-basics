package model

type StockalRequest struct {
	MobileNo   string `json:"mobileno"`
	CustomerId string `json:"customerId"`
	Exchange   string `json:"exchange"`
}
