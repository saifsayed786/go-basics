package model

type ForgetPassword struct {
	MobileNo string `json:"mobile_no"`
	Email    string `json:"email"`
	OTP      string `json:"otp"`
	Pan      string `json:"pan"`
}

type UnblockUser struct {
	MobileNo string `json:"mobile_no"`
	Email    string `json:"email"`
	OTP      string `json:"otp"`
	Pan      string `json:"pan"`
}

type ForgotMPin struct {
	MobileNo string `json:"mobile_no"`
	Email    string `json:"email"`
	OTP      string `json:"otp"`
	Pan      string `json:"pan"`
}

type UnblockUserResponse struct {
	IsErr      bool   `json:"isErr"`
	Msg        string `json:"msg"`
	StatusCode int    `json:"statusCode"`
	Url        string `json:"url,omitempty"`
}

type ForgotPasswordResponseModel struct {
	IsErr        bool   `json:"isErr"`
	Msg          string `json:"msg"`
	StatusCode   int    `json:"statusCode"`
	Img64        string `json:"img64,omitempty"`
	IsOtp        string `json:"isOtp,omitempty"`
	OtpCnt       string `json:"otpCnt,omitempty"`
	AccessToken  string `json:"access_token,omitempty"`
	RefreshToken string `json:"refresh_token,omitempty"`
	Url          string `json:"url,omitempty"`
}
