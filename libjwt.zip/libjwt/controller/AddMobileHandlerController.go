package controller

import (
	"net/http"

	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/model"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/contrib/sessions"
	"github.com/gin-gonic/gin"
)

func AddMobileHandler(c *gin.Context) {
	libhttp.CoreHeader(c)
	session := sessions.Default(c)
	retrievedState := session.Get("state")
	if retrievedState == nil {
		service.Zerologs.Info().Msg("AddMobileHandler(): RetriveState is Nil")
		return
	}
	cquery := c.Query("state")
	if retrievedState != cquery {
		//Pending
		service.Zerologs.Error().Msg("AddMobileHandler(): retrievedState and cquery is not equal:=  " + retrievedState.(string) + " -- " + cquery)
		//c.AbortWithError(http.StatusUnauthorized, fmt.Errorf("Invalid session state: %s", retrievedState))
		//return
	}
	var mobilemodel model.MobileModel
	err := c.BindJSON(&mobilemodel)
	if err != nil {
		service.Zerologs.Error().Msg("AddMobileHandler(): Error while json binding model= " + mobilemodel.Mobileno + mobilemodel.OTP + mobilemodel.Password + mobilemodel.UID + mobilemodel.Pwd + mobilemodel.DeviceInfo + mobilemodel.DeviceName + err.Error())
		c.JSON(http.StatusBadRequest, "")
		return
	}
	RetrievedState := retrievedState.(string)

	response := service.AddMobileHandlerService(RetrievedState, mobilemodel)
	c.JSON(response.StatusCode, response)
}
