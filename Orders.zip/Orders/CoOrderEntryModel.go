package model

type CoOrderEntryModel struct {
	UserType         string `json:"user_type,omitempty"`
	OfflineFlag      string `json:"offline_flag,omitempty"`
	Disclosequantity string `json:"disclosequantity,omitempty"`
	FTriggerPrice2   string `json:"fTriggerPrice2,omitempty"`
	TokenID          string `json:"token_id,omitempty"`
	Securityid       string `json:"securityid,omitempty"`
	INoOfLeg         string `json:"iNoOfLeg,omitempty"`
	Productlist      string `json:"productlist,omitempty"`
	InstType         string `json:"inst_type,omitempty"`
	Buysell          string `json:"buysell,omitempty"`
	Price            string `json:"price,omitempty"`
	Source           string `json:"source,omitempty"`
	OrderValidity    string `json:"order_validity,omitempty"`
	UserID           string `json:"user_id,omitempty"`
	Quantity         string `json:"quantity,omitempty"`
	ClientID         string `json:"client_id,omitempty"`
	Exchange         string `json:"exchange,omitempty"`
	OrderType        string `json:"order_type,omitempty"`
	MarketProflag    string `json:"marketProflag,omitempty"`
	MarketProVal     string `json:"marketProVal,omitempty"`
	ParticipantType  string `json:"ParticipantType,omitempty"`
	Settlor          string `json:"settlor,omitempty"`
	Gtcflag          string `json:"Gtcflag,omitempty"`
	EncashFlag       string `json:"EncashFlag,omitempty"`
	PanID            string `json:"pan_id,omitempty"`
	Algoid           string `json:"algoid,omitempty"`
	Remark1          string `json:"remark1,omitempty"`
	Remarks2         string `json:"remarks2,omitempty"`
}
