package helper

import "golang.org/x/oauth2"

var (
	Lefttemplate        string
	Righttemplate       string
	Mobiletemplate      []byte
	Redirecttemplate    []byte
	Mpintemplate        []byte
	SetMpintemplate     []byte
	RegisterTemplate    []byte
	ForgetPassTemplate  []byte
	SetPasswordTemplate []byte
	UnblockUsrTemplate  []byte
	SetMpinTemplate     []byte
	TOTPTemplate        string
	TOTP_Template       []byte
	ForgotMpinTemplate  []byte
	BlockUsertemplate   []byte
	Conf                *oauth2.Config
)

//
// Summary:
//     The URI for a claim that specifies the actor, http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor.
const Actor = "http://schemas.xmlsoap.org/ws/2009/09/identity/claims/actor"

//
// Summary:
//     The URI for a claim that specifies the anonymous user; http://schemas.xmlsoap.org/ws/2005/05/identity/claims/anonymous.
const Anonymous = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/anonymous"

//
// Summary:
//     The URI for a claim that specifies details about whether an identity is authenticated,
//     http://schemas.xmlsoap.org/ws/2005/05/identity/claims/authenticated.
const Authentication = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/authentication"

//
// Summary:
//     The URI for a claim that specifies the instant at which an entity was authenticated;
//     http://schemas.microsoft.com/ws/2008/06/identity/claims/authenticationinstant.
const AuthenticationInstant = "http://schemas.microsoft.com/ws/2008/06/identity/claims/authenticationinstant"

//
// Summary:
//     The URI for a claim that specifies the method with which an entity was authenticated;
//     http://schemas.microsoft.com/ws/2008/06/identity/claims/authenticationmethod.
const AuthenticationMethod = "http://schemas.microsoft.com/ws/2008/06/identity/claims/authenticationmethod"

//
// Summary:
//     The URI for a claim that specifies an authorization decision on an entity; http://schemas.xmlsoap.org/ws/2005/05/identity/claims/authorizationdecision.
const AuthorizationDecision = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/authorizationdecision"

//
// Summary:
//     The URI for a claim that specifies the cookie path; http://schemas.microsoft.com/ws/2008/06/identity/claims/cookiepath.
const CookiePath = "http://schemas.microsoft.com/ws/2008/06/identity/claims/cookiepath"

//
// Summary:
//     The URI for a claim that specifies the country/region in which an entity resides,
//     http://schemas.xmlsoap.org/ws/2005/05/identity/claims/country.
const Country = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/country"

//
// Summary:
//     The URI for a claim that specifies the date of birth of an entity, http://schemas.xmlsoap.org/ws/2005/05/identity/claims/dateofbirth.
const DateOfBirth = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/dateofbirth"

//
// Summary:
//     The URI for a claim that specifies the deny-only primary group SID on an entity;
//     http://schemas.microsoft.com/ws/2008/06/identity/claims/denyonlyprimarygroupsid.
//     A deny-only SID denies the specified entity to a securable object.
const DenyOnlyPrimaryGroupSid = "http://schemas.microsoft.com/ws/2008/06/identity/claims/denyonlyprimarygroupsid"

//
// Summary:
//     The URI for a claim that specifies the deny-only primary SID on an entity; http://schemas.microsoft.com/ws/2008/06/identity/claims/denyonlyprimarysid.
//     A deny-only SID denies the specified entity to a securable object.
const DenyOnlyPrimarySid = "http://schemas.microsoft.com/ws/2008/06/identity/claims/denyonlyprimarysid"

//
// Summary:
//     The URI for a claim that specifies a deny-only security identifier (SID) for
//     an entity, http://schemas.xmlsoap.org/ws/2005/05/identity/claims/denyonlysid.
//     A deny-only SID denies the specified entity to a securable object.
const DenyOnlySid = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/denyonlysid"

//
// Summary:
//     The URI for a claim that specifies the Windows deny-only group SID of the device,
//     http://schemas.microsoft.com/ws/2008/06/identity/claims/denyonlywindowsdevicegroup.
const DenyOnlyWindowsDeviceGroup = "http://schemas.microsoft.com/ws/2008/06/identity/claims/denyonlywindowsdevicegroup"

//
// Summary:
//     The URI for a claim that specifies the DNS name associated with the computer
//     name or with the alternative name of either the subject or issuer of an X.509
//     certificate, http://schemas.xmlsoap.org/ws/2005/05/identity/claims/dns.
const Dns = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/dns"

//
// Summary:
//     http://schemas.microsoft.com/ws/2008/06/identity/claims/dsa.
const Dsa = "http://schemas.microsoft.com/ws/2008/06/identity/claims/dsa"

//
// Summary:
//     The URI for a claim that specifies the email address of an entity, http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress.
const Email = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress"

//
// Summary:
//     http://schemas.microsoft.com/ws/2008/06/identity/claims/expiration.
const Expiration = "http://schemas.microsoft.com/ws/2008/06/identity/claims/expiration"

//
// Summary:
//     http://schemas.microsoft.com/ws/2008/06/identity/claims/expired.
const Expired = "http://schemas.microsoft.com/ws/2008/06/identity/claims/expired"

//
// Summary:
//     The URI for a claim that specifies the gender of an entity, http://schemas.xmlsoap.org/ws/2005/05/identity/claims/gender.
const Gender = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/gender"

//
// Summary:
//     The URI for a claim that specifies the given name of an entity, http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname.
const GivenName = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname"

//
// Summary:
//     The URI for a claim that specifies the SID for the group of an entity, http://schemas.microsoft.com/ws/2008/06/identity/claims/groupsid.
const GroupSid = "http://schemas.microsoft.com/ws/2008/06/identity/claims/groupsid"

//
// Summary:
//     The URI for a claim that specifies a hash value, http://schemas.xmlsoap.org/ws/2005/05/identity/claims/hash.
const Hash = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/hash"

//
// Summary:
//     The URI for a claim that specifies the home phone number of an entity, http://schemas.xmlsoap.org/ws/2005/05/identity/claims/homephone.
const HomePhone = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/homephone"

//
// Summary:
//     http://schemas.microsoft.com/ws/2008/06/identity/claims/ispersistent.
const IsPersistent = "http://schemas.microsoft.com/ws/2008/06/identity/claims/ispersistent"

//
// Summary:
//     The URI for a claim that specifies the locale in which an entity resides, http://schemas.xmlsoap.org/ws/2005/05/identity/claims/locality.
const Locality = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/locality"

//
// Summary:
//     The URI for a claim that specifies the mobile phone number of an entity, http://schemas.xmlsoap.org/ws/2005/05/identity/claims/mobilephone.
const MobilePhone = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/mobilephone"

//
// Summary:
//     The URI for a claim that specifies the name of an entity, http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name.
const Name = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name"

//
// Summary:
//     The URI for a claim that specifies the name of an entity, http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier.
const NameIdentifier = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier"

//
// Summary:
//     The URI for a claim that specifies the alternative phone number of an entity,
//     http://schemas.xmlsoap.org/ws/2005/05/identity/claims/otherphone.
const OtherPhone = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/otherphone"

//
// Summary:
//     The URI for a claim that specifies the postal code of an entity, http://schemas.xmlsoap.org/ws/2005/05/identity/claims/postalcode.
const PostalCode = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/postalcode"

//
// Summary:
//     The URI for a claim that specifies the primary group SID of an entity, http://schemas.microsoft.com/ws/2008/06/identity/claims/primarygroupsid.
const PrimaryGroupSid = "http://schemas.microsoft.com/ws/2008/06/identity/claims/primarygroupsid"

//
// Summary:
//     The URI for a claim that specifies the primary SID of an entity, http://schemas.microsoft.com/ws/2008/06/identity/claims/primarysid.
const PrimarySid = "http://schemas.microsoft.com/ws/2008/06/identity/claims/primarysid"

//
// Summary:
//     The URI for a claim that specifies the role of an entity, http://schemas.microsoft.com/ws/2008/06/identity/claims/role.
const Role = "http://schemas.microsoft.com/ws/2008/06/identity/claims/role"

//
// Summary:
//     The URI for a claim that specifies an RSA key, http://schemas.xmlsoap.org/ws/2005/05/identity/claims/rsa.
const Rsa = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/rsa"

//
// Summary:
//     The URI for a claim that specifies a serial number, http://schemas.microsoft.com/ws/2008/06/identity/claims/serialnumber.
const SerialNumber = "http://schemas.microsoft.com/ws/2008/06/identity/claims/serialnumber"

//
// Summary:
//     The URI for a claim that specifies a security identifier (SID), http://schemas.xmlsoap.org/ws/2005/05/identity/claims/sid.
const Sid = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/sid"

//
// Summary:
//     The URI for a claim that specifies a service principal name (SPN) claim, http://schemas.xmlsoap.org/ws/2005/05/identity/claims/spn.
const Spn = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/spn"

//
// Summary:
//     The URI for a claim that specifies the state or province in which an entity resides,
//     http://schemas.xmlsoap.org/ws/2005/05/identity/claims/stateorprovince.
const StateOrProvince = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/stateorprovince"

//
// Summary:
//     The URI for a claim that specifies the street address of an entity, http://schemas.xmlsoap.org/ws/2005/05/identity/claims/streetaddress.
const StreetAddress = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/streetaddress"

//
// Summary:
//     The URI for a claim that specifies the surname of an entity, http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname.
const Surname = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname"

//
// Summary:
//     The URI for a claim that identifies the system entity, http://schemas.xmlsoap.org/ws/2005/05/identity/claims/system.
const System = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/system"

//
// Summary:
//     The URI for a claim that specifies a thumbprint, http://schemas.xmlsoap.org/ws/2005/05/identity/claims/thumbprint.
//     A thumbprint is a globally unique SHA-1 hash of an X.509 certificate.
const Thumbprint = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/thumbprint"

//
// Summary:
//     The URI for a claim that specifies a user principal name (UPN), http://schemas.xmlsoap.org/ws/2005/05/identity/claims/upn.
const Upn = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/upn"

//
// Summary:
//     The URI for a claim that specifies a URI, http://schemas.xmlsoap.org/ws/2005/05/identity/claims/uri.
const Uri = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/uri"

//
// Summary:
//     The URI for a claim that specifies the user data, http://schemas.microsoft.com/ws/2008/06/identity/claims/userdata.
const UserData = "http://schemas.microsoft.com/ws/2008/06/identity/claims/userdata"

//
// Summary:
//     The URI for a claim that specifies the version, http://schemas.microsoft.com/ws/2008/06/identity/claims/version.
const Version = "http://schemas.microsoft.com/ws/2008/06/identity/claims/version"

//
// Summary:
//     The URI for a claim that specifies the webpage of an entity, http://schemas.xmlsoap.org/ws/2005/05/identity/claims/webpage.
const Webpage = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/webpage"

//
// Summary:
//     The URI for a claim that specifies the Windows domain account name of an entity,
//     http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsaccountname.
const WindowsAccountName = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsaccountname"

//
// Summary:
//     http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsdeviceclaim.
const WindowsDeviceClaim = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsdeviceclaim"

//
// Summary:
//     The URI for a claim that specifies the Windows group SID of the device, http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsdevicegroup.
const WindowsDeviceGroup = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsdevicegroup"

//
// Summary:
//     http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsfqbnversion.
const WindowsFqbnVersion = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsfqbnversion"

//
// Summary:
//     http://schemas.microsoft.com/ws/2008/06/identity/claims/windowssubauthority.
const WindowsSubAuthority = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowssubauthority"

//
// Summary:
//     http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsuserclaim.
const WindowsUserClaim = "http://schemas.microsoft.com/ws/2008/06/identity/claims/windowsuserclaim"

//
// Summary:
//     The URI for an X.500 distinguished name claim, such as the subject of an X.509
//     Public Key Certificate or an entry identifier in a directory services Directory
//     Information Tree; http://schemas.xmlsoap.org/ws/2005/05/identity/claims/x500distinguishedname.
const X500DistinguishedName = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/x500distinguishedname"

const (
	CLIENT_MOBILE_PARAM = iota + 1
	CLIENT_EMAIL_PARAM
	CLIENT_ID_PARAM
	CLIENT_PASSWORD_PARAM
	CLIENT_USERGUID
)
