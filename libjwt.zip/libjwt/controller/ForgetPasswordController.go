package controller

import (
	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/model"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/contrib/sessions"
	"github.com/gin-gonic/gin"
)

func ForgetPassword(c *gin.Context) {
	libhttp.CoreHeader(c)
	session := sessions.Default(c)
	retrievedState := session.Get("state")
	if retrievedState == nil {
		service.Zerologs.Info().Msg("ForgetPassword(): RetriveState is Nil")
		return
	}
	// RetriveState := retrievedState.(string)
	cquery := c.Query("state")
	if retrievedState != cquery {
		//Pending
		//c.AbortWithError(http.StatusUnauthorized, fmt.Errorf("Invalid session state: %s", retrievedState))
		//return
	}
	RetriveState := retrievedState.(string)
	var forgetpassword model.ForgetPassword
	if err := c.BindJSON(&forgetpassword); err != nil {
		service.Zerologs.Error().Msg("ForgetPassword(): Error c.BindJSON forgetpassword model " + err.Error())
		return
	}
	response := service.ForgetPassword(RetriveState, forgetpassword)
	c.JSON(response.StatusCode, response)

}
