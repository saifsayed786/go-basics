package service

import (
	"net/http"
	"time"

	"github.com/MACMREPO/libdb/clientmaster"
	"github.com/MACMREPO/libjwt/helper"
	"github.com/MACMREPO/libjwt/model"
)

func NewPasswordMobile(MobileNo string, newpassword model.New_Password) model.NewPasswordResponse {
	var responseModel model.NewPasswordResponse
	// var passwordhistory []clientmaster.PasswordHistory
	// Db.Client.Where("mobile_no=?", MobileNo).Last(&passwordhistory).Limit(3)
	passwordhistory, _ := findPasswordHistoryLimit(helper.CLIENT_MOBILE_PARAM, MobileNo)
	if len(passwordhistory) == 0 {
		responseModel.IsErr = true
		responseModel.Msg = "New_Password(): Data not found in PasswordHistory for mobileno=" + MobileNo
		responseModel.StatusCode = http.StatusInternalServerError
		return responseModel

	}
	// token := make(map[string]string)
	for i := range passwordhistory {
		if newpassword.NewPassword == passwordhistory[i].LastPassword {
			Zerologs.Info().Msg("New_Password(): Current password should not be same as last 3 passwords for mobileno=" + MobileNo)
			responseModel.IsErr = true
			responseModel.Msg = "Current password should not be same as last 3 passwords"
			responseModel.StatusCode = http.StatusInternalServerError
			return responseModel
		}
	}
	updatePassData := make(map[string]interface{})
	updatePassData["password"] = newpassword.NewPassword
	updatePassData["password_failed_count"] = 0
	updatePassData["is_password_reset"] = true
	updatePassData["last_password_updated_time"] = time.Now()
	// err := Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", MobileNo).Updates(updatePassData).Error
	err := updateJWTAuthMaster(helper.CLIENT_MOBILE_PARAM, MobileNo, updatePassData)
	if err != nil {
		Zerologs.Error().Msg("New_Password(): Password, PasswordFailedCount and MPin update failed for mobileno=" + MobileNo + " and error is " + err.Error())
		responseModel.IsErr = true
		responseModel.Msg = err.Error()
		responseModel.StatusCode = http.StatusInternalServerError
		return responseModel
	}
	var password clientmaster.PasswordHistory
	password.MobileNo = MobileNo
	password.LastPassword = newpassword.NewPassword
	password.LastPassword_UpdatedTime = time.Now()
	err = Db.Client.Create(&password).Error
	if err != nil {
		Zerologs.Error().Msg("New_Password(): Error while inserting data in password history for mobileno=" + MobileNo + " and error is " + err.Error())
		responseModel.IsErr = true
		responseModel.Msg = err.Error()
		responseModel.StatusCode = http.StatusInternalServerError
		return responseModel
	}
	// token["url"] = "/sign/glogin"
	Zerologs.Info().Msg("New_Password(): Password reset  successfully for user mobileno= " + MobileNo)
	responseModel.IsErr = true
	responseModel.Msg = "Password reset successfully"
	responseModel.StatusCode = http.StatusInternalServerError
	return responseModel

}
