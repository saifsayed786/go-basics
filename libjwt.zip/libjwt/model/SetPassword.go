package model

type NewPassword struct {
	// MobileNo    string `json:"mobile_no"`
	OldPassword string `json:"oldPassword"`
	NewPassword string `json:"newPassword"`
	UID         string `json:"uid"`
	Pwd         string `json:"pwd"`
	BrokerID    string `json:"brokerId"`
	Source      string `json:"source"`
	DeviceName  string `json:"deviceName"`
	DeviceInfo  string `json:"deviceInfo"`
	// ConfirmPassword string `json:"confirmPassword"`
}

type New_Password struct {
	// MobileNo    string `json:"mobile_no"`
	NewPassword string `json:"newPassword"`
	// ConfirmPassword string `json:"confirmPassword"`
	// NewMPin string `json:"newMPin"`
	// ConfirmMPin string `json:"confirmMPin"`
}

type NewPasswordResponse struct {
	IsErr      bool   `json:"isErr"`
	Msg        string `json:"msg"`
	StatusCode int    `json:"statusCode"`
	Url        string `json:"url,omitempty"`
}

type SetPasswordModel struct {
	IsErr        bool   `json:"isErr"`
	Msg          string `json:"msg"`
	StatusCode   int    `json:"statusCode"`
	IsKyc        bool   `json:"isKyc,omitempty"`
	IsActivated  bool   `json:"isActivated,omitempty"`
	AccessToken  string `json:"access_token"`
	RefreshToken string `json:"refresh_token"`
	Url          string `json:"url"`
}
