package models

type ReportTimeFrameDTO struct {
	From        string `json:"from"`
	To          string `json:"to"`
	SendToSlack bool   `json:"sendToSlack"`
}
