package controller

import (
	"errors"
	"net/http"
	"strconv"

	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/model"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/contrib/sessions"
	"github.com/gin-gonic/gin"
)

func ValidateLogin(c *gin.Context) {
	libhttp.CoreHeader(c)
	session := sessions.Default(c)
	retrievedState := session.Get("state")
	if retrievedState == nil {
		service.Zerologs.Info().Msg("ValidateLogin(): RetriveState is Nil")
		c.JSON(http.StatusInternalServerError, errors.New("RetriveState is Nil"))
		return
	}
	cquery := c.Query("state")
	if retrievedState != cquery {
		//Pending
		//c.AbortWithError(http.StatusUnauthorized, fmt.Errorf("Invalid session state: %s", retrievedState))
		//return
	}

	// skey := c.Request.Header.Get("access_token")
	var UserKey model.ValidateLoginModel
	if err := c.BindJSON(&UserKey); err != nil {
		service.Zerologs.Error().Msg("ValidateLogin(): Error in c.BindJSON is " + err.Error())
		c.JSON(http.StatusBadRequest, err)
		return
	}
	// mobileNo, err := VerifyUser(UserKey.AccessToken)
	// if err != nil {
	// 	token["url"] = "/sign/glogin"
	// 	token["errMsg"] = "Unauthorized token, Jwt auth Data not found for this tokenString"
	// 	c.JSON(http.StatusInternalServerError, token)
	// 	return
	// }
	// fmt.Println(mobileNo)
	mobile_no, err := service.GetUser(c)
	if err != nil {
		service.Zerologs.Error().Err(err).Msg("GetProfileHandler(): Unauthorized")
		c.JSON(http.StatusUnauthorized, "Unauthorized")
		return
	}
	MobileNo := strconv.FormatUint(uint64(mobile_no), 10)
	response := service.ValidateLoginService(MobileNo, UserKey, retrievedState)
	c.JSON(response.StatusCode, response)

}
