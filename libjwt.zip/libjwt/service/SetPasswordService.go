package service

import (
	"net/http"
	"time"

	"github.com/MACMREPO/libdb/clientmaster"
	"github.com/MACMREPO/libjwt/helper"
	"github.com/MACMREPO/libjwt/model"
)

func SetPasswordService(MobileNo string, newpassword model.NewPassword) model.SetPasswordModel {
	var responseModel model.SetPasswordModel
	// var clientdbData clientmaster.JwtAuthMaster
	// err := Db.Client.Where("mobile_no=?", MobileNo).First(&clientdbData).Error
	clientdbData, err := getJwtAuthMasterDB(helper.CLIENT_MOBILE_PARAM, MobileNo)
	if err != nil {
		Zerologs.Error().Msg("Set_Password(): User data not found for mobileno=" + MobileNo + " and error is " + err.Error())
		responseModel.IsErr = true
		responseModel.Msg = err.Error()
		responseModel.StatusCode = http.StatusInternalServerError
		return responseModel
	}
	if newpassword.OldPassword != clientdbData.Password {
		Zerologs.Error().Msg("Set_Password(): Old password is incorrect for mobileno=" + MobileNo)
		responseModel.IsErr = true
		responseModel.Msg = "Old password is incorrect"
		responseModel.StatusCode = http.StatusInternalServerError
		return responseModel
	} else {
		// err = Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", MobileNo).Updates(clientmaster.JwtAuthMaster{Password: newpassword.NewPassword, PasswordFailedCount: 0, IsPasswordReset: true}).Error
		err := updateJWTAuthMasterModel(helper.CLIENT_MOBILE_PARAM, MobileNo, clientmaster.JwtAuthMaster{Password: newpassword.NewPassword, PasswordFailedCount: 0, IsPasswordReset: true})
		if err != nil {
			Zerologs.Error().Msg("Set_Password(): Password and PasswordFailedCount update failed for mobileno=" + MobileNo + " and error is " + err.Error())
			responseModel.IsErr = true
			responseModel.Msg = err.Error()
			responseModel.StatusCode = http.StatusInternalServerError
			return responseModel
		}
		var password clientmaster.PasswordHistory
		password.MobileNo = MobileNo
		password.LastPassword = newpassword.NewPassword
		password.LastPassword_UpdatedTime = time.Now()
		err = Db.Client.Create(&password).Error
		if err != nil {
			Zerologs.Error().Msg("Set_Password(): Error while inserting data in password history for mobileno=" + MobileNo + " and error is " + err.Error())
			responseModel.IsErr = true
			responseModel.Msg = err.Error()
			responseModel.StatusCode = http.StatusInternalServerError
			return responseModel
		}

		token, err := GenerateJWTWithRefresh(clientdbData.MobileNo, clientdbData.Email, "") //Samir Pending
		if err != nil {
			// fmt.Println("GenerateJWTWithRefresh Erro = " + err.Error())
			Zerologs.Error().Msg("Set_Password(): Error in GenerateJWTWithRefresh for mobileno=" + clientdbData.MobileNo + " and email=" + clientdbData.Email + " is " + err.Error())
			responseModel.IsErr = true
			responseModel.Msg = err.Error()
			responseModel.StatusCode = http.StatusInternalServerError
			return responseModel
		}
		if clientdbData.KYCDone == true {
			if clientdbData.Activated {
				// if clientdbData.IsMPIN_Reset == false {
				// 	token["isKyc"] = "true"
				// 	token["isActivated"] = "true"
				// 	token["isMpinSet"] = "false"
				//
				// 	return token, nil
				// }
				// loginModel := model.HyperLoginmodel{
				// 	UID:        clientdbData.ClientID + "-" + newpassword.BrokerID,
				// 	Pwd:        newpassword.Pwd,
				// 	BrokerID:   newpassword.BrokerID,
				// 	Source:     newpassword.Source,
				// 	DeviceName: newpassword.DeviceName,
				// 	DeviceInfo: newpassword.DeviceInfo,
				// }
				// key, IsMPINRequired, err := HypersyncLogin(loginModel)
				// fmt.Println("hypersync devicempin key: ", key)
				// if err == nil {
				// 	token["devicekey"] = key
				// 	if IsMPINRequired {
				// 		token["isKyc"] = "true"
				// 		token["isActivated"] = "true"
				// 		token["isMpinSet"] = "true"
				//
				// 		return token, nil
				// 	}
				// }
				responseModel.IsErr = false
				responseModel.Msg = "Login Success"
				responseModel.StatusCode = http.StatusOK
				responseModel.IsKyc = true
				responseModel.IsActivated = true
				responseModel.AccessToken = token.AccessToken
				responseModel.RefreshToken = token.RefreshToken

				return responseModel
			} else {
				// if clientdbData.IsMPIN_Reset == false {
				// 	token["isKyc"] = "true"
				// 	token["isActivated"] = "false"
				// 	token["isMpinSet"] = "false"

				// 	return token, nil
				// }
				// token["hypersyncAccessToken"] = ""
				// token["isKyc"] = "true"
				// token["isMpinSet"] = "true"
				// token["isActivated"] = "false"
				responseModel.IsErr = false
				responseModel.Msg = "Login Success"
				responseModel.StatusCode = http.StatusOK
				responseModel.IsKyc = true
				responseModel.IsActivated = false
				responseModel.AccessToken = token.AccessToken
				responseModel.RefreshToken = token.RefreshToken
				return responseModel
			}
		} else {
			responseModel.IsErr = false
			responseModel.Msg = "Login Success"
			responseModel.StatusCode = http.StatusOK
			responseModel.IsKyc = false
			responseModel.IsActivated = false
			responseModel.AccessToken = token.AccessToken
			responseModel.RefreshToken = token.RefreshToken
			return responseModel
		}
	}
}
