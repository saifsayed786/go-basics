package controller

import (
	"net/http"

	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/model"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/gin"
)

func Add_Mobile(c *gin.Context) {
	libhttp.CoreHeader(c)
	var mobilemodel model.MobileModel
	err := c.BindJSON(&mobilemodel)
	if err != nil {
		service.Zerologs.Error().Msg("Add_Mobile(): Error in c.BindJSON MobileModel " + err.Error())
		c.JSON(http.StatusBadRequest, "")
		return
	}
	response := service.AddMobileService(mobilemodel)
	c.JSON(response.StatusCode, response)
}
