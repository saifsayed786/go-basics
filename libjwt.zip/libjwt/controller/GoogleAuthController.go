package controller

import (
	"github.com/gin-gonic/gin"
)

func GoogleAuth(c *gin.Context) {
	// libhttp.CoreHeader(c)
	// var user model.User
	// err := c.BindJSON(&user)
	// if err != nil {
	// 	service.Zerologs.Error().Msg("GoogleAuth(): Error in c.BindJSON is " + err.Error())
	// 	return
	// }
	// response, err := service.GoogleAuthService(user)
	// if err != nil {
	// 	c.JSON(500, err.Error())
	// 	return
	// }
	// result, ok := response["errMsg"]
	// if ok {
	// 	c.JSON(500, result)
	// 	return
	// }
	// c.JSON(200, response)

}
