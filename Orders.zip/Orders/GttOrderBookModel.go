package model

type GttOrderBookModel struct {
	RwsTokenID    string `json:"rws_token_id,omitempty"`
	Source        string `json:"source,omitempty"`
	ClientType    string `json:"client_type,omitempty"`
	RwsClientcode string `json:"rws_clientcode,omitempty"`
	ExchangeID    string `json:"exch,omitempty"`
	SegmnetID     string `json:"Seg,omitempty"`
	ProductID     string `json:"Product,omitempty"`
	OrderStatus   string `json:"Status,omitempty"`
}
