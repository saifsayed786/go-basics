package service

import (
	"net/http"

	"github.com/MACMREPO/libjwt/helper"
	"github.com/MACMREPO/libjwt/model"
)

func ForgotPasswordService(forgetpassword model.ForgetPassword) model.ForgotPasswordResponseModel {
	var ResponseModel model.ForgotPasswordResponseModel
	resp := Verify_OTP(forgetpassword.MobileNo, forgetpassword.OTP)
	if !resp.IsErr {
		// var EmailMap clientmaster.TblMobileEmailMapping
		// err := Db.Client.Where("mobile_no=? AND email=?", forgetpassword.MobileNo, forgetpassword.Email).First(&EmailMap).Error
		_, err := getEmailAndMobFromEmailMapping(forgetpassword.MobileNo, forgetpassword.Email)
		if err != nil {
			Zerologs.Error().Msg("Forgot_Password(): User email data not found for MobileNo=" + forgetpassword.MobileNo + " and Email=" + forgetpassword.Email + "and error is " + err.Error())
			ResponseModel.IsErr = true
			ResponseModel.Msg = "Wrong Email"
			ResponseModel.StatusCode = http.StatusInternalServerError
			return ResponseModel
		}
		// var userData clientmaster.JwtAuthMaster
		// err = Db.Client.Where("mobile_no=?", forgetpassword.MobileNo).First(&userData).Error
		userData, err := getJwtAuthMasterDB(helper.CLIENT_MOBILE_PARAM, forgetpassword.MobileNo)
		if err != nil {
			Zerologs.Error().Msg("Forgot_Password(): User data not found for mobileno=" + forgetpassword.MobileNo + " and error is " + err.Error())
			ResponseModel.IsErr = true
			ResponseModel.Msg = "User details not available"
			ResponseModel.StatusCode = http.StatusInternalServerError
			return ResponseModel
		}
		if userData.PasswordFailedCount >= Env.MAX_PASSWORD_ATTEMPT {
			Zerologs.Info().Msg("Forgot_Password(): Mobileno=" + forgetpassword.MobileNo + " is blocked, please unblock and try again")
			ResponseModel.IsErr = true
			ResponseModel.Msg = "User is blocked, please unblock and try again"
			ResponseModel.StatusCode = http.StatusInternalServerError
			return ResponseModel
		}
		token, err := GenerateJWTWithRefresh(userData.MobileNo, userData.Email, "") //Samir Pending
		if err != nil {
			// fmt.Println("GenerateJWTWithRefresh Erro = " + err.Error())
			Zerologs.Error().Msg("Forgot_Password(): Error in GenerateJWTWithRefresh for mobileno=" + userData.MobileNo + " and email=" + userData.Email + " is " + err.Error())
			ResponseModel.IsErr = true
			ResponseModel.Msg = err.Error()
			ResponseModel.StatusCode = http.StatusInternalServerError
			return ResponseModel
		}
		//user verify and redirect to set pass page.
		ResponseModel.IsErr = false
		ResponseModel.Msg = "Show set password screen"
		ResponseModel.Url = "/sign/newpass"
		ResponseModel.StatusCode = http.StatusOK
		ResponseModel.AccessToken = token.AccessToken
		ResponseModel.RefreshToken = token.RefreshToken
		return ResponseModel
	} else {
		ResponseModel.IsErr = true
		ResponseModel.Msg = resp.Msg
		ResponseModel.StatusCode = http.StatusInternalServerError
		return ResponseModel
	}
}
