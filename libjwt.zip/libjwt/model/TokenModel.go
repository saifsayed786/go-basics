package model

type TokenModel struct {
	AccessToken  string `json:"access_token"`
	RefreshToken string `json:"refresh_token"`
	Url          string `json:"url"`
}

type AccessTokenResponseModel struct {
	IsErr        bool   `json:"isErr"`
	Msg          string `json:"Msg"`
	StatusCode   int    `json:"statusCode"`
	IsKyc        bool   `json:"isKyc,omitempty"`
	IsActivated  bool   `json:"isActivated,omitempty"`
	AccessToken  string `json:"access_token,omitempty"`
	RefreshToken string `json:"refresh_token,omitempty"`
	Url          string `json:"url,omitempty"`
}

type TokenHandlerResponseModel struct {
	IsErr        bool   `json:"isErr"`
	Msg          string `json:"Msg"`
	StatusCode   int    `json:"statusCode"`
	IsActivated  bool   `json:"isActivated,omitempty"`
	AccessToken  string `json:"access_token,omitempty"`
	RefreshToken string `json:"refresh_token,omitempty"`
	Url          string `json:"url,omitempty"`
}
