package service

import (
	"bytes"
	"encoding/json"
	"errors"
	"io/ioutil"
	"net/http"

	"github.com/MACMREPO/libjwt/model"
)

func HypersyncLogin(logindata model.HyperLoginmodel) (string, bool, error) {
	json_data, err := json.Marshal(logindata)
	if err != nil {
		return "", false, err
	}
	resp, err := http.Post("https://www.nuuu.com/auth/api/login", "application/json",
		bytes.NewBuffer(json_data))

	if err != nil {
		return "", false, err
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return "", false, err
	}
	respModel := model.HyperLoginResponse{}
	err = json.Unmarshal(body, &respModel)
	if err != nil {
		return "", false, err
	}

	if respModel.Code == 200 && respModel.Data.Devicempinkey != "" {
		if respModel.Data.Message == "Enter MPIN" {
			return respModel.Data.Devicempinkey, true, nil
		} else {
			return respModel.Data.Devicempinkey, false, nil
		}
	}

	return "", false, errors.New("unauthorised")
}
func HypersyncMpin(mpinmodel model.HyperMpinRequest) (string, error) {
	json_data, err := json.Marshal(mpinmodel)
	if err != nil {
		return "", err
	}
	resp, err := http.Post("https://www.nuuu.com/auth/api/mpinlogin", "application/json",
		bytes.NewBuffer(json_data))

	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}
	respModel := model.HyperMpinResponse{}
	err = json.Unmarshal(body, &respModel)
	if err != nil {
		return "", err
	}

	if respModel.Code == 200 && respModel.Data.SessionKey != "" {
		return respModel.Data.SessionKey, nil
	}

	return "", errors.New("unauthorised")
}
