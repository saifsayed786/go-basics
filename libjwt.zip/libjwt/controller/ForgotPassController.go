package controller

import (
	"fmt"
	"strings"

	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/helper"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/contrib/sessions"
	"github.com/gin-gonic/gin"
)

func ForgotPassTempController(c *gin.Context) {
	libhttp.CoreHeader(c)
	session := sessions.Default(c)
	retrievedState := session.Get("state")
	cquery := c.Query("state")
	RetriveState := retrievedState.(string)

	if retrievedState != cquery {
		fmt.Println(retrievedState.(string) + " -- " + cquery)
		// c.AbortWithError(http.StatusUnauthorized, fmt.Errorf("Invalid session state: %s", retrievedState))
		// return
	}
	imgBase64Str := service.CreateCaptcha(RetriveState)
	forgotpasstemp := strings.Replace(string(helper.ForgetPassTemplate), "CAPTCHADATA", imgBase64Str, 1)
	c.Writer.Write([]byte(forgotpasstemp))
	// c.Writer.Write(ForgetPassTemplate)
}
