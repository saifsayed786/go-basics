package service

// import (
// 	"fmt"
// 	"strconv"
// 	"time"

// 	"github.com/MACMREPO/libdb/clientmaster"
// 	"github.com/MACMREPO/libjwt/model"
// )

// func AddMPINApiHandlerService(RetrievedState string, mpinmodel model.MpinModel) (map[string]string, error) {
// 	val, err := RedisLib.Client.Get(RetrievedState).Result()
// 	if err != nil {
// 		Zerologs.Error().Msg("AddMPINApiHandler():UserGuid not getting from redis by using retrieved state:= " + RetrievedState + err.Error())
// 		return nil, err
// 	}
// 	RedirectUrl, err := RedisLib.Client.Get(RetrievedState + "-RedirectUrl").Result()
// 	fmt.Println("AddMPINApiHandler(): RedirectUrl= ", RedirectUrl)
// 	if err != nil {
// 		Zerologs.Error().Msg("AddMPINApiHandler(): RedirectUrl not getting from redis by using retrieved state := " + RetrievedState + err.Error())
// 		return nil, err
// 	}
// 	var clientdbData clientmaster.JwtAuthMaster
// 	err = Db.Client.Where("user_guid=?", val).First(&clientdbData).Error
// 	if err != nil {
// 		Zerologs.Error().Msg("AddMPINApiHandler(): User not found in clientmaster.JwtAuthMaster where user_guid=  " + val + err.Error())
// 		return nil, err
// 	}
// 	token := make(map[string]string)
// 	if clientdbData.MPINFailedCount >= Env.MAX_MPIN_ATTEMPT || clientdbData.PasswordFailedCount >= Env.MAX_PASSWORD_ATTEMPT {
// 		Zerologs.Info().Msg("AddMPINApiHandler(): MOBILE NO: " + clientdbData.MobileNo + "IS BLOCKED AT :=  " + time.Now().Format("2006-01-02 15:04:05"))
// 		token["errMsg"] = "User is blocked"
// 		return token, nil
// 	}
// 	if mpinmodel.Mpin != clientdbData.MPIN {
// 		Zerologs.Error().Msg("AddMPINApiHandler(): User " + clientdbData.MobileNo + " enter wrong MPIN ")
// 		Totalcount := clientdbData.MPINFailedCount + 1
// 		err = Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", clientdbData.MobileNo).Update("mpin_failed_count", Totalcount).Error
// 		if err != nil {
// 			Zerologs.Error().Msg("AddMPINApiHandler(): mpinfailed count update query failed where mobile_no:=  " + clientdbData.MobileNo + err.Error())
// 			return nil, err
// 		}
// 		remainingcount := Env.MAX_MPIN_ATTEMPT - Totalcount
// 		if remainingcount == 0 {
// 			token["errMsg"] = "User blocked, please unblock and try again"
// 		} else {
// 			token["errMsg"] = "Incorect Mpin. " + strconv.Itoa(remainingcount) + " attempts remaining "
// 		}
// 		return token, nil
// 	}
// 	if clientdbData.KYCDone && clientdbData.Activated == true {
// 		sAccountcode := clientdbData.ClientID + "-" + mpinmodel.BrokerID
// 		token, err := GenerateJWTWithRefresh(clientdbData.MobileNo, clientdbData.Email, sAccountcode)
// 		if err != nil {
// 			Zerologs.Error().Msg("AddMPINApiHandler(): Token not generated using GenerateJWTWithRefresh for mobileno & email " + clientdbData.MobileNo + clientdbData.Email + err.Error())
// 			return nil, err
// 		}
// 		if clientdbData.MobileNo == "9673780788" {
// 			var greenWareReq model.GreenwareRequestModel
// 			greenWareReq.SsoBy = "mobile+user_type"
// 			greenWareReq.Param1 = clientdbData.MobileNo
// 			greenWareReq.Param2 = 1
// 			mfaccesstoken := GreenWareLoginService(greenWareReq)
// 			if mfaccesstoken != "" {
// 				Zerologs.Info().Msg("AddMPINApiHandler() : User " + clientdbData.MobileNo + " successfully login to greenware on " + " AT " + time.Now().Format("2006-01-02 15:04:05"))
// 				token["mftoken"] = mfaccesstoken
// 			} else {
// 				token["mftoken"] = mfaccesstoken
// 			}
// 		}
// 		mpinModel := model.HypersyncModel{
// 			Uid:      clientdbData.ClientID + "-" + mpinmodel.BrokerID,
// 			BrokerId: mpinmodel.BrokerID, //NIT
// 			System:   mpinmodel.BrokerID, //NIT
// 		}
// 		key, err := NewHyperSyncLogin(mpinModel)
// 		Zerologs.Info().Msg("HyperSyncAccessToken for mobileNo:=" + clientdbData.MobileNo + " hypersyncToken " + key)
// 		if err == nil {
// 			if err := RedisLib.Client.Set("Hyper-"+token["access_token"], key, time.Hour*24).Err(); err != nil {
// 				Zerologs.Error().Err(err).Msg("AddMPINApiHandler(): Error Inserting hypersync token  in redis for mobile: " + clientdbData.MobileNo + err.Error())
// 				return nil, err
// 			}
// 			// if RedirectUrl == "" || RedirectUrl == "https://www.foocut.com/trade" || RedirectUrl == "https://www.foocut.com/trade/" {
// 			if UrlsArr.CheckUrls(RedirectUrl) {
// 				err = Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", clientdbData.MobileNo).Updates(clientmaster.JwtAuthMaster{HyperSyncAccessToken: key}).Error
// 				if err != nil {
// 					Zerologs.Error().Msg("AddMPINApiHandler(): HyperSyncAccessToken update query failed where mobile_no:= " + clientdbData.MobileNo + err.Error())
// 					return nil, err
// 				}
// 				Zerologs.Info().Msg("AddMPINApiHandler(): USER LOGIN SUCCESSFULLY FOR MOBILE NO:=  " + clientdbData.MobileNo + " AT " + time.Now().Format("2006-01-02 15:04:05"))
// 				token["hyperSyncAccessToken"] = key // hypersync access token return
// 				return token, nil

// 			} else {
// 				// token["devicempinkey"] = key
// 				err = Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", clientdbData.MobileNo).Updates(clientmaster.JwtAuthMaster{HyperSyncAccessToken: key}).Error
// 				if err != nil {
// 					Zerologs.Error().Msg("AddMPINApiHandler(): HyperSyncAccessToken update query failed where mobile_no:= " + clientdbData.MobileNo + err.Error())
// 					return nil, err
// 				}
// 				Zerologs.Info().Msg("AddMPINApiHandler(): USER LOGIN SUCCESSFULLY FOR MOBILE NO:=  " + clientdbData.MobileNo + " AT " + time.Now().Format("2006-01-02 15:04:05"))
// 				token["url"] = RedirectUrl
// 				fmt.Println("AddMPINApiHandler(): token[url]", RedirectUrl)
// 				token["hyperSyncAccessToken"] = key // hypersync access token return
// 				fmt.Println("AddMPINApiHandler() lastresponse: ", token)
// 				return token, nil
// 			}
// 		} else {
// 			// if RedirectUrl == "" || RedirectUrl == "https://www.nuuu.com/trade" || RedirectUrl == "https://www.nuuu.com/trade/" {
// 			if UrlsArr.CheckUrls(RedirectUrl) {
// 				Zerologs.Info().Msg("AddMPINApiHandler(): USER LOGIN SUCCESSFULLY FOR MOBILE NO:=  " + clientdbData.MobileNo + " AT " + time.Now().Format("2006-01-02 15:04:05"))
// 				token["hyperSyncAccessToken"] = ""
// 				return token, nil
// 			} else {
// 				Zerologs.Info().Msg("AddMPINApiHandler(): USER LOGIN SUCCESSFULLY FOR MOBILE NO:=  " + clientdbData.MobileNo + " AT " + time.Now().Format("2006-01-02 15:04:05"))
// 				token["hyperSyncAccessToken"] = ""
// 				token["url"] = RedirectUrl
// 				// fmt.Println("AddMPINApiHandler(): token[url]", RedirectUrl)
// 				return token, nil
// 				// fmt.Println("AddMPINApiHandler() lastresponse: ", token)
// 			}

// 		}
// 	}
// 	return token, nil
// }

// func AddMPINService(MobileNo string, mpinmodel model.MpinModel) (map[string]string, error) {
// 	var clientdbData clientmaster.JwtAuthMaster
// 	err := Db.Client.Where("mobile_no=?", MobileNo).First(&clientdbData).Error
// 	if err != nil {
// 		Zerologs.Error().Msg("AddMPIN(): User data not found for mobileno=" + MobileNo + " and error is " + err.Error())
// 		return nil, err
// 	}
// 	token := make(map[string]string)
// 	if clientdbData.MPINFailedCount >= Env.MAX_MPIN_ATTEMPT || clientdbData.PasswordFailedCount >= Env.MAX_PASSWORD_ATTEMPT {
// 		Zerologs.Info().Msg("AddMPIN(): MOBILE NO: " + clientdbData.MobileNo + "IS BLOCKED AT :=  " + time.Now().Format("2006-01-02 15:04:05"))
// 		token["errMsg"] = "User is blocked"
// 		return token, nil
// 	}
// 	if mpinmodel.Mpin != clientdbData.MPIN {
// 		Zerologs.Error().Msg("AddMPIN(): User " + clientdbData.MobileNo + " enter wrong MPIN ")
// 		Totalcount := clientdbData.MPINFailedCount + 1
// 		err = Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", clientdbData.MobileNo).Update("mpin_failed_count", Totalcount).Error
// 		if err != nil {
// 			Zerologs.Error().Msg("AddMPIN(): mpinfailed count update query failed where mobile_no:=  " + clientdbData.MobileNo + err.Error())
// 			return nil, err
// 		}
// 		remainingcount := Env.MAX_MPIN_ATTEMPT - Totalcount
// 		if remainingcount == 0 {
// 			token["errMsg"] = "User blocked, please unblock and try again"
// 		} else {
// 			token["errMsg"] = "Incorect Mpin. " + strconv.Itoa(remainingcount) + " attempts remaining "
// 		}
// 		return token, nil
// 	}
// 	sAccountcode := clientdbData.ClientID + "-" + "NIT" //Samir Pending
// 	token, err = GenerateJWTWithRefresh(clientdbData.MobileNo, clientdbData.Email, sAccountcode)
// 	if err != nil {
// 		Zerologs.Error().Msg("AddMPIN(): Error in GenerateJWTWithRefresh for mobileno=" + clientdbData.MobileNo + " and email=" + clientdbData.Email + " is " + err.Error())
// 		return nil, err
// 	}
// 	//fmt.Println("step 5 token not generated:", token)
// 	if clientdbData.KYCDone {
// 		if clientdbData.MobileNo == "9673780788" {
// 			var greenWareReq model.GreenwareRequestModel
// 			greenWareReq.SsoBy = "mobile+user_type"
// 			greenWareReq.Param1 = clientdbData.MobileNo
// 			greenWareReq.Param2 = 1
// 			mfaccesstoken := GreenWareLoginService(greenWareReq)
// 			if mfaccesstoken != "" {
// 				Zerologs.Info().Msg("AddMPIN() : User " + clientdbData.MobileNo + " successfully login to greenware " + " AT " + time.Now().Format("2006-01-02 15:04:05"))
// 				token["mftoken"] = mfaccesstoken
// 			} else {
// 				token["mftoken"] = mfaccesstoken
// 			}
// 		}
// 		if clientdbData.Activated {
// 			//new hypersync login code-----start
// 			mpinModel := model.HypersyncModel{
// 				Uid:      clientdbData.ClientID + "-" + mpinmodel.BrokerID,
// 				BrokerId: mpinmodel.BrokerID, //NIT
// 				System:   mpinmodel.BrokerID, //NIT
// 			}
// 			key, err := NewHyperSyncLogin(mpinModel)
// 			Zerologs.Info().Msg("HyperSyncAccessToken for mobileNo:=" + clientdbData.MobileNo + " hypersyncToken " + key)
// 			if err == nil {
// 				// token["devicempinkey"] = key
// 				token["hyperSyncAccessToken"] = key // hypersync access token return
// 				err = Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", clientdbData.MobileNo).Updates(clientmaster.JwtAuthMaster{HyperSyncAccessToken: key}).Error
// 				if err != nil {
// 					Zerologs.Error().Msg("AddMPIN(): HyperSyncAccessToken update query failed where mobile_no:= " + clientdbData.MobileNo + err.Error())
// 					return nil, err
// 				}
// 				Zerologs.Info().Msg(" MOBILE NO: " + clientdbData.MobileNo + "Is login successfully at :=  " + time.Now().Format("2006-01-02 15:04:05"))
// 				token["isKyc"] = "true"
// 				token["isActivated"] = "true"
// 				// token["refresh_token"] = clientdbData.Refreshtoken
// 				token["Msg"] = "login successfully"
// 				return token, nil
// 			} else {
// 				Zerologs.Info().Msg(" MOBILE NO: " + clientdbData.MobileNo + "Is login successfully at :=  " + time.Now().Format("2006-01-02 15:04:05"))
// 				token["isKyc"] = "true"
// 				token["isMpinSet"] = "true"
// 				token["hyperSyncAccessToken"] = ""
// 				token["hyperSyncLogin"] = "Error"
// 				token["isActivated"] = "true"
// 				// token["refresh_token"] = clientdbData.Refreshtoken
// 				return token, nil
// 			}

// 		} else {
// 			if clientdbData.MobileNo == "9673780788" {
// 				var greenWareReq model.GreenwareRequestModel
// 				greenWareReq.SsoBy = "mobile+user_type"
// 				greenWareReq.Param1 = clientdbData.MobileNo
// 				greenWareReq.Param2 = 1
// 				mfaccesstoken := GreenWareLoginService(greenWareReq)
// 				if mfaccesstoken != "" {
// 					Zerologs.Info().Msg("AddMPIN() : User " + clientdbData.MobileNo + " successfully login to greenware " + " AT " + time.Now().Format("2006-01-02 15:04:05"))
// 					token["mftoken"] = mfaccesstoken
// 				} else {
// 					token["mftoken"] = mfaccesstoken
// 				}
// 			}
// 			Zerologs.Info().Msg(" MOBILE NO: " + clientdbData.MobileNo + "Is login successfully at :=  " + time.Now().Format("2006-01-02 15:04:05"))
// 			token["isKyc"] = "true"
// 			token["hyperSyncAccessToken"] = ""
// 			token["isActivated"] = "false"
// 			// token["refresh_token"] = clientdbData.Refreshtoken
// 			return token, nil
// 		}
// 	} else {
// 		token["isKyc"] = "false"
// 		token["isActivated"] = "false"
// 		// token["refresh_token"] = clientdbData.Refreshtoken
// 		return token, nil
// 	}
// }
