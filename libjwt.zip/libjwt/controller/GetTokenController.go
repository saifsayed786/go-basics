package controller

import (
	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/contrib/sessions"
	"github.com/gin-gonic/gin"
)

func GetTokenHandler(c *gin.Context) {
	libhttp.CoreHeader(c)
	session := sessions.Default(c)
	retrievedState := session.Get("state")
	if retrievedState == nil {
		service.Zerologs.Info().Msg("GetTokenHandler(): RetriveState is Nil")
		return
	}
	cquery := c.Query("state")
	if retrievedState != cquery {
		//Pending
		service.Zerologs.Error().Msg("GetTokenHandler(): retrievedState and cquery is not equal:=  " + retrievedState.(string) + " -- " + cquery)
		//c.AbortWithError(http.StatusUnauthorized, fmt.Errorf("Invalid session state: %s", retrievedState))
		//return
	}

	RetrievedState := retrievedState.(string)
	response := service.GetTokenHandlerservice(RetrievedState)
	c.JSON(response.StatusCode, response)
}
