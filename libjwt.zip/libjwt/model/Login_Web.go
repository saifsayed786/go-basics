package model

type Login_Web struct {
	IsErr           bool   `json:"isErr"`
	Msg             string `json:"msg"`
	IsKyc           bool   `json:"isKyc,omitempty"`
	IsActivated     bool   `json:"isActivated,,omitempty"`
	IsPasswordReset bool   `json:"isPasswordReset,omitempty"`
	StatusCode      int    `json:"statusCode"`
	AccessToken     string `json:"access_token,omitempty"`
	RefreshToken    string `json:"refresh_token,omitempty"`
	Url             string `json:"url,omitempty"`
}
