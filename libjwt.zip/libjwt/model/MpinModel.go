package model

type MpinModel struct {
	UID           string `json:"uid"`
	Mpin          string `json:"mpin"`
	BrokerID      string `json:"brokerId"`
	Devicempinkey string `json:"devicempinkey"`
	Source        string `json:"source"`
	DeviceName    string `json:"deviceName"`
	DeviceInfo    string `json:"deviceInfo"`
}

type MPINmodel struct {
	Uid           string `json:"Uid"`
	Mpin          string `json:"Mpin"`
	BrokerID      string `json:"BrokerId"`
	Devicempinkey string `json:"DeviceMpinKey"`
	Source        string `json:"Source"`
	DeviceName    string `json:"DeviceName"`
	DeviceInfo    string `json:"DeviceInfo"`
}

type SetMpinModel struct {
	NewMpin    string `json:"NewMpin"`
	UID        string `json:"uid"`
	Pwd        string `json:"pwd"`
	BrokerID   string `json:"brokerId"`
	Source     string `json:"source"`
	DeviceName string `json:"deviceName"`
	DeviceInfo string `json:"deviceInfo"`
}
