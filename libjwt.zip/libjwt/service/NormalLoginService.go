package service

import (
	"net/http"
	"strconv"
	"time"

	"github.com/MACMREPO/libjwt/helper"
	"github.com/MACMREPO/libjwt/model"
)

func NormalLoginHandlerServicve(mobilemodel model.NormalLoginmodel, retrievedState interface{}, RedirectUrl string) model.NormalLoginResponseModel {
	// token := make(map[string]string)
	var responseModel model.NormalLoginResponseModel
	res, count, mpincount := IsAlreadyRegister(mobilemodel.Mobileno)
	if !res {
		// token["url"] = "/sign/glogin"
		Zerologs.Info().Msg("NormalLoginHandler(): USER NOT REGISTERED WHOS MOBILE NO:=  " + mobilemodel.Mobileno)
		responseModel.IsErr = true
		responseModel.Msg = "Invalid username or password"
		responseModel.StatusCode = http.StatusInternalServerError
		return responseModel
	}
	if count >= Env.MAX_PASSWORD_ATTEMPT || mpincount >= Env.MAX_MPIN_ATTEMPT {
		// token["url"] = "/sign/glogin"
		Zerologs.Info().Msg("NormalLoginHandler(): MOBILE NO: " + mobilemodel.Mobileno + "IS BLOCKED AT :=  " + time.Now().Format("2006-01-02 15:04:05"))
		responseModel.IsErr = true
		responseModel.Msg = "User is blocked"
		responseModel.StatusCode = http.StatusInternalServerError
		return responseModel
	}
	// var clientdbData clientmaster.JwtAuthMaster
	// err := Db.Client.Where("mobile_no=? and password=?", mobilemodel.Mobileno, mobilemodel.Pwd).First(&clientdbData).Error
	clientdbData, err := getClientByUserType(helper.CLIENT_MOBILE_PARAM, mobilemodel.Mobileno, mobilemodel.Pwd)
	if err != nil {
		Totalcount := count + 1
		updateData := make(map[string]interface{})
		updateData["password_failed_count"] = Totalcount
		// err = Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", mobilemodel.Mobileno).Update("password_failed_count", Totalcount).Error
		err := updateJWTAuthMaster(helper.CLIENT_MOBILE_PARAM, mobilemodel.Mobileno, updateData)
		if err != nil {
			Zerologs.Error().Msg("NormalLoginHandler(): password_failed_count update query failed where mobile_no:=  " + mobilemodel.Mobileno + err.Error())
			responseModel.IsErr = true
			responseModel.Msg = " password_failed_count update query failed"
			responseModel.StatusCode = http.StatusInternalServerError
			return responseModel
		}
		remainingAttemptCount := Env.MAX_PASSWORD_ATTEMPT - Totalcount
		// token["url"] = "/sign/glogin"
		if remainingAttemptCount == 0 {
			responseModel.IsErr = true
			responseModel.Msg = "User blocked, please unblock and try again"
			responseModel.StatusCode = http.StatusInternalServerError
		} else {
			responseModel.IsErr = true
			responseModel.Msg = "Invalid username or password. " + strconv.Itoa(remainingAttemptCount) + " attempts remaining "
			responseModel.StatusCode = http.StatusInternalServerError
		}
		return responseModel
	} else {
		// var tbl_mobEmail clientmaster.TblMobileEmailMapping
		// err = Db.Client.Where("mobile_no=? and email=?", mobilemodel.Mobileno, clientdbData.Email).First(&tbl_mobEmail).Error
		tbl_mobEmail, err := getEmailAndMobFromEmailMapping(mobilemodel.Mobileno, clientdbData.Email)
		if err != nil {
			Zerologs.Error().Msg("NormalLoginHandler(): Data not found in clientmaster.TblMobileEmailMapping  where =  " + mobilemodel.Mobileno + " And " + clientdbData.Email + err.Error())
			responseModel.IsErr = true
			responseModel.Msg = err.Error()
			responseModel.StatusCode = http.StatusInternalServerError
			return responseModel
		}
		if clientdbData.PasswordFailedCount > 0 || clientdbData.MPINFailedCount > 0 {
			updateData := make(map[string]interface{})
			updateData["password_failed_count"] = 0
			updateData["mpin_failed_count"] = 0
			// err = Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", mobilemodel.Mobileno).Updates(updateData).Error
			err = updateJWTAuthMaster(helper.CLIENT_MOBILE_PARAM, mobilemodel.Mobileno, updateData)
			if err != nil {
				Zerologs.Error().Msg("NormalLoginHandler(): password_failed_count and mpin_failed count not set to zero, update query failed where mobile_no:=  " + mobilemodel.Mobileno + err.Error())
				responseModel.IsErr = true
				responseModel.Msg = err.Error()
				responseModel.StatusCode = http.StatusInternalServerError
				return responseModel
			}
		}
		RetriveState := retrievedState.(string)
		// err = RedisLib.Client.Set(RetriveState, clientdbData.UserGuid, time.Hour*24).Err()
		err = setDataInRedis(RetriveState, clientdbData.UserGuid, time.Hour*24)
		if err != nil {
			Zerologs.Error().Msg("NormalLoginHandler():UserGUID not set in redis for retriveStat:=  " + RetriveState + err.Error())
			responseModel.IsErr = true
			responseModel.Msg = err.Error()
			responseModel.StatusCode = http.StatusInternalServerError
			return responseModel
		}
		if clientdbData.IsPasswordReset {
			if clientdbData.KYCDone == true {
				if clientdbData.Activated {
					if tbl_mobEmail.TotpStatus {
						responseModel.IsErr = false
						responseModel.Url = "/sign/entertotp?state=" + retrievedState.(string)
						responseModel.StatusCode = http.StatusOK
						return responseModel
					}
					// redirect to setmpin
					if clientdbData.IsMPIN_Reset == false {
						responseModel.IsErr = false
						responseModel.Url = "/sign/setmpin?state=" + retrievedState.(string)
						responseModel.StatusCode = http.StatusOK
						return responseModel
					}
					responseModel.IsErr = false
					responseModel.Url = "/sign/mpin?state=" + retrievedState.(string)
					responseModel.StatusCode = http.StatusOK
					return responseModel

				} else {
					sAccountcode := clientdbData.ClientID + "-" + "NIT" //Samir Pending
					token, err := GenerateJWTWithRefresh(mobilemodel.Mobileno, clientdbData.Email, sAccountcode)
					if err != nil {
						Zerologs.Error().Msg("NormalLoginHandler(): Token not generated using GenerateJWTWithRefresh for mobileno & email " + clientdbData.MobileNo + clientdbData.Email + err.Error())
						responseModel.IsErr = true
						responseModel.Msg = err.Error()
						responseModel.StatusCode = http.StatusInternalServerError
						return responseModel
					}
					// if mobilemodel.Mobileno == "9673780788" {
					// 	var greenWareReq model.GreenwareRequestModel
					// 	greenWareReq.SsoBy = "mobile+user_type"
					// 	greenWareReq.Param1 = mobilemodel.Mobileno
					// 	greenWareReq.Param2 = 1
					// 	mfaccesstoken := GreenWareLoginService(greenWareReq)
					// 	if mfaccesstoken != "" {
					// 		Zerologs.Info().Msg("NormalLoginHandler() : User " + mobilemodel.Mobileno + " successfully login to greenware " + " AT " + time.Now().Format("2006-01-02 15:04:05"))
					// 		token["mftoken"] = mfaccesstoken
					// 	} else {
					// 		token["mftoken"] = mfaccesstoken
					// 	}
					// }
					// if RedirectUrl == "" || RedirectUrl == "https://www.nuuu.com/trade" || RedirectUrl == "https://www.nuuu.com/trade/" {
					if UrlsArr.CheckUrls(RedirectUrl) {
						Zerologs.Info().Msg("NormalLoginHandler(): USER LOGIN SUCCESSFULLY FOR MOBILE NO:=  " + mobilemodel.Mobileno + " AT TIME " + time.Now().Format("2006-01-02 15:04:05"))
						// token["url"] = "/sign/mpin?state=" + retrievedState.(string)
						responseModel.IsErr = false
						responseModel.Msg = "USER LOGIN SUCCESSFULLY"
						responseModel.StatusCode = http.StatusOK
						responseModel.AccessToken = token.AccessToken
						responseModel.RefreshToken = token.RefreshToken
						return responseModel

					} else {
						Zerologs.Info().Msg("NormalLoginHandler(): USER LOGIN SUCCESSFULLY FOR MOBILE NO:=  " + mobilemodel.Mobileno + " AT TIME " + time.Now().Format("2006-01-02 15:04:05"))
						// token["url"] = "/sign/mpin?state=" + retrievedState.(string)
						responseModel.IsErr = false
						responseModel.Msg = "USER LOGIN SUCCESSFULLY"
						responseModel.StatusCode = http.StatusOK
						responseModel.Url = RedirectUrl
						responseModel.AccessToken = token.AccessToken
						responseModel.RefreshToken = token.RefreshToken
						return responseModel
					}
				}
			} else {
				token, err := GenerateJWTWithRefresh(mobilemodel.Mobileno, clientdbData.Email, "")
				if err != nil {
					Zerologs.Error().Msg("NormalLoginHandler(): Token not generated using GenerateJWTWithRefresh for mobileno & email " + clientdbData.MobileNo + clientdbData.Email + err.Error())
					responseModel.IsErr = true
					responseModel.Msg = err.Error()
					responseModel.StatusCode = http.StatusInternalServerError
					return responseModel
				}
				// if RedirectUrl == "" || RedirectUrl == "https://www.nuuu.com/trade" || RedirectUrl == "https://www.nuuu.com/trade/" {
				if UrlsArr.CheckUrls(RedirectUrl) {
					Zerologs.Info().Msg("NormalLoginHandler(): USER LOGIN SUCCESSFULLY FOR MOBILE NO:=  " + mobilemodel.Mobileno + " AT TIME " + time.Now().Format("2006-01-02 15:04:05"))
					responseModel.IsErr = false
					responseModel.Msg = "USER LOGIN SUCCESSFULLY"
					responseModel.StatusCode = http.StatusOK
					responseModel.Url = Env.GOOGLE_MAIN_PAGE
					responseModel.AccessToken = token.AccessToken
					responseModel.RefreshToken = token.RefreshToken
					return responseModel
				} else {
					Zerologs.Info().Msg("NormalLoginHandler(): USER LOGIN SUCCESSFULLY FOR MOBILE NO:=  " + mobilemodel.Mobileno + " AT TIME " + time.Now().Format("2006-01-02 15:04:05"))
					responseModel.IsErr = false
					responseModel.Msg = "USER LOGIN SUCCESSFULLY"
					responseModel.StatusCode = http.StatusOK
					responseModel.Url = RedirectUrl
					responseModel.AccessToken = token.AccessToken
					responseModel.RefreshToken = token.RefreshToken
					return responseModel
				}
			}
		} else {
			responseModel.IsErr = false
			responseModel.Url = "/sign/setpassword?state=" + retrievedState.(string)
			responseModel.StatusCode = http.StatusOK
			return responseModel
		}

	}
}

func NormalLoginService(mobilemodel model.MobileLoginModel) (map[string]string, error) {
	token := make(map[string]string)

	res, _, _ := IsAlreadyRegister(mobilemodel.Mobileno)
	if !res {
		token["isKyc"] = "false"
		token["isActivated"] = "false"
		token["isPasswordSet"] = "false"
		token["Msg"] = "user Not Registered"
		return token, nil
	}
	// var userData clientmaster.JwtAuthMaster
	// err := Db.Client.Where("mobile_no=?", mobilemodel.Mobileno).First(&userData).Error
	userData, err := getJwtAuthMasterDB(helper.CLIENT_MOBILE_PARAM, mobilemodel.Mobileno)
	if err != nil {
		Zerologs.Error().Msg("NormalLogin(): User data not found for mobileno=" + mobilemodel.Mobileno + " and error is " + err.Error())
		return nil, err
	} else {
		if userData.KYCDone {
			if userData.Activated {
				token["isKyc"] = "true"
				token["isActivated"] = "true"
				token["Msg"] = "show  password screen"
				return token, nil

			} else {
				token["isKyc"] = "true"
				token["isActivated"] = "false"
				token["Msg"] = "show  password screen"
				return token, nil
			}
		} else {
			token["isKyc"] = "false"
			token["isActivated"] = "false"
			token["Msg"] = "show  password screen"
			return token, nil
		}
	}
}
