package controller

import (
	"net/http"

	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/model"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/gin"
)

func VerifyOTPController(c *gin.Context) {
	libhttp.CoreHeader(c)
	var VerifyModel model.OtpVerifyModel
	if err := c.BindJSON(&VerifyModel); err != nil {
		// fmt.Println(err)
		service.Zerologs.Error().Err(err).Msg("VerifyOTP(): error BindJSON " + err.Error())
		c.JSON(http.StatusBadRequest, err)
		return
	}
	response, err := service.VerifyOTPService(VerifyModel)
	if err != nil {
		c.JSON(500, err.Error())
		return
	}
	result, ok := response["errMsg"]
	if ok {
		c.JSON(500, result)
		return
	}
	c.JSON(200, response)

}
