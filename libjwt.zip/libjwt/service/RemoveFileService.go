package service

import (
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/s3"
)

func RemoveFile(session *session.Session, filename string) error {
	_, err := s3.New(session).DeleteObject(&s3.DeleteObjectInput{
		Bucket: aws.String(Env.AWS_S3_BUCKET),
		Key:    aws.String(filename),
	})
	return err
}
