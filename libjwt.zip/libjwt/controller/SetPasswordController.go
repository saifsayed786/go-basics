package controller

import (
	"net/http"
	"strconv"

	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/model"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/gin"
)

func Set_Password(c *gin.Context) {
	libhttp.CoreHeader(c)
	mobile_no, err := service.GetUser(c)
	if err != nil {
		// service.Zerologs.Error().Err(err).Msg("Set_Password(): Unauthorized")
		c.JSON(http.StatusUnauthorized, "Unauthorized")
		return
	}
	MobileNo := strconv.FormatUint(uint64(mobile_no), 10)

	var newpassword model.NewPassword
	if err := c.BindJSON(&newpassword); err != nil {
		// service.Zerologs.Error().Msg("Set_Password(): Error in c.BindJSON is " + err.Error())
		c.JSON(http.StatusBadRequest, err)
		return
	}
	response := service.SetPasswordService(MobileNo, newpassword)

	c.JSON(response.StatusCode, response)
}

// func Set_Password(c *gin.Context) {
// 	libhttp.CoreHeader(c)
// 	skey := c.Request.Header.Get("access_token")
// 	MobileNo, err := service.RedisLib.Client.Get(skey).Result()
// 	if err != nil {
// 		fmt.Println(err)
// 		service.Zerologs.Error().Err(err).Msg("Error Getting data from redis")
// 		c.JSON(http.StatusUnauthorized, "Unauthorized")
// 		return
// 	}
// 	token := make(map[string]string)
// 	var newpassword model.NewPassword
// 	if err := c.BindJSON(&newpassword); err != nil {
// 		fmt.Println(err)
// 		return
// 	}
// 	var clientdbData clientmaster.JwtAuthMaster
// 	err = service.Db.Client.Where("mobile_no=?", MobileNo).First(&clientdbData).Error
// 	if err != nil {
// 		service.Zerologs.Error().Msg("Data from  DBError First(&clientdbData)" + err.Error())
// 		c.JSON(http.StatusInternalServerError, "Wrong value")
// 		return
// 	}
// 	if newpassword.OldPassword != clientdbData.Password {
// 		service.Zerologs.Error().Msg("Old password is incorrect ")
// 		token["errMsg"] = "Old password is incorrect"
// 		c.JSON(http.StatusInternalServerError, token)
// 	} else {
// 		err = service.Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", MobileNo).Updates(clientmaster.JwtAuthMaster{Password: newpassword.NewPassword, PasswordFailedCount: 0, IsPasswordReset: true}).Error
// 		if err != nil {
// 			service.Zerologs.Error().Msg("updates failed Password, PasswordFailedCount:" + err.Error())
// 			return
// 		}
// 		var password clientmaster.PasswordHistory
// 		password.MobileNo = MobileNo
// 		password.LastPassword = newpassword.NewPassword
// 		password.LastPassword_UpdatedTime = time.Now()
// 		err = service.Db.Client.Create(&password).Error
// 		if err != nil {
// 			service.Zerologs.Error().Msg("Error while inserting data in password history" + err.Error())
// 			return
// 		}
// 		token["Msg"] = "Password reset successfully"
// 		// token["url"] = "/sign/glogin"

//			c.JSON(http.StatusOK, token)
//		}
//	}
