package model

import (
	"time"
)

type JwtMaster struct {
	Id                       uint   `gorm:"primary_key;" json:"id"`
	MobileNo                 string `json:"mobile_no"`
	MobileOtp                string `json:"mobileotp"`
	MobileVerified           bool   `json:"mobileverified"`
	Email                    string `json:"email"`
	ClientID                 string `json:"client_id"`
	Password                 string `json:"password"`
	Activated                bool   `json:"activated"`
	UserGuid                 string `json:"userGuid"`
	Sub                      string `json:"sub"`
	Name                     string `json:"name"`
	GivenName                string `json:"givenName"`
	FamilyName               string `json:"familyName"`
	Profile                  string `json:"profile"`
	Picture                  string `json:"picture"`
	EmailVerified            bool   `json:"emailVerified"`
	Gender                   string `json:"gender"`
	KYCDone                  bool   `json:"kycDone"`
	MPIN                     string `json:"mpin"`
	PasswordFailedCount      int    `json:"passwordFailedCount"`
	LastPassword_UpdatedTime time.Time
	IsPasswordReset          bool `json:"isPasswordReset"`
	LastMPIN_UpdatedTime     time.Time
	IsMPIN_Reset             bool   `json:"isMPIN_Reset"`
	HyperSyncAccessToken     string `json:"hyperSyncAccessToken"`
	Pan                      string `json:"pan"`
	Default_password         string `json:"defaultPassword"`
	Refreshtoken             string `json:"refreshtoken"`
	ExpiresInDays            int    `json:"expiresInDays"`
	TotpSecretKey            string `json:"totpSecretKey"`
	TotpStatus               string `json:"totpStatus"`
}
