package service

import (
	"bufio"
	"chartdataservice/models"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/TecXLab/liblogs"
	"github.com/gin-gonic/gin"
)

var (
	directoryPath = RootPath + "/" + BasePath + "/" + RawPath + "/" + EqPath
	// directoryPath = "/home/cedric/Projects/Sample/chartdataservice2/rawdata/nse1/NSEEQ/23082022"
	// chartdataDir  = "/home/cedric/Projects/Sample/chartdataservice2/"
	chartdataDir = RootPath + "/" + BasePath

	lastScannedFileIndex = -1
)

const DIFF = time.Minute //? Timeframe unit interval)

func GenerateReport(c *gin.Context) {
	if c.Query("folderName") == "" {
		c.JSON(500, "Folder Name is required")
		return
	}
	folderPath := filepath.Join(directoryPath, c.Query("folderName"))

	filesDir, err := os.ReadDir(folderPath)
	if err != nil {
		Logger("Report: System Path for directory not found", err, liblogs.Error, liblogs.ZEROLOG|liblogs.PRINT)
		c.JSON(500, "Report: System Path for directory not found")
		return
	}
	files := filesDir[lastScannedFileIndex+1:]
	if len(files) == 0 {
		return
	}
	startDate, err := getDateFromFileName(files[0].Name(), "020120061504")
	if err != nil {
		c.JSON(500, "Date parsing error: "+err.Error())
		return
	}
	endDate, err := getDateFromFileName(files[len(files)-1].Name(), "020120061504")
	if err != nil {
		c.JSON(500, "Date parsing error: "+err.Error())
		return
	}
	var errorMessageSlice []string
	fileIndex := 0
	for startDate.Before(endDate) {
		fileDate, _ := getDateFromFileName(files[fileIndex].Name(), "020120061504")
		if startDate != fileDate {
			errorString := startDate.Format("2006-01-02T15:04:05") + " " + directoryPath + c.Query("folderName") + "/" + startDate.Format("020120061504") + ".txt"
			errorMessageSlice = append(errorMessageSlice, errorString)
		} else {
			fileIndex++
		}
		startDate = startDate.Add(DIFF)
	}
	lastScannedFileIndex = lastScannedFileIndex + len(files) - 1
	var report string
	report += fmt.Sprintf("Number of errors encountered: %d\n", len(errorMessageSlice))
	for _, e := range errorMessageSlice {
		report += "MISSING: " + e + "\n"
	}
	if len(errorMessageSlice) != 0 {
		Logger(report, nil, liblogs.Error, liblogs.PRINT|liblogs.SLACK|liblogs.ZEROLOG)
	} else {
		Logger(report, nil, liblogs.Info, liblogs.PRINT)
	}
	c.JSON(200, "Report will be generated and sent to Slack")
}

func GenerateReportEOD(c *gin.Context) {
	var fromDate time.Time
	var toDate time.Time
	var reportTimeFrameDTO models.ReportTimeFrameDTO
	err := c.ShouldBindJSON(&reportTimeFrameDTO)
	if err != nil {
		c.JSON(500, "Dates paramters are required "+err.Error())
		return
	}
	if reportTimeFrameDTO.From != "" {
		fromDate, err = time.Parse("2006-01-02T15:04:05", reportTimeFrameDTO.From)
		if err != nil {
			c.JSON(500, "Incorrect 'From' Time Format "+err.Error())
			return
		}
	}
	if reportTimeFrameDTO.To != "" {
		toDate, err = time.Parse("2006-01-02T15:04:05", reportTimeFrameDTO.To)
		if err != nil {
			c.JSON(500, "Incorrect 'To' Time Format "+err.Error())
			return
		}
	}
	nse1Dir := filepath.Join(chartdataDir, "nse1")
	scripDir, err := os.ReadDir(nse1Dir)
	if err != nil {
		c.JSON(500, "Report: System Path for directory not found "+err.Error())
		return
	}
	var errorMessageSlice []string
	for scripIndex := range scripDir {
		intervalPath := filepath.Join(nse1Dir, scripDir[scripIndex].Name())
		intervalDir, _ := os.ReadDir(intervalPath)
		for intervalIndex := range intervalDir {
			durationPath := filepath.Join(intervalPath, intervalDir[intervalIndex].Name())
			durationDir, _ := os.ReadDir(durationPath)
			if intervalDir[intervalIndex].Name() != "1Min" {
				continue
			}
			for durationIndex := range durationDir {
				filePath := filepath.Join(durationPath, durationDir[durationIndex].Name())
				if !fromDate.Equal(time.Time{}) {
					fileDate, _ := getDateFromFileName(durationDir[durationIndex].Name(), "20060102")
					if fileDate.Before(fromDate.Truncate(24 * time.Hour)) {
						continue
					}
				}
				if !toDate.Equal(time.Time{}) {
					fileDate, _ := getDateFromFileName(durationDir[durationIndex].Name(), "20060102")
					if fileDate.After(toDate.Add(time.Hour * 24)) {
						break
					}
				}
				file, err := os.Open(filePath)
				if err != nil {
					Logger("Report: Error while opening file ", err, liblogs.Error, liblogs.PRINT|liblogs.ZEROLOG)
					c.JSON(500, "Report: Error while opening file "+err.Error())
					return
				}
				defer file.Close()
				scanner := bufio.NewScanner(file)
				var fileLines []string
				for scanner.Scan() {
					fileLines = append(fileLines, scanner.Text())
				}
				for i, j := 0, len(fileLines)-1; i < j; i, j = i+1, j-1 {
					fileLines[i], fileLines[j] = fileLines[j], fileLines[i]
				}
				startTime, err := getDateFromLine(fileLines[0])
				if err != nil {
					c.JSON(500, "Date parsing error: "+err.Error())
					return
				}
				endTime, err := getDateFromLine(fileLines[len(fileLines)-1])
				if err != nil {
					fmt.Println(err.Error())
				}
				linePos := 1
				for startTime.Before(endTime) {
					lineTime, err := getDateFromLine(fileLines[linePos])
					if err != nil {
						Logger("Error for parsing date", err, liblogs.Error, liblogs.PRINT)
						continue
					}
					if !fromDate.Equal(time.Time{}) {
						if lineTime.Before(fromDate) {
							continue
						}
					}
					if !toDate.Equal(time.Time{}) {
						if lineTime.After(toDate) {
							break
						}
					}

					if startTime.Truncate(60*time.Second) != lineTime.Truncate(60*time.Second) {
						errorString := startTime.Format("2006-01-02T15:04:05") + " " + filePath
						errorMessageSlice = append(errorMessageSlice, errorString)
					} else {
						linePos++
					}
					startTime = startTime.Add(DIFF)
				}
			}
		}
	}
	var reportMap = make(map[string][]string)
	reportMap[fmt.Sprintf("Number of errors encountered: %d", len(errorMessageSlice))] = errorMessageSlice
	if reportTimeFrameDTO.SendToSlack {
		mp, _ := json.Marshal(reportMap)
		Logger(string(mp), nil, liblogs.Info, liblogs.SLACK)
		c.JSON(200, "Request will be sent on Slack")
	} else {
		c.JSON(200, reportMap)
	}

	fmt.Println("------------Scan Ended--------------")

}
func getDateFromLine(timeString string) (time.Time, error) {
	timeString = strings.Split(timeString, ",")[0]
	return time.Parse("2006-01-02T15:04:05", timeString[:len(timeString)-5])
}
func getDateFromFileName(timeString string, format string) (time.Time, error) {
	timeString = strings.Split(timeString, ".")[0]
	return time.Parse(format, timeString)
}
func SyncDirectory(c *gin.Context) {
	var model models.ReportSyncDirectoryDTO
	err := c.ShouldBindJSON(&model)
	if err != nil {
		fmt.Println(err.Error())
		c.JSON(500, err.Error())
		return
	}
	err = CopyDirectory(model.FromDir, model.ToDir, model.FromDate, model.ToDate, model.ScripName, model.ExchangeName)
	if err != nil {
		fmt.Println(err.Error())
		c.JSON(500, "Sync Unsuccessful"+err.Error())
		return
	}
	c.JSON(200, "Sync Successful")
}
func CopyDirectory(source, destination, fromDateString, toDateString, scripName, exhangeName string) error {
	entries, err := os.ReadDir(source)
	if err != nil {
		return err
	}
	for _, entry := range entries {
		sourcePath := filepath.Join(source, entry.Name())
		destPath := filepath.Join(destination, entry.Name())

		fileInfo, err := os.Stat(sourcePath)
		if err != nil {
			return err
		}
		switch fileInfo.Mode() & os.ModeType {
		case os.ModeDir:

			if exhangeName != "" {
				sliceLength := len(strings.Split(sourcePath, "/"))
				// fmt.

				if sliceLength >= 6 {

					if getFolderFromString(sourcePath, 6) != exhangeName {
						continue
					}
				}
			}
			if scripName != "" {
				sliceLength := len(strings.Split(sourcePath, "/"))
				if sliceLength > 7 {

					if getFolderFromString(sourcePath, 7) != scripName {
						continue
					}
				}
			}
			if err := CreateIfNotExists(destPath, 0755); err != nil {
				return err
			}
			if err := CopyDirectory(sourcePath, destPath, fromDateString, toDateString, scripName, exhangeName); err != nil {
				return err
			}
		default:
			if fromDateString != "" || toDateString != "" {
				fileDate, err := getDateFromFileName(entry.Name(), "20060102")
				if err != nil {
					return err
				}
				fromDate, err := getDateFromFileName(fromDateString, "20060102")
				if err != nil {
					return err
				}

				toDate, err := getDateFromFileName(toDateString, "20060102")
				if err != nil {
					return err
				}

				if fileDate.Before(fromDate) || fileDate.After(toDate) {
					continue
				}
			}

			if err := Copy(sourcePath, destPath); err != nil {
				return err
			}
		}
	}
	return nil
}

func getFolderFromString(path string, order int) string {
	slice := strings.Split(path, "/")
	return slice[order]
}

func Copy(srcFile, dstFile string) error {
	out, err := os.Create(dstFile)
	if err != nil {
		return err
	}
	defer out.Close()
	in, err := os.Open(srcFile)
	if err != nil {
		return err
	}
	defer in.Close()
	_, err = io.Copy(out, in)
	if err != nil {
		return err
	}
	return nil
}

func Exists(filePath string) bool {
	if _, err := os.Stat(filePath); os.IsNotExist(err) {
		return false
	}
	return true
}

func CreateIfNotExists(dir string, perm os.FileMode) error {
	if Exists(dir) {
		return nil
	}
	if err := os.MkdirAll(dir, perm); err != nil {
		return fmt.Errorf("failed to create directory: '%s', error: '%s'", dir, err.Error())
	}
	return nil
}
