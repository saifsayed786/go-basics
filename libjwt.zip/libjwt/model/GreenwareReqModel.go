package model

type GreenwareRequestModel struct {
	SsoBy  string `json:"SsoBy"`
	Param1 string `json:"Param1"`
	Param2 int    `json:"Param2"`
}
type GreenwareEncrReq struct {
	EncrInput string `json:"EncrInput"`
}

type GreenwareResponse struct {
	AccessToken        string
	RefreshTokenConfig struct {
		RToken    string `json:"rToken"`
		RTokenMin int    `json:"rTokenMin"`
	}
	AuthData struct {
		AccountId     int
		LoginName     string
		LoginUserId   int
		LoginUserType int
		MobileNumber  string
		Email         string
		UserName      string
	}
}
