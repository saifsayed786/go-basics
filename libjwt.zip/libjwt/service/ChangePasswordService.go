package service

import (
	"errors"
	"time"

	"github.com/MACMREPO/libdb/clientmaster"
	"github.com/MACMREPO/libjwt/helper"
	"github.com/MACMREPO/libjwt/model"
)

func ChangePasswordService(MobileNo string, changepassword model.ChangePassword) (map[string]string, error) {
	token := make(map[string]string)
	// var clientdbData clientmaster.JwtAuthMaster
	// err := Db.Client.Where("mobile_no=?", MobileNo).First(&clientdbData).Error
	clientdbData, err := getJwtAuthMasterDB(helper.CLIENT_MOBILE_PARAM, MobileNo)
	if err != nil {
		Zerologs.Error().Msg("ChangePassword(): User data not found in clientmaster.JwtAuthMaster for mobileno=" + MobileNo + " and error is " + err.Error())
		return nil, err
	}

	if changepassword.OldPassword != clientdbData.Password {
		Zerologs.Info().Msg("ChangePassword(): User " + MobileNo + " entered incorrect oldpassword ")
		token["errMsg"] = "Old password is incorrect."
		return token, nil
	}
	// var passwordhistory []clientmaster.PasswordHistory
	// Db.Client.Where("mobile_no=?", clientdbData.MobileNo).Order("created_at DESC").Limit(3).Find(&passwordhistory)
	passwordhistory, _ := findPasswordHistoryLimit(helper.CLIENT_MOBILE_PARAM, clientdbData.MobileNo)
	if len(passwordhistory) == 0 {
		Zerologs.Info().Msg("ChangePassword():Data not found in password history table where mobileNo: " + clientdbData.MobileNo)
		return nil, errors.New("Password history data not found")
	}
	for i := range passwordhistory {
		if changepassword.NewPassword == passwordhistory[i].LastPassword {
			token["errMsg"] = "Current password should not be same as last 3 passwords."
			return token, nil
		}
	}
	var password clientmaster.PasswordHistory
	password.MobileNo = MobileNo
	password.LastPassword = changepassword.NewPassword
	password.LastPassword_UpdatedTime = time.Now()
	err = Db.Client.Create(&password).Error
	if err != nil {
		Zerologs.Error().Msg("ChangePassword(): Error while inserting data in password history for mobileno=" + MobileNo + " and error is " + err.Error())
		return nil, err
	}
	// err = Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", clientdbData.MobileNo).Updates(clientmaster.JwtAuthMaster{Password: changepassword.NewPassword, IsPasswordReset: true}).Error
	clientmaster := clientmaster.JwtAuthMaster{Password: changepassword.NewPassword, IsPasswordReset: true}
	err = updateJWTAuthMasterModel(helper.CLIENT_MOBILE_PARAM, clientdbData.MobileNo, clientmaster)
	if err != nil {
		// fmt.Println(err)
		Zerologs.Error().Msg("ChangePassword(): Password update failed for mobileno=" + clientdbData.MobileNo + " and error is " + err.Error())
		return nil, err
	}
	Zerologs.Info().Msg("ChangePassword(): Password changed successfully for : " + clientdbData.MobileNo)
	token["Msg"] = "Password changed successfully...!"
	return token, nil
}
