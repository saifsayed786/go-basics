package controller

import (
	"net/http"
	"strconv"

	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/model"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/gin"
)

func ChangePassword(c *gin.Context) {
	libhttp.CoreHeader(c)
	mobile_no, err := service.GetUser(c)
	if err != nil {
		// service.Zerologs.Error().Err(err).Msg("ChangePassword(): Unauthorized")
		c.JSON(http.StatusUnauthorized, "Unauthorized")
		return
	}
	MobileNo := strconv.FormatUint(uint64(mobile_no), 10)

	var changepassword model.ChangePassword
	err = c.BindJSON(&changepassword)
	if err != nil {
		// fmt.Println("Bind Data Failed")
		// service.Zerologs.Error().Msg("ChangePassword(): Error in c.BindJSON is " + err.Error())
		c.JSON(http.StatusBadRequest, err)
		return
	}
	response, err := service.ChangePasswordService(MobileNo, changepassword)
	if err != nil {
		c.JSON(http.StatusInternalServerError, err)
		return
	}
	if response["errMsg"] != "" {
		c.JSON(http.StatusInternalServerError, response)
		return
	}
	c.JSON(http.StatusOK, response)
}
