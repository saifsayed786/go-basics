package service

// import (
// 	"time"

// 	"github.com/MACMREPO/libdb/clientmaster"
// 	"github.com/MACMREPO/libjwt/model"
// )

// func ForgotMpinService(forgotmpin model.ForgotMPin) (map[string]string, error) {
// 	token := make(map[string]string)
// 	resp := Verify_OTP(forgotmpin.MobileNo, forgotmpin.OTP)
// 	if resp["Msg"] == "Success" {
// 		var EmailMap clientmaster.TblMobileEmailMapping
// 		err := Db.Client.Where("mobile_no=? AND email=?", forgotmpin.MobileNo, forgotmpin.Email).First(&EmailMap).Error
// 		if err != nil {
// 			Zerologs.Error().Msg("Forgot_MPin(): User email data not found for MobileNo=" + forgotmpin.MobileNo + " and Email=" + forgotmpin.Email + "and error is " + err.Error())
// 			token["errMsg"] = "Wrong Email"
// 			return token, nil
// 		}
// 		var userData clientmaster.JwtAuthMaster
// 		err = Db.Client.Where("mobile_no=?", forgotmpin.MobileNo).First(&userData).Error
// 		if err != nil {
// 			Zerologs.Error().Msg("Forgot_MPin(): User data not found for mobileno=" + forgotmpin.MobileNo + " and error is " + err.Error())
// 			token["errMsg"] = "User details not available"
// 			return token, nil
// 		}
// 		if userData.MPINFailedCount >= Env.MAX_MPIN_ATTEMPT {
// 			Zerologs.Info().Msg("Forgot_Password(): Mobileno=" + forgotmpin.MobileNo + " is blocked, please unblock and try again")
// 			token["errMsg"] = "User is blocked, please unblock and try again"
// 			return token, nil
// 		}
// 		token, err = GenerateJWTWithRefresh(userData.MobileNo, userData.Email, "")
// 		if err != nil {
// 			// fmt.Println("GenerateJWTWithRefresh Erro = " + err.Error())
// 			Zerologs.Error().Msg("Forgot_Password(): Error in GenerateJWTWithRefresh for mobileno=" + userData.MobileNo + " and email=" + userData.Email + " is " + err.Error())
// 			return nil, err
// 		}
// 		//user verify and redirect to set pass page.
// 		token["url"] = "/sign/setnewmpin"
// 		return token, nil
// 	} else {
// 		token["errMsg"] = resp["errMsg"]
// 		return token, nil
// 	}
// }

// func ForgotMpinApiHandlerService(retrievedState interface{}, forgotMpinReq model.ForgotMPin) (map[string]string, error) {
// 	token := make(map[string]string)
// 	RetriveState := retrievedState.(string)
// 	resp := Verify_OTP(forgotMpinReq.MobileNo, forgotMpinReq.OTP)
// 	if resp["Msg"] == "Success" {
// 		var userData clientmaster.JwtAuthMaster
// 		err := Db.Client.Where("mobile_no=?", forgotMpinReq.MobileNo).First(&userData).Error
// 		if err != nil {
// 			Zerologs.Error().Msg("ForgotMpinApiHandler(): User data not found where mobileno= " + forgotMpinReq.MobileNo + err.Error())
// 			token["errMsg"] = "User details not found in JwtAuthMaster"
// 			return token, nil
// 		}
// 		if userData.MPINFailedCount >= Env.MAX_MPIN_ATTEMPT {
// 			Zerologs.Info().Msg(" User is blocked for mobile no= " + forgotMpinReq.MobileNo + " please unblock and try again " + err.Error())
// 			token["errMsg"] = "User is blocked, please unblock and try again"
// 			return token, nil
// 		}
// 		//	RetriveState := retrievedState.(string)
// 		err = RedisLib.Client.Set(RetriveState, userData.UserGuid, time.Duration(60*time.Second)).Err()
// 		if err != nil {
// 			Zerologs.Error().Msg("ForgotMpinApiHandler(): User guid not set in redis for guid:= " + userData.UserGuid + err.Error())
// 			return nil, err
// 		}
// 		//user verify and redirect to set pass page.
// 		token["url"] = "/sign/setmpin?state=" + retrievedState.(string)
// 		return token, nil
// 	} else {
// 		if token["otpCnt"] == "2" {
// 			imgBase64Str := CreateCaptcha(forgotMpinReq.MobileNo)
// 			token["img64"] = imgBase64Str
// 			token["isOtp"] = "1"
// 			return token, nil
// 		} else {
// 			token["errMsg"] = resp["errMsg"]
// 			return token, nil
// 		}
// 	}
// }
