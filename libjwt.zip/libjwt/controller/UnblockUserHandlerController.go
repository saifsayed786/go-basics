package controller

import (
	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/model"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/gin"
)

func UnblockUserHandler(c *gin.Context) {
	libhttp.CoreHeader(c)

	var usermodel model.UnblockUser
	if err := c.BindJSON(&usermodel); err != nil {
		service.Zerologs.Error().Msg("UnblockUserHandler(): Error while json binding  model.UnblockUser= " + err.Error())
		return
	}
	response := service.UnblockUserHandlerService(usermodel)
	c.JSON(response.StatusCode, response)

}
