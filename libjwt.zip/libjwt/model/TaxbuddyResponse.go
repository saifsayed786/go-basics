package model

type TaxBuddyResponse struct {
	Success bool        `json:"success"`
	Error   interface{} `json:"error"`
	Message string      `json:"message"`
	Data    struct {
		Token                  string `json:"token"`
		ValidityInMilliseconds int    `json:"validityInMilliseconds"`
		TokenType              string `json:"tokenType"`
		PartnerInfo            struct {
			RegDate       string `json:"regDate"`
			OnboardDate   string `json:"onboardDate"`
			TimeZone      string `json:"timeZone"`
			PartnerId     string `json:"partnerId"`
			Code          string `json:"code"`
			Name          string `json:"name"`
			WebDomain     string `json:"webDomain"`
			SystemSetting struct {
				SettingId                  string      `json:"settingId"`
				SessionTimeOutInMin        int         `json:"sessionTimeOutInMin"`
				AllowFnbToManageTickets    bool        `json:"allowFnbToManageTickets"`
				TimeOutRedirectUrl         string      `json:"timeOutRedirectUrl"`
				PoweredBy                  interface{} `json:"poweredBy"`
				InvestNowLink              interface{} `json:"investNowLink"`
				PoweredByProduct           string      `json:"poweredByProduct"`
				InvestNowAction            string      `json:"investNowAction"`
				InvestNowPlaceHolder       string      `json:"investNowPlaceHolder"`
				ElssAction                 string      `json:"elssAction"`
				ElssPlaceHolder            string      `json:"elssPlaceHolder"`
				HealthInsuranceAction      string      `json:"healthInsuranceAction"`
				HealthInsurancePlaceHolder string      `json:"healthInsurancePlaceHolder"`
				LifeInsuranceAction        string      `json:"lifeInsuranceAction"`
				LifeInsurancePlaceHolder   string      `json:"lifeInsurancePlaceHolder"`
				ExpertAdviceAction         string      `json:"expertAdviceAction"`
				ExpertAdvicePlaceHolder    interface{} `json:"expertAdvicePlaceHolder"`
				PdVideoUrl                 string      `json:"pdVideoUrl"`
				CasVideoUrl                string      `json:"casVideoUrl"`
			} `json:"systemSetting"`
			ModuleSubDetails interface{} `json:"moduleSubDetails"`
		} `json:"partnerInfo"`
		ApplyWBagain  bool `json:"applyWBagain"`
		ApplyTPAagain bool `json:"applyTPAagain"`
		ApplyPDagain  bool `json:"applyPDagain"`
	} `json:"data"`
}
