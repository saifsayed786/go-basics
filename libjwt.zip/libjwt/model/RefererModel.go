package model

type RefererModel struct {
	Url string `json:"url"`
}
