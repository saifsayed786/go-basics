package service

// import "fmt"

// var ch = make(chan []interface{}, 20000)

// func Init() error {

// 	var val []interface{}
// 	Enqueue(val)
// 	go Dequeue(ch)
// 	return nil
// }

// func Enqueue(val []interface{}) {
// 	ch <- val
// 	close(ch)
// }

// func Dequeue(ch chan []interface{}) {
// 	abc := <-ch
// 	if len(abc) == 0 {
// 		fmt.Println("")
// 	}

// }
