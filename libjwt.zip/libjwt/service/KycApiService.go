package service

import (
	"io/ioutil"
	"net/http"
)

func KycApi(mobileno string, email string) {
	url := "https://www.nuuu.com/kycapi/SaveSSOData?MobileNo=" + mobileno + "&Email=" + email

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		Zerologs.Error().Msg("KycApi(): Error in http.NewRequest for mobileno=" + mobileno + " and email=" + email + " and error is : " + err.Error())
		// os.Exit(1)
		return
	}
	// req.Header.Set("Content-Type", "application/json")

	client := &http.Client{}
	rep, err := client.Do(req)
	if err != nil {
		Zerologs.Error().Err(err).Msg("KycApi(): Client DO error is " + err.Error() + " and URL=" + url)
		// panic(err)
		return
	}
	defer rep.Body.Close()
	// fmt.Println("response Status:", rep.Status)
	// fmt.Println("response Headers:", rep.Header)
	_, err = ioutil.ReadAll(rep.Body)
	if err != nil {
		// fmt.Println(err)
		Zerologs.Error().Err(err).Msg("KycApi(): Client DO response read error is " + err.Error())
		return
	}
	// fmt.Println("response Body:", string(body))
}
