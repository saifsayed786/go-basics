package model

type GenerateOTPModel struct {
	MobileNo string `json:"mobileno"`
	Type     uint   `json:"type"`
}
type Otpmodel struct {
	Otp string `json:"otp"`
}
type GenerateTOTPModel struct {
	QRCode    string `json:"QRCode"`
	SecretKey string `json:"Secretkey"`
}
type GenerateOTPModelResponse struct {
	// ErrMsg string `json:"errMsg"`
	Msg string `json:"Msg"`
}
