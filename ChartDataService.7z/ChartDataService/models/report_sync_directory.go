package models

type ReportSyncDirectoryDTO struct {
	FromDir     string `json:"fromDir"`
	ToDir       string `json:"toDir"`
	ScripName   string `json:"ScripName"`
	FromDate    string `json:"fromDate"`
	ToDate      string `json:"toDate"`
	ExchangeName string `json:"exchangeName"`
}
