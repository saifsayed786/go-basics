package controller

import (
	"github.com/gin-gonic/gin"
)

func AddMPINHandler(c *gin.Context) {
	// 	libhttp.CoreHeader(c)
	// 	session := sessions.Default(c)
	// 	retrievedState := session.Get("state")
	// 	cquery := c.Query("state")
	// 	if retrievedState != cquery {
	// 		service.Zerologs.Error().Msg("SetMPINApiHandler(): retrievedState and cquery is not equal:=  " + retrievedState.(string) + " -- " + cquery)
	// 		// c.AbortWithError(http.StatusUnauthorized, fmt.Errorf("Invalid session state: %s", retrievedState))
	// 		// return
	// 	}
	// 	// state = randToken()
	// 	// session := sessions.Default(c)
	// 	c.Writer.Write(helper.Mpintemplate)
	// }

	// func AddMPIN(c *gin.Context) {
	// 	libhttp.CoreHeader(c)
	// 	mobile_no, err := service.GetUser(c)
	// 	if err != nil {
	// 		service.Zerologs.Error().Err(err).Msg("AddMPIN(): Unauthorized")
	// 		c.JSON(http.StatusUnauthorized, "Unauthorized")
	// 		return
	// 	}
	// 	MobileNo := strconv.FormatUint(uint64(mobile_no), 10)
	// 	//fmt.Println(" step 1 mobile_no", MobileNo)
	// 	var mpinmodel model.MpinModel
	// 	err = c.BindJSON(&mpinmodel)
	// 	if err != nil {
	// 		// fmt.Println("Bind Data Failed")
	// 		service.Zerologs.Error().Msg("AddMPIN(): Error in c.BindJSON is " + err.Error())
	// 		c.JSON(http.StatusBadRequest, "")
	// 		return
	// 	}
	// 	response, err := service.AddMPINService(MobileNo, mpinmodel)
	// 	if err != nil {
	// 		c.JSON(http.StatusInternalServerError, err.Error())
	// 		return
	// 	}
	// 	result, ok := response["errMsg"]
	// 	if ok {
	// 		c.JSON(500, result)
	// 		return
	// 	}
	// 	c.JSON(200, response)

}
