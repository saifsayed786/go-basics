package model

type Profile struct {
	// COMPANY_CODE             string `json:"COMPANY_CODE"`
	// ASS_CLIENT_ID            string `json:"ASS_CLIENT_ID"`
	// CLIENT_ID_FAX            string `json:"CLIENT_ID_FAX"`
	CLIENT_ID_MAIL string `json:"CLIENT_ID_MAIL"`
	UCC_CLIENT_ID  string `json:"UCC_CLIENT_ID"`
	UCLIENT_ID     string `json:"UCLIENT_ID"`
	CLIENT_ID      string `json:"CLIENT_ID"`
	MOBILE_NO      string `json:"MOBILE_NO"`
	// CL_RESI_ADD1             string `json:"CL_RESI_ADD1"`
	// CL_RESI_ADD2             string `json:"CL_RESI_ADD2"`
	// CL_RESI_ADD3             string `json:"CL_RESI_ADD3"`
	// PIN_CODE                 int    `json:"PIN_CODE"`
	// CITY                     string `json:"CITY"`
	// STATE                    string `json:"STATE"`
	// COUNTRY                  string `json:"COUNTRY"`
	// ANNUAL_INCOME            string `json:"ANNUAL_INCOME"`
	// GROSSANNUALINCOMEDATE    string `json:"GROSSANNUALINCOMEDATE"`
	// NET_WORTH_DATE           string `json:"NET_WORTH_DATE"`
	// APPLICATION_NO           string `json:"APPLICATION_NO"`
	// RELATIONSHIPMOBILE       int    `json:"RELATIONSHIPMOBILE"`
	// RELATIONSHIPEMAILID      string `json:"RELATIONSHIPEMAILID"`
	// AADHARCARD               string `json:"AADHARCARD"`
	// FATHER_HUSBAND_NAME      string `json:"FATHER_HUSBAND_NAME"`
	SEX string `json:"SEX"`
	// MARITAL_STATUS           string `json:"MARITAL_STATUS"`
	// OCCUPATION               string `json:"OCCUPATION"`
	// BIRTH_DATE               string `json:"BIRTH_DATE"`
	// STATMENT_OPTION          string `json:"STATMENT_OPTION"`
	// MTF_INTEREST             int    `json:"MTF_INTEREST"`
	// MTF_MAX_AMOUNT           int    `json:"MTF_MAX_AMOUNT"`
	// MTFCL                    string `json:"MTFCL"`
	// MTFCLAUTO                string `json:"MTFCLAUTO"`
	// IBT_FLAG                 string `json:"IBT_FLAG"`
	// PAYMENT_REQUEST          string `json:"PAYMENT_REQUEST"`
	// GRP1ACTIVE               string `json:"GRP1ACTIVE"`
	// GRP2ACTIVE               string `json:"GRP2ACTIVE"`
	CLIENT_NAME string `json:"CLIENT_NAME"`
	// CLIENT_DP_CODE           int    `json:"CLIENT_DP_CODE"`
	// CLIENT_DP_NAME           string `json:"CLIENT_DP_NAME"`
	// DP_ID                    int    `json:"DP_ID"`
	// DP_NAME                  string `json:"DP_NAME"`
	// BROKERAGE_MODULE         int    `json:"BROKERAGE_MODULE"`
	// POA                      string `json:"POA"`
	// EXCHANGE_ACTIVE_INACTIVE string `json:"EXCHANGE_ACTIVE_INACTIVE"`
	PAN string `json:"PAN"`
	// FORM_NO                  string `json:"FORM_NO"`
	// MOTHER_NAME              string `json:"MOTHER_NAME"`
	// NATIONALITY              string `json:"NATIONALITY"`
	// KRA_STATUS               string `json:"KRA_STATUS"`
	// UCC_STATUS               string `json:"UCC_STATUS"`
	// CLIENT_BANK_NAME         string `json:"CLIENT_BANK_NAME"`
	// CLIENT_BANK_ADDRESS      string `json:"CLIENT_BANK_ADDRESS"`
	// IFSCCODE                 string `json:"IFSCCODE"`
	// BANK_ACNO                string `json:"BANK_ACNO"`
	// FATCA_DECLARATION        string `json:"FATCA_DECLARATION"`
	// FATCA_DATE               string `json:"FATCA_DATE"`
	// FATCA_COUNTRY            string `json:"FATCA_COUNTRY"`
	// FATCA_TIN                int    `json:"FATCA_TIN"`
	// DEFAULT_ACC_DP           string `json:"DEFAULT_ACC_DP"`
	// DEPOSITORY               string `json:"DEPOSITORY"`
	PAN_NO        string `json:"PAN_NO"`
	PICTURE       string `json:"PICTURE"`
	KYC_DONE      bool   `json:"KYC_DONE"`
	FullName      string `json:"FullName"`
	Activated     bool   `json:"activated"`
	IsTotpEnabled int    `json:"isTotpEnabled"`
	ReferralCode  string `json:"referralCode"`
}

type ErrorMsg struct {
	ErrMsg string `json:"errMsg"`
	Status int    `json:"status"`
}
