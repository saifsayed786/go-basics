package service

import (
	"github.com/MACMREPO/libdb/clientmaster"
	"github.com/MACMREPO/libgochannel"
)

var (
	DBChannel = libgochannel.CreateQueue()
)

func dbEnqueue(ch chan<- any, mod libgochannel.ChanMod) {
	DBChannel <- mod
}

func enqueue(enqueueModel any) {
	dbEnqueue(DBChannel, libgochannel.ChanMod{Model: enqueueModel, Func: func(m any) {
		DequeueDBChannel(m)
	}})
}

func EnqueuToDBChannel(enqueueModel any) {
	enqueue(enqueueModel)
}

func DequeueDBChannel(dequeueModel any) {
	switch value := dequeueModel.(type) {
	case clientmaster.TblMobileEmailMapping:
		InsertInTblMobileEmailMapping(value)
	}

}

//last
