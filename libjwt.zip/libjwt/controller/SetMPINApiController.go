package controller

import (
	"github.com/gin-gonic/gin"
)

func SetMPINApiHandler(c *gin.Context) {
	// libhttp.CoreHeader(c)
	// session := sessions.Default(c)
	// retrievedState := session.Get("state")
	// cquery := c.Query("state")
	// if retrievedState != cquery {
	// 	// fmt.Println("add MPINHAndeler " + retrievedState.(string) + " -- " + cquery)
	// 	service.Zerologs.Error().Msg("SetMPINApiHandler(): retrievedState and cquery is not equal:=  " + retrievedState.(string) + " -- " + cquery)
	// 	// c.AbortWithError(http.StatusUnauthorized, fmt.Errorf("Invalid session state: %s", retrievedState))
	// 	// return
	// }
	// var setmpinmodel model.SetMpinModel
	// err := c.BindJSON(&setmpinmodel)
	// if err != nil {
	// 	service.Zerologs.Error().Msg("SetMPINApiHandler(): Error while json binding model= " + setmpinmodel.BrokerID + setmpinmodel.NewMpin + setmpinmodel.UID + setmpinmodel.DeviceInfo + setmpinmodel.DeviceName + err.Error())
	// 	c.JSON(http.StatusBadRequest, "")
	// 	return
	// }
	// if retrievedState == nil {
	// 	service.Zerologs.Error().Msg("SetMPINApiHandler(): retrievedState is null " + err.Error())
	// 	return
	// }
	// RetrievedState := retrievedState.(string)
	// response, err := service.SetMPINApiService(RetrievedState, setmpinmodel)
	// if err != nil {
	// 	c.JSON(500, err.Error)
	// 	return
	// }
	// c.JSON(200, RetrievedState)
}
