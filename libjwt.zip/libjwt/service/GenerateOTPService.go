package service

import (
	"errors"
	"fmt"
	"time"

	"github.com/MACMREPO/libdb/clientmaster"
	"github.com/MACMREPO/libjwt/model"
)

func GenerateOTPService(OtpModel model.GenerateOTPModel, mobileno string) (map[string]string, error) {
	token := make(map[string]string)
	if OtpModel.Type == 1 {
		var jwtDbData clientmaster.JwtAuthMaster
		err := Db.Client.Where("mobile_no=?", mobileno).First(&jwtDbData).Error
		if err != nil {
			Zerologs.Error().Msg("GenerateOTP(): Mobile number found empty in clientmaster.JwtAuthMaster " + err.Error())
			token["errMsg"] = "Invalid Mobile Number"
			return token, nil
		}
	}
	currentTime := time.Now()
	otp := RandomInt(Env.OTPDIGIT)
	var mobOtpdata clientmaster.TblMobileOtp
	err := Db.Client.Where("mobile_no=?", mobileno).First(&mobOtpdata).Error
	if err != nil {
		mobOtpdata.MobileNo = mobileno
		mobOtpdata.Otp = otp
		mobOtpdata.OtpAttempt = 0
		mobOtpdata.OtpBlockTime = time.Now()
		err := Db.Client.Create(&mobOtpdata).Error
		if err != nil {
			Zerologs.Error().Err(err).Msg("GenerateOTP(): Error in executing Db.Client.Create(&mobOtpdata) for mobile: " + mobileno + err.Error())
			return nil, err
		}
		// if err := RedisLib.Client.Set(mobileno, otp, time.Second*180).Err(); err != nil {
		if err := RedisLib.Client.Set(mobileno, otp, 0).Err(); err != nil {
			Zerologs.Error().Err(err).Msg("GenerateOTP(): Error Inserting Otp in redis for mobile: " + mobileno + err.Error())
			return nil, err
		}
		var Otpmodel model.CommonOtpmodel
		Otpmodel.Actiontype = 1
		Otpmodel.OTP = otp
		Otpmodel.OldNumber = mobileno
		// err = SendSMSService(OTPtemplateforNewNumber, Otpmodel.OldNumber, Otpmodel)
		// if err != nil {
		// 	Zerologs.Error().Err(err).Msg("GenerateOTP():Error While Sending sms service for mobileno: " + Otpmodel.OldNumber + err.Error())
		// 	return nil, err
		// }
		token["Msg"] = "OTP sent successfully on " + mobileno
		return token, nil
	} else {
		if mobOtpdata.OtpAttempt >= 3 {
			BlockTime := mobOtpdata.OtpBlockTime
			// Block_Time := BlockTime.Format("2006/01/02 15:04:05")
			dif := currentTime.Sub(BlockTime)
			// fmt.Println(dif)
			minute := int(dif.Minutes())
			// fmt.Println(minute)
			if minute <= 15 {
				Zerologs.Error().Msg("User " + mobileno + " is blocked for 15 minutes")
				token["errMsg"] = "please try again later,user blocked for 15 minutes"
				return token, nil
			} else {
				// if err := RedisLib.Client.Set(mobileno, otp, time.Second*180).Err(); err != nil {
				if err := RedisLib.Client.Set(mobileno, otp, 0).Err(); err != nil {
					Zerologs.Error().Err(err).Msg("GenerateOTP(): Error Inserting Otp in redis for mobile: " + mobileno + err.Error())
					return nil, err
				}
				var Otpmodel model.CommonOtpmodel
				Otpmodel.Actiontype = 1
				Otpmodel.OTP = otp
				Otpmodel.OldNumber = mobileno
				// err = SendSMSService(OTPtemplateforNewNumber, Otpmodel.OldNumber, Otpmodel)
				// if err != nil {
				// 	Zerologs.Error().Err(err).Msg("GenerateOTP():Error While Sending sms service for mobileno: " + Otpmodel.OldNumber + err.Error())
				// 	// fmt.Println(err)
				// 	return nil, err
				// }
				err := Db.Client.Model(clientmaster.TblMobileOtp{}).Where("mobile_no=?", mobileno).Update("otp_attempt", 0).Error
				if err != nil {
					fmt.Println(err)
					return nil, err
				}
				token["Msg"] = "OTP sent successfully on " + mobileno
				return token, nil
			}
		} else {
			// if err := RedisLib.Client.Set(mobileno, otp, time.Second*180).Err(); err != nil {
			if err := RedisLib.Client.Set(mobileno, otp, 0).Err(); err != nil {
				Zerologs.Error().Err(err).Msg("GenerateOTP(): Error Inserting Otp in redis for mobile: " + mobileno + err.Error())
				return nil, err
			}
			var Otpmodel model.CommonOtpmodel
			Otpmodel.Actiontype = 1
			Otpmodel.OTP = otp
			Otpmodel.OldNumber = mobileno
			// err = SendSMSService(OTPtemplateforNewNumber, Otpmodel.OldNumber, Otpmodel)
			// if err != nil {
			// 	Zerologs.Error().Err(err).Msg("GenerateOTP():Error While Sending sms service for mobileno: " + Otpmodel.OldNumber + err.Error())
			// 	// fmt.Println(err)
			// 	return nil, err
			// }
			err := Db.Client.Model(clientmaster.TblMobileOtp{}).Where("mobile_no=?", mobileno).Update("otp_attempt", 0).Error
			if err != nil {
				fmt.Println(err)
				return nil, err
			}
			token["Msg"] = "OTP sent successfully on " + mobileno
			return token, nil
		}
	}
}

func GenerateOTPService_NEW(OtpModel model.GenerateOTPModel, mobileno string) (model.GenerateOTPModelResponse, error) {
	var OTPModelResponse model.GenerateOTPModelResponse
	if OtpModel.Type == 1 {
		var jwtDbData clientmaster.JwtAuthMaster
		err := Db.Client.Where("mobile_no=?", mobileno).First(&jwtDbData).Error
		if err != nil {
			Zerologs.Error().Msg("GenerateOTP(): Mobile number found empty in clientmaster.JwtAuthMaster " + err.Error())
			//token["errMsg"] = "Invalid Mobile Number"
			// OTPModelResponse.ErrMsg = "Invalid Mobile Number"
			return OTPModelResponse, errors.New("Invalid Mobile Number")
		}
	}
	currentTime := time.Now() 
	otp := RandomInt(Env.OTPDIGIT)
	var mobOtpdata clientmaster.TblMobileOtp
	err := Db.Client.Where("mobile_no=?", mobileno).First(&mobOtpdata).Error
	if err != nil {
		mobOtpdata.MobileNo = mobileno
		mobOtpdata.Otp = otp
		mobOtpdata.OtpAttempt = 0
		mobOtpdata.OtpBlockTime = time.Now()
		err := Db.Client.Create(&mobOtpdata).Error
		if err != nil {
			Zerologs.Error().Err(err).Msg("GenerateOTP(): Error in executing Db.Client.Create(&mobOtpdata) for mobile: " + mobileno + err.Error())
			return OTPModelResponse, err
		}
		// if err := RedisLib.Client.Set(mobileno, otp, time.Second*180).Err(); err != nil {
		if err := RedisLib.Client.Set(mobileno, otp, 0).Err(); err != nil {
			Zerologs.Error().Err(err).Msg("GenerateOTP(): Error Inserting Otp in redis for mobile: " + mobileno + err.Error())
			return OTPModelResponse, err
		}
		var Otpmodel model.CommonOtpmodel
		Otpmodel.Actiontype = 1
		Otpmodel.OTP = otp
		Otpmodel.OldNumber = mobileno
		// err = SendSMSService(OTPtemplateforNewNumber, Otpmodel.OldNumber, Otpmodel)
		// if err != nil {
		// 	Zerologs.Error().Err(err).Msg("GenerateOTP():Error While Sending sms service for mobileno: " + Otpmodel.OldNumber + err.Error())
		// 	return nil, err
		// }
		OTPModelResponse.Msg = "OTP sent successfully on " + mobileno
		// token["Msg"] = "OTP sent successfully on " + mobileno
		return OTPModelResponse, nil
	} else {
		if mobOtpdata.OtpAttempt >= 3 {
			BlockTime := mobOtpdata.OtpBlockTime
			// Block_Time := BlockTime.Format("2006/01/02 15:04:05")
			dif := currentTime.Sub(BlockTime)
			// fmt.Println(dif)
			minute := int(dif.Minutes())
			// fmt.Println(minute)
			if minute <= 15 {
				Zerologs.Error().Msg("User " + mobileno + " is blocked for 15 minutes")
				// token["errMsg"] = "please try again later,user blocked for 15 minutes"
				// OTPModelResponse.ErrMsg = "please try again later,user blocked for 15 minutes"
				return OTPModelResponse, errors.New("Please try again later, user is blocked for 15 minutes.")
			} else {
				// if err := RedisLib.Client.Set(mobileno, otp, time.Second*180).Err(); err != nil {
				if err := RedisLib.Client.Set(mobileno, otp, 0).Err(); err != nil {
					Zerologs.Error().Err(err).Msg("GenerateOTP(): Error Inserting Otp in redis for mobile: " + mobileno + err.Error())
					return OTPModelResponse, err
				}
				var Otpmodel model.CommonOtpmodel
				Otpmodel.Actiontype = 1
				Otpmodel.OTP = otp
				Otpmodel.OldNumber = mobileno
				// err = SendSMSService(OTPtemplateforNewNumber, Otpmodel.OldNumber, Otpmodel)
				// if err != nil {
				// 	Zerologs.Error().Err(err).Msg("GenerateOTP():Error While Sending sms service for mobileno: " + Otpmodel.OldNumber + err.Error())
				// 	// fmt.Println(err)
				// 	return nil, err
				// }
				err := Db.Client.Model(clientmaster.TblMobileOtp{}).Where("mobile_no=?", mobileno).Update("otp_attempt", 0).Error
				if err != nil {
					fmt.Println(err)
					return OTPModelResponse, err
				}
				//token["Msg"] = "OTP sent successfully on " + mobileno
				OTPModelResponse.Msg = "OTP sent successfully on " + mobileno
				return OTPModelResponse, nil
			}
		} else {
			// if err := RedisLib.Client.Set(mobileno, otp, time.Second*180).Err(); err != nil {
			if err := RedisLib.Client.Set(mobileno, otp, 0).Err(); err != nil {
				Zerologs.Error().Err(err).Msg("GenerateOTP(): Error Inserting Otp in redis for mobile: " + mobileno + err.Error())
				return OTPModelResponse, err
			}
			var Otpmodel model.CommonOtpmodel
			Otpmodel.Actiontype = 1
			Otpmodel.OTP = otp
			Otpmodel.OldNumber = mobileno
			// err = SendSMSService(OTPtemplateforNewNumber, Otpmodel.OldNumber, Otpmodel)
			// if err != nil {
			// 	Zerologs.Error().Err(err).Msg("GenerateOTP():Error While Sending sms service for mobileno: " + Otpmodel.OldNumber + err.Error())
			// 	// fmt.Println(err)
			// 	return nil, err
			// }
			err := Db.Client.Model(clientmaster.TblMobileOtp{}).Where("mobile_no=?", mobileno).Update("otp_attempt", 0).Error
			if err != nil {
				fmt.Println(err)
				return OTPModelResponse, err
			}
			//token["Msg"] = "OTP sent successfully on " + mobileno
			OTPModelResponse.Msg = "OTP sent successfully on " + mobileno
			return OTPModelResponse, nil
		}
	}
}
