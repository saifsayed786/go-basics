package service

import (
	"net/http"
	"time"

	"github.com/MACMREPO/libjwt/helper"
	"github.com/MACMREPO/libjwt/model"
)

func ValidateLoginService(MobileNo string, UserKey model.ValidateLoginModel, retrievedState interface{}) model.ValidateLoginResponse {
	var responseModel model.ValidateLoginResponse
	// var jwtUser clientmaster.JwtAuthMaster
	// err := Db.Client.Where("mobile_no=?", MobileNo).First(&jwtUser).Error
	jwtUser, err := getJwtAuthMasterDB(helper.CLIENT_MOBILE_PARAM, MobileNo)
	if err != nil {
		Zerologs.Error().Msg("GetProfileHandler(): User data not found for mobileNo: " + MobileNo + err.Error())
		responseModel.IsErr = true
		responseModel.Msg = err.Error()
		responseModel.StatusCode = http.StatusInternalServerError
		return responseModel
	}
	RetriveState := retrievedState.(string)
	// err = RedisLib.Client.Set(RetriveState, jwtUser.UserGuid, time.Hour*24).Err()
	err = setDataInRedis(RetriveState, jwtUser.UserGuid, time.Hour*24)
	if err != nil {
		Zerologs.Error().Msg("NormalLoginHandler():UserGUID not set in redis for retriveStat:=  " + RetriveState + err.Error())
		responseModel.IsErr = true
		responseModel.Msg = err.Error()
		responseModel.StatusCode = http.StatusInternalServerError
		return responseModel
	}
	// token["url"] = "/sso"
	if jwtUser.PasswordFailedCount >= Env.MAX_PASSWORD_ATTEMPT {
		responseModel.IsErr = true
		responseModel.Msg = " User is blocked , please unblock and try again"
		responseModel.StatusCode = http.StatusInternalServerError
		responseModel.Url = "/sign/glogin"
		return responseModel

	} else {
		if jwtUser.IsPasswordReset {
			if jwtUser.KYCDone == true {
				if jwtUser.Activated {

					responseModel.IsErr = false
					responseModel.Msg = "Success"
					responseModel.StatusCode = http.StatusOK
					responseModel.Url = Env.GOOGLE_MAIN_PAGE
					responseModel.RefreshToken = jwtUser.Refreshtoken
					return responseModel
					// redirect to setmpin
					// if jwtUser.IsMPIN_Reset == false {
					// 	token["url"] = "/sign/setmpin?state=" + retrievedState.(string)
					// 	return token, nil
					// } else {
					// 	token["refresh_token"] = jwtUser.Refreshtoken
					// 	token["url"] = Env.GOOGLE_MAIN_PAGE
					// 	return token, nil
					// }
				} else {
					responseModel.IsErr = false
					responseModel.Msg = "Success"
					responseModel.StatusCode = http.StatusOK
					responseModel.Url = Env.GOOGLE_MAIN_PAGE
					responseModel.RefreshToken = jwtUser.Refreshtoken
					return responseModel
				}
			} else {
				responseModel.IsErr = false
				responseModel.Msg = "Success"
				responseModel.StatusCode = http.StatusOK
				responseModel.Url = Env.GOOGLE_MAIN_PAGE
				responseModel.RefreshToken = jwtUser.Refreshtoken
				return responseModel
			}
		} else {
			responseModel.IsErr = false
			responseModel.Msg = "Success"
			responseModel.StatusCode = http.StatusOK
			responseModel.Url = "/sign/setpassword?state=" + retrievedState.(string)
			responseModel.RefreshToken = jwtUser.Refreshtoken
			return responseModel
		}
	}
}
