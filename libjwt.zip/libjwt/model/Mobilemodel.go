package model

type MobileModel struct {
	Mobileno   string `json:"Mobileno" binding:"required"`
	OTP        string `json:"OTP" binding:"required"`
	Password   string `json:"Password" binding:"required"`
	Email      string `json:"Email" binding:"required"`
	UID        string `json:"uid"`
	Pwd        string `json:"pwd"`
	BrokerID   string `json:"brokerId"`
	Source     string `json:"source" binding:"required"`
	DeviceName string `json:"deviceName"`
	DeviceInfo string `json:"deviceInfo"`
}

type AddMobileModel struct {
	Mobileno        string `json:"Mobileno" binding:"required"`
	OTP             string `json:"OTP"`
	Password        string `json:"Password"`
	ConfirmPassword string `json:"confirmPassword"`
}
type AddMobileModelRes struct {
	IsError       string `json:"isError"`
	Msg           string `json:"msg"`
	IsKyc         string `json:"isKyc"`
	IsActivated   string `json:"isActivated"`
	IsPasswordSet string `json:"isPasswordSet"`
}
