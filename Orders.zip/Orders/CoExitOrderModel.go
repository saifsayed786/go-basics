package model

type CoExitOrderModel struct {
	UserType             string `json:"user_type,omitempty"`
	ModorderValidity     string `json:"modorder_validity,omitempty"`
	ModorderNumber       string `json:"modorder_number,omitempty"`
	Modproductlist       string `json:"modproductlist,omitempty"`
	ModfTriggerPrice     string `json:"modfTriggerPrice,omitempty"`
	OfflineFlag          string `json:"offline_flag,omitempty"`
	Disclosequantity     string `json:"disclosequantity,omitempty"`
	TokenID              string `json:"token_id,omitempty"`
	Quantitytype         string `json:"quantitytype,omitempty"`
	ModtradedQty         string `json:"modtraded_qty,omitempty"`
	Securityid           string `json:"securityid,omitempty"`
	Modquantity          string `json:"modquantity,omitempty"`
	InstType             string `json:"inst_type,omitempty"`
	Buysell              string `json:"buysell,omitempty"`
	ModorderType         string `json:"modorder_type,omitempty"`
	ModorderSerialNumber string `json:"modorder_serial_number,omitempty"`
	Source               string `json:"source,omitempty"`
	ILegValue            string `json:"iLegValue,omitempty"`
	UserID               string `json:"user_id,omitempty"`
	ClientID             string `json:"client_id,omitempty"`
	ModqtyRemng          string `json:"modqty_remng,omitempty"`
	Modprice             string `json:"modprice,omitempty"`
	FillQty              string `json:"fillQty,omitempty"`
	Exchange             string `json:"exchange,omitempty"`
	MarketProflag        string `json:"marketProflag,omitempty"`
	MarketProVal         string `json:"marketProVal,omitempty"`
	ParticipantType      string `json:"ParticipantType,omitempty"`
	Settlor              string `json:"settlor,omitempty"`
	Gtcflag              string `json:"Gtcflag,omitempty"`
	EncashFlag           string `json:"EncashFlag,omitempty"`
	PanID                string `json:"pan_id,omitempty"`
	Algoid               string `json:"algoid,omitempty"`
	Remark1              string `json:"remark1,omitempty"`
	Remarks2             string `json:"remarks2,omitempty"`
}
