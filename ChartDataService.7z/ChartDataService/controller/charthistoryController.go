package controller

import (
	"bytes"
	"chartdataservice/models"
	"chartdataservice/service"
	"log"
	"runtime"

	"compress/gzip"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/TecXLab/libenv"
	"github.com/TecXLab/libhttp"
	"github.com/TecXLab/liblogs"
	"github.com/gin-gonic/gin"
	"github.com/golobby/container/v3"
	"github.com/rs/zerolog"
)

var (
	zerologs zerolog.Logger
	Env      libenv.Env
	Logger   = liblogs.Logger
)

func SaveChartHistoryZ(c *gin.Context) {
	var request models.NewChartRespModel
	reader, err := gzip.NewReader(c.Request.Body)
	if err != nil {
		return
	}
	defer reader.Close()
	buff, err := ioutil.ReadAll(reader)
	if err != nil {
		return
	}
	err = json.Unmarshal(buff, &request)
	if err != nil {
		Logger("Message: ", err, liblogs.Error, liblogs.PRINT)
		return
	}
	service.SaveHistory(request)
}

func SaveChartHistory(c *gin.Context) {
	var request models.NewChartRespModel
	err := c.ShouldBindJSON(&request)
	if err != nil {
		Logger("Message: ", err, liblogs.Error, liblogs.PRINT)

		return
	}
	service.SaveHistory(request)
	Logger("Exiting SaveChartHistory Controller", nil, liblogs.Info, liblogs.ZEROLOG)

}

func GetChartHistory(c *gin.Context) {

	//service.CDS_Enqueue_NSEEQ_Count.Inc()
	//fmt.Println(service.CDS_Enqueue_NSEEQ_Count)
	libhttp.CoreHeader(c)
	// reqToken := c.Request.Header.Get("Authorization")
	// splitToken := strings.Split(reqToken, "Bearer ")
	// reqToken = splitToken[1]
	// _, err := libjwt.VerifyUser(reqToken)
	// if err != nil {
	// 	zerologs.Error().Msg("libjwt.GetUser :=" + err.Error())
	// 	c.JSON(http.StatusUnauth+orized, "unauthorized")
	// 	return
	// }

	// var zerologs zerolog.Logger
	// container.NamedResolve(&zerologs, "zerologs")
	///582913/3minute?user_id=NQ8562&oi=1&from=2021-06-17&to=2021-06-27
	var symbol string
	var folder string
	var FromDate string
	var ToDate string
	var Exch int
	if c.Params[0].Key == "exch" {
		Exch, _ = strconv.Atoi(c.Params[0].Value)
	}
	if c.Params[1].Key == "symbol" {
		symbol = c.Params[1].Value
	}
	if c.Params[2].Key == "timefilter" {
		folder = c.Params[2].Value
	}
	if c.Params[3].Key == "from" {
		FromDate = c.Params[3].Value
	}
	if c.Params[4].Key == "to" {
		ToDate = c.Params[4].Value
	}
	if symbol == "" || folder == "" {
		c.JSON(400, gin.H{"status": "failed", "data": gin.H{"candles": nil}})
		return
	}
	_, err := time.Parse("20060102", FromDate)
	if err != nil {
		fmt.Println(err)
		c.JSON(400, gin.H{"status": "failed", "data": gin.H{"candles": nil}})
		return
	}
	_, err = time.Parse("20060102", ToDate)
	if err != nil {
		fmt.Println(err)
		c.JSON(400, gin.H{"status": "failed", "data": gin.H{"candles": nil}})
		return
	}
	// intFromDate, _ := strconv.Atoi(FromDate)
	// intToDate, _ := strconv.Atoi(ToDate)
	// if intFromDate < intToDate {
	// 	c.JSON(404, gin.H{
	// 		"status":     "error",
	// 		"message":    "from date cannot be after to date",
	// 		"data":       nil,
	// 		"error_type": "InputException",
	// 	})
	// 	return
	// }

	var data = service.GetHistoryData(Exch, strings.ToUpper(symbol), folder, FromDate, ToDate)

	c.JSON(http.StatusOK, gin.H{"status": "success", "data": gin.H{"candles": data}})
}
func GetChartHistoryZ(c *gin.Context) {
	//service.CDS_Enqueue_NSEEQ_Count.Inc()
	//fmt.Println(service.CDS_Enqueue_NSEEQ_Count)
	libhttp.CoreHeader(c)
	// reqToken := c.Request.Header.Get("Authorization")
	// splitToken := strings.Split(reqToken, "Bearer ")
	// reqToken = splitToken[1]
	// _, err := libjwt.VerifyUser(reqToken)
	// if err != nil {
	// 	zerologs.Error().Msg("libjwt.GetUser :=" + err.Error())
	// 	c.JSON(http.StatusUnauthorized, "unauthorized")
	// 	return
	// }

	// var zerologs zerolog.Logger
	// container.NamedResolve(&zerologs, "zerologs")
	///582913/3minute?user_id=NQ8562&oi=1&from=2021-06-17&to=2021-06-27
	var symbol string
	var folder string
	var FromDate string
	var ToDate string
	var Exch int
	if c.Params[0].Key == "exch" {
		Exch, _ = strconv.Atoi(c.Params[0].Value)
	}
	if c.Params[1].Key == "symbol" {
		symbol = c.Params[1].Value
	}
	if c.Params[2].Key == "timefilter" {
		folder = c.Params[2].Value
	}
	if c.Params[3].Key == "from" {
		FromDate = c.Params[3].Value
	}
	if c.Params[4].Key == "to" {
		ToDate = c.Params[4].Value
	}
	_, err := time.Parse("20060102", FromDate)
	if err != nil {
		fmt.Println(err)
		c.JSON(400, gin.H{"status": "failed", "data": gin.H{"candles": nil}})
		return
	}
	_, err = time.Parse("20060102", ToDate)
	if err != nil {
		fmt.Println(err)
		c.JSON(400, gin.H{"status": "failed", "data": gin.H{"candles": nil}})
		return
	}

	var data = service.GetHistoryData(Exch, strings.ToUpper(symbol), folder, FromDate, ToDate)
	cmpMap := gin.H{"status": "success", "data": gin.H{"candles": data}}
	responsedata, err := json.Marshal(cmpMap)
	if err != nil {
		fmt.Println(err)
	}
	compressedData, compressedDataErr := service.GzipData(responsedata)
	if compressedDataErr != nil {
		log.Fatal(compressedDataErr)
	}
	c.Request.Header.Set("Accept-Encoding", "gzip")
	// c.Request.Header.Set("Content-Disposition", "application/octet-stream")
	c.Request.Header.Set("Content-Type", "application/octect-stream")
	c.Writer.Header().Set("Accept-Encoding", "gzip")
	c.JSON(http.StatusOK, compressedData)
}

func Filecrongeneratetf(c *gin.Context) {
	libhttp.CoreHeader(c)
	var Exch string
	if c.Params[0].Key == "exch" {
		Exch = c.Params[0].Value
	}

	Inputdate := models.FileCronInput{Crondate: "", ExchId: Exch}
	err := c.ShouldBindJSON(&Inputdate)
	if err != nil {

		Logger("Message: ", err, liblogs.Error, liblogs.PRINT)

	}

	Logger(time.Now().String()+" File Cron File Cron Enque: Start", err, liblogs.Error, liblogs.PRINT|liblogs.SLACK)

	service.EnqueueFilecronData(Inputdate)

	Logger(time.Now().String()+" File Cron File Cron Enque: End", err, liblogs.Error, liblogs.PRINT|liblogs.SLACK)

}

func FileCronController(c *gin.Context) {
	libhttp.CoreHeader(c)
	Logger(time.Now().String()+" File Cron Controller Hit: Start", nil, liblogs.Debug, liblogs.PRINT|liblogs.SLACK)

	var Inputdate models.FileCronInput

	err := c.ShouldBindJSON(&Inputdate)
	if err != nil {

		Logger("Message: ", err, liblogs.Error, liblogs.PRINT)
	}

	Logger(time.Now().String()+" File Cron File Cron Enque: Start", nil, liblogs.Debug, liblogs.PRINT|liblogs.SLACK)

	service.EnqueueFilecronData(Inputdate)

	Logger(time.Now().String()+" File Cron File Cron Enque: End", nil, liblogs.Debug, liblogs.PRINT|liblogs.SLACK)

}

func FileCronController_Old(c *gin.Context) {

	Logger(time.Now().String()+"  File Cron Controller Hit: Start", nil, liblogs.Debug, liblogs.PRINT|liblogs.SLACK)

	var Inputdate models.FileCronInput
	var current_date = service.GetCurrentDate()
	var slackMsg string
	err := c.ShouldBindJSON(&Inputdate)
	if err != nil {
		fmt.Println(err)
	}
	if Inputdate.Crondate == "" && Inputdate.ExchId == "" {
		for ExName, val := range service.ExIds {
			// service.SentToContractCronJob(time.Now().String() + " IF Inside Loop: " + ExName + " TF File writing Started.")
			Logger(time.Now().String()+" IF Inside Loop: "+ExName+" TF File writing Started.", nil, liblogs.Debug, liblogs.PRINT|liblogs.SLACK)

			slackMsg = service.CreateFileCron(val, current_date, ExName)
			// err = service.SentToContractCronJob(slackMsg)
			Logger(slackMsg, nil, liblogs.Info, liblogs.SLACK)
			// if err != nil {
			// 	Logger("Error while sending to slack, msg : "+slackMsg, err, liblogs.Error, liblogs.PRINT)
			// }
		}
	} else {
		// service.SentToContractCronJob(time.Now().String() + " Inside Else: " + Inputdate.ExchId + " TF File writing Started.")
		// fmt.Println(time.Now().String() + " Inside Else: " + Inputdate.ExchId + " TF File writing Started.")
		Logger(time.Now().String()+" Inside Else: "+Inputdate.ExchId+" TF File writing Started.", nil, liblogs.Info, liblogs.PRINT|liblogs.SLACK)

		nexid, _ := strconv.Atoi(Inputdate.ExchId)
		slackMsg = service.CreateFileCron(int16(nexid), Inputdate.Crondate, service.GetExchngeName(int16(nexid)))
		// err = service.SentToContractCronJob(slackMsg)
		Logger(slackMsg, nil, liblogs.Info, liblogs.SLACK)

		// if err != nil {
		// 	Logger("Error while sending to slack, msg : "+slackMsg, err, liblogs.Error, liblogs.PRINT)

		// }
	}

	// service.SentToContractCronJob(time.Now().String() + " File Cron Controller Hit: End")
	Logger(time.Now().String()+" File Cron Controller Hit: End", nil, liblogs.Info, liblogs.PRINT|liblogs.SLACK)

}

func RawFileWritingController(c *gin.Context) {
	var zerologs zerolog.Logger
	err := container.NamedResolve(&zerologs, "zerologs")
	if err != nil {
		Logger("Log Lib Not Initialize", err, liblogs.Error, liblogs.ZEROLOG)

	}
	var request models.NewChartRespModel
	err = c.ShouldBindJSON(&request)
	if err != nil {
		Logger("Message: ", err, liblogs.Error, liblogs.PRINT)

		return
	}
	service.RawFileWriting(request)
}

func InitAllCron(c *gin.Context) {
	runtime.GC()
	result := service.InitAll()
	start := time.Now()
	elapsed := time.Since(start)
	str := fmt.Sprintf("%v", elapsed)
	// err := service.SentToContractCronJob(result + "\n" + str)
	Logger(result+"\n"+str, nil, liblogs.Info, liblogs.PRINT|liblogs.SLACK)
	runtime.GC()
	// if err != nil {
	// 	Logger("Error while sending to slack", err, liblogs.Error, liblogs.ZEROLOG|liblogs.PRINT)

	// }
}

func GenerateTFFileController(c *gin.Context) {
	// service.SentToContractCronJob(time.Now().String() + " GenerateTFFileController Hit: Start")
	Logger(time.Now().String()+" GenerateTFFileController Hit: Start", nil, liblogs.Info, liblogs.PRINT|liblogs.SLACK)

	var objData models.GenerateTFFileModel

	err := c.ShouldBindJSON(&objData)
	if err != nil {
		Logger("Message: ", err, liblogs.Error, liblogs.PRINT)

	}

	// service.SentToContractCronJob(time.Now().String() + " GenerateTFFileController Enque: Start")
	Logger(time.Now().String()+" GenerateTFFileController Enque: Start", nil, liblogs.Info, liblogs.PRINT|liblogs.SLACK)

	service.EnqueueFilecronData(objData)

	// service.SentToContractCronJob(time.Now().String() + " GenerateTFFileController Enque: End")
	Logger(time.Now().String()+" GenerateTFFileController Enque: End", nil, liblogs.Info, liblogs.PRINT|liblogs.SLACK)

}

func SendFileToProd(c *gin.Context) {
	var requestFile models.SendToProdModel
	err := container.NamedResolve(&zerologs, "zerologs")
	if err != nil {
		panic("Log Lib Not Initialize" + err.Error())
	}

	err = c.ShouldBindJSON(&requestFile)
	if err != nil {
		fmt.Println(err)
	}
	localFile, err := service.GetFilesFromLocal(requestFile.EcxhId, requestFile.FromDate, requestFile.ToDate)
	if err != nil {
		Logger("Message: ", err, liblogs.Error, liblogs.PRINT)

	}
	if len(localFile) == 0 {
		Logger("No files found in Localfile", nil, liblogs.Info, liblogs.PRINT)

		return
	}

	start := time.Now()
	// var UploadFileModel models.UploadFileModel

	if len(localFile) > 0 {
		batch := 500
		for k := 0; k < len(localFile); k += batch {
			l := k + batch
			if l > len(localFile) {
				l = len(localFile)
			}
			WriteRequest(localFile[k:l], requestFile)
		}
	}
	timeTaken := fmt.Sprintf("Time Taken To WriteAll Files %s\n", time.Since(start))
	c.JSON(200, timeTaken)
}

func GetFileFromLocal(c *gin.Context) {
	var BulkUploadFileModel models.BulkUploadFileModel
	err := c.ShouldBindJSON(&BulkUploadFileModel)
	if err != nil {
		fmt.Println(err)
	}
	service.EnqueuechSendProd(BulkUploadFileModel)
	time.Sleep(200 * time.Millisecond)

}

func WriteRequest(localFile []string, requestFile models.SendToProdModel) {
	var path string
	var UploadFileModel models.UploadFileModel
	var BulkUploadFileModel models.BulkUploadFileModel
	for i := range localFile {
		localFileData, err := os.ReadFile(localFile[i])
		if err != nil {
			fmt.Println(err)
			return
		}
		if requestFile.EcxhId == service.ExIds["nseeq"] {
			path = strings.Split(localFile[i], "\\nse1\\")[1]
		} else if requestFile.EcxhId == service.ExIds["nsefo"] {
			path = strings.Split(localFile[i], "\\nsefo1\\")[1]
		}
		UploadFileModel.Data = localFileData
		UploadFileModel.Path = path
		UploadFileModel.ExchId = requestFile.EcxhId
		BulkUploadFileModel.Bulkdata = append(BulkUploadFileModel.Bulkdata, UploadFileModel)
	}
	BulkUploadRequest(BulkUploadFileModel)
}
func BulkUploadRequest(bulkUploadModel models.BulkUploadFileModel) {
	data, err := json.Marshal(bulkUploadModel)
	if err != nil {
		Logger("Message: ", err, liblogs.Error, liblogs.PRINT)

	}
	buf := bytes.NewBuffer(data)
	client := &http.Client{}
	// req, err := http.NewRequest(http.MethodPost, "https://kyc.nuuu.com/chartdataservice/getFileFromlocal", buf)
	req, err := http.NewRequest(http.MethodPost, "http://localhost:8087/chartdataservice/getFileFromlocal", buf)
	if err != nil {

		Logger("Message: ", err, liblogs.Error, liblogs.PRINT)

	}
	resp, err := client.Do(req)
	if err != nil {
		Logger("Errored when sending request to the server: ", err, liblogs.Error, liblogs.PRINT)
		return
	}
	fmt.Println(resp.StatusCode)

}

func SaveHistory_Old(c *gin.Context) {
	path := "D:\\GitHub\\KubeVolumeData\\chartdataservice\\TrueData\\Indices"
	files, err := os.ReadDir(path)
	if err != nil {
		Logger("In SaveHistory", err, liblogs.Error, liblogs.ZEROLOG)
	}
	for i := range files {
		service.AddFileToQueue(path + "\\" + files[i].Name())
	}
}

func DeleteFilesController(c *gin.Context) {
	var DeleteRequest models.DeleteRequest
	err := c.ShouldBindJSON(&DeleteRequest)
	if err != nil {
		fmt.Println(err)
		return
	}
	err = service.DeleteFiles(DeleteRequest.Exch, DeleteRequest.Symbol, DeleteRequest.TimeFrame, DeleteRequest.Date)
	if err != nil {
		fmt.Println(err)
		return
	}
}

func GetDataFromStoreController(c *gin.Context) {
	token := c.Param("token")
	Exch := c.Param("exch")
	Ex, _ := strconv.Atoi(Exch)
	tk, _ := strconv.Atoi(token)
	data, err := service.GetDataFromStoreService(int16(Ex), int64(tk))
	if err != nil {
		fmt.Println(err)
		c.JSON(500, err)
		return
	}
	c.JSON(200, data)
}

func GetRawdataService(c *gin.Context) {
	token := c.Param("token")
	Exch := c.Param("exch")
	date := c.Param("date")
	Ex, _ := strconv.Atoi(Exch)
	tk, _ := strconv.Atoi(token)
	data, err := service.GetRawdata(date, int16(Ex), int64(tk))
	if err != nil {
		fmt.Println(err)
		c.JSON(500, err)
		return
	}
	c.JSON(200, data)

}

func ChangeFolderName(c *gin.Context) {
	err := service.ChangeFolderName()
	if err != nil {
		fmt.Println(err)
		return
	}
}
func ChangeFolderPermission(c *gin.Context) {
	var request models.ChangeFolderModel
	err := c.ShouldBindJSON(&request)
	if err != nil {
		fmt.Println(err)
		c.JSON(400, err)
		return
	}
	service.EnqueueFilecronData(request.Path)
}

func CopyFolders(c *gin.Context) {
	var request models.ChangeFolderModel
	err := c.ShouldBindJSON(&request)
	if err != nil {
		fmt.Println(err)
		c.JSON(400, err)
		return
	}
	service.EnqueueFilecronData(request.Path)
}
