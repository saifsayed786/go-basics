package service

import (
	"github.com/MACMREPO/libdb/clientmaster"
	"gorm.io/gorm/clause"
)

func AddReferralService(Referralreq clientmaster.ReferralMaster) (string, error) {
	Referralreq.ID = Referralreq.MobileNo + "_" + Referralreq.ReferralCode
	err := Db.Client.Clauses(clause.OnConflict{
		Columns:   []clause.Column{{Name: "id"}},
		DoUpdates: clause.AssignmentColumns([]string{"mobile_no", "referral_code"}),
	}).CreateInBatches(&Referralreq, 1000).Error
	if err != nil {
		Zerologs.Error().Msg("AddReferral(): Error while adding referral in database for MobileNo=" + Referralreq.MobileNo + " and ReferralCode=" + Referralreq.ReferralCode + " and Error is " + err.Error())
		return "", err
	}
	return "Success", nil
}
