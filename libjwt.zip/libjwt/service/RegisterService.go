package service

// func RegisterService(RetriveState, RedirectUrl string, usermodel model.JwtMaster) (map[string]string, error) {
// 	token := make(map[string]string)
// 	var tblEmailMap clientmaster.TblMobileEmailMapping
// 	err := Db.Client.Where("mobile_no", usermodel.MobileNo).First(&tblEmailMap).Error
// 	if err != nil {
// 		err = Db.Client.Where("email", usermodel.Email).First(&tblEmailMap).Error
// 		if err != nil {
// 			resp := Verify_OTP(usermodel.MobileNo, usermodel.MobileOtp)
// 			if resp["Msg"] == "Success" {
// 				var MobEmailModel clientmaster.TblMobileEmailMapping
// 				MobEmailModel.Email = usermodel.Email
// 				MobEmailModel.MobileNo = usermodel.MobileNo
// 				MobEmailModel.EmailVerified = true
// 				err = Db.Client.Create(&MobEmailModel).Error
// 				if err != nil {
// 					Zerologs.Error().Msg("Register(): Data not added in email-mobile mapping table for mobileNO= " + usermodel.MobileNo + " AND email:=  " + usermodel.Email + err.Error())
// 					return nil, err
// 				}
// 				usermodel.MobileVerified = true
// 				var guid uuid.UUID
// 				var guidData clientmaster.MobileGuidMaster
// 				err := Db.Client.Where("mobile_no=?", usermodel.MobileNo).First(&guidData).Error
// 				if err != nil {
// 					guid = uuid.New()
// 					guidData.UserGuid = guid
// 					guidData.MobileNo = usermodel.MobileNo
// 					err = Db.Client.Create(&guidData).Error
// 					if err != nil {
// 						Zerologs.Error().Msg("Register(): Data Not added in MobileGuidMaster table,query Db.Client.Create(&guidData)failed for user mobileNo= " + usermodel.MobileNo + err.Error())
// 						return nil, err
// 					}
// 				} else {
// 					guid = guidData.UserGuid
// 				}
// 				usermodel.UserGuid = helper.UuidToString(guid)
// 				usermodel.IsPasswordReset = true
// 				response, err := AddJwtMaster(usermodel)
// 				if err != nil {
// 					Zerologs.Error().Msg("Register():= Data Not Added in jwtauthmaster table for mobileNo= " + usermodel.MobileNo + err.Error())
// 					return nil, err
// 				}
// 				if response == "success" {
// 					var clientData clientmaster.JwtAuthMaster
// 					err := Db.Client.Where("mobile_no", usermodel.MobileNo).First(&clientData).Error
// 					if err != nil {
// 						Zerologs.Error().Msg("Register():= jwtauthmaster user data not found for mobileNo:=  " + usermodel.MobileNo + err.Error())
// 						return nil, err
// 					}

// 					//add entry for password in passhistory table
// 					var passwordhistory clientmaster.PasswordHistory
// 					passwordhistory.MobileNo = usermodel.MobileNo
// 					passwordhistory.LastPassword = usermodel.Password
// 					passwordhistory.LastPassword_UpdatedTime = time.Now()
// 					err = Db.Client.Create(&passwordhistory).Error
// 					if err != nil {
// 						Zerologs.Error().Msg("Error while add data in password history" + err.Error())
// 						return nil, err
// 					}

// 					err = AddWatchList(usermodel.MobileNo)
// 					if err != nil {
// 						Zerologs.Error().Msg("Register(): Watchlist not added for mobileNo: " + usermodel.MobileNo + err.Error())
// 						return nil, err
// 					}

// 					err = RedisLib.Client.Set(RetriveState, helper.UuidToString(guid), time.Duration(60*time.Second)).Err()
// 					if err != nil {
// 						Zerologs.Error().Msg(" Register(): User guid not set in redis (RedisLib.Client.Set) for mobile no:= " + clientData.MobileNo + " And GUID IS " + helper.UuidToString(guid) + err.Error())
// 						return nil, err
// 					}
// 					// token, err := GenerateJWTWithRefresh(usermodel.MobileNo, usermodel.Email)
// 					// if err != nil {
// 					// 	Zerologs.Error().Msg("Login libjwt.GenerateJWT " + err.Error())
// 					// 	c.JSON(200, "Invalid details: "+err.Error())
// 					// 	return
// 					// }
// 					// if RedirectUrl == "" || RedirectUrl == "https://www.nuuu.com/trade" || RedirectUrl == "https://www.nuuu.com/trade/" {
// 					if UrlsArr.CheckUrls(RedirectUrl) {
// 						token["Msg"] = "Register Successfully"
// 						token["url"] = "/sign/glogin"
// 						// fmt.Println(token["url"])
// 						return token, nil
// 					} else {
// 						token["Msg"] = "Register Successfully"
// 						token["url"] = RedirectUrl
// 						// fmt.Println(token["url"])
// 						return token, nil
// 					}
// 				}
// 			} else {
// 				token["errMsg"] = resp["errMsg"]
// 				return token, nil
// 			}
// 		} else {
// 			token["errMsg"] = "Email already registered"
// 			return token, nil
// 		}
// 	} else {
// 		resp := Verify_OTP(usermodel.MobileNo, usermodel.MobileOtp)
// 		if resp["Msg"] == "Success" {
// 			err = Db.Client.Where("email", usermodel.Email).First(&tblEmailMap).Error
// 			if err != nil {
// 				var MobEmailModel clientmaster.TblMobileEmailMapping
// 				MobEmailModel.Email = usermodel.Email
// 				MobEmailModel.MobileNo = usermodel.MobileNo
// 				MobEmailModel.EmailVerified = true
// 				err = Db.Client.Create(&MobEmailModel).Error
// 				if err != nil {
// 					Zerologs.Error().Msg("Register(): Data not added in email-mobile mapping table for mobileNO= " + usermodel.MobileNo + " AND email:=  " + usermodel.Email + err.Error())
// 					return nil, err
// 				}
// 				if resp["Flag1"] == "Already registered" {
// 					token, err := GenerateJWTWithRefresh(usermodel.MobileNo, usermodel.Email, "") //Samir Need to Check
// 					if err != nil {
// 						Zerologs.Error().Msg("Login libjwt.GenerateJWT " + err.Error())
// 						return nil, err
// 					}
// 					// if RedirectUrl == "" || RedirectUrl == "https://www.nuuu.com/trade" || RedirectUrl == "https://www.nuuu.com/trade/" {
// 					if UrlsArr.CheckUrls(RedirectUrl) {
// 						token["Msg"] = "Register Successfully"
// 						token["url"] = Env.GOOGLE_MAIN_PAGE
// 						return token, nil
// 					} else {
// 						token["Msg"] = "Register Successfully"
// 						token["url"] = RedirectUrl
// 						return token, nil
// 					}
// 				} else {
// 					// if RedirectUrl == "" || RedirectUrl == "https://www.nuuu.com/trade" || RedirectUrl == "https://www.nuuu.com/trade/" {
// 					if UrlsArr.CheckUrls(RedirectUrl) {
// 						token["Msg"] = "Register Successfully"
// 						token["url"] = "/sign/glogin"
// 						return token, nil
// 					} else {
// 						token["Msg"] = "Register Successfully"
// 						token["url"] = RedirectUrl
// 						return token, nil
// 					}
// 				}

// 			} else {
// 				token["errMsg"] = "User already registered"
// 				return token, nil
// 			}
// 		} else {
// 			token["errMsg"] = resp["errMsg"]
// 			return token, nil
// 		}
// 	}
// 	return token, nil
// }
