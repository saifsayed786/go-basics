package controller

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"time"

	"github.com/MACMREPO/libdb/clientmaster"
	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/helper"
	"github.com/MACMREPO/libjwt/model"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/contrib/sessions"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"golang.org/x/oauth2"
)

func AuthHandler(c *gin.Context) {
	libhttp.CoreHeader(c)
	// Handle the exchange code to initiate a transport.
	session := sessions.Default(c)
	retrievedState := session.Get("state")
	if retrievedState == nil {
		service.Zerologs.Info().Msg("AuthHandler(): RetriveState is Nil")
		return
	}
	// RetriveState := retrievedState.(string)
	cquery := c.Query("state")
	if retrievedState != cquery {
		service.Zerologs.Info().Msg("AuthHandler(): Invalid session state " + retrievedState.(string))
		c.AbortWithError(http.StatusUnauthorized, fmt.Errorf("Invalid session state: %s", retrievedState))
		return
	}
	tok, err := helper.Conf.Exchange(oauth2.NoContext, c.Query("code"))
	if err != nil {
		service.Zerologs.Error().Msg("AuthHandler(): Error in helper.Conf.Exchange is " + err.Error())
		c.AbortWithError(http.StatusBadRequest, err)
		return
	}
	client := helper.Conf.Client(oauth2.NoContext, tok)
	email, err := client.Get("https://www.googleapis.com/oauth2/v3/userinfo")
	if err != nil {
		service.Zerologs.Error().Msg("AuthHandler(): Error in client.Get is " + err.Error())
		c.AbortWithError(http.StatusBadRequest, err)
		return
	}
	defer email.Body.Close()
	data, _ := ioutil.ReadAll(email.Body)
	var user model.User
	err = json.Unmarshal(data, &user)
	if err != nil {
		service.Zerologs.Error().Msg("AuthHandler(): Error in json.Unmarshal of User is " + err.Error())
		c.AbortWithError(http.StatusBadRequest, err)
		return
	}
	// var clientdbData clientmaster.TblJwtMaster
	var clientdbData clientmaster.JwtAuthMaster
	err = service.Db.Client.Where("Email=?", user.Email).First(&clientdbData).Error
	if err != nil {
		guid := uuid.New()
		clientdbData.Email = user.Email
		clientdbData.Activated = false
		clientdbData.EmailVerified = user.EmailVerified
		clientdbData.FamilyName = user.FamilyName
		clientdbData.Gender = user.Gender
		clientdbData.GivenName = user.GivenName
		clientdbData.Name = user.Name
		clientdbData.Picture = user.Picture
		clientdbData.Profile = user.Profile
		clientdbData.UserGuid = helper.UuidToString(guid)
		clientdbData.LastMPIN_UpdatedTime = time.Now()
		clientdbData.LastPassword_UpdatedTime = time.Now()
		clientdbData.UserActivatedTime = time.Now()
		err = service.Db.Client.Create(&clientdbData).Error
		if err != nil {
			service.Zerologs.Error().Msg("AuthHandler(): Error while executing query= service.Db.Client.Create(&clientdbData) for user emailId= " + user.Email + err.Error())
			return
		}
		RetriveState := retrievedState.(string)
		err = service.RedisLib.Client.Set(RetriveState, helper.UuidToString(guid), time.Duration(60*time.Second)).Err()
		if err != nil {
			service.Zerologs.Error().Msg("AuthHandler():UserGUID not set in redis for retriveStat:=  " + RetriveState + err.Error())
			return
		}
		//REcord Not Found Send Email Page
		c.Writer.Write([]byte(helper.Mobiletemplate))
		return
	} else {
		RetriveState := retrievedState.(string)
		err = service.RedisLib.Client.Set(RetriveState, clientdbData.UserGuid, time.Duration(60*time.Second)).Err()
		if err != nil {
			service.Zerologs.Error().Msg("AuthHandler():UserGUID not set in redis for retriveStat:=  " + RetriveState + err.Error())
			return
		}
		if clientdbData.MobileNo == "" {
			c.Writer.Write([]byte(helper.Mobiletemplate))
		} else {
			if clientdbData.PasswordFailedCount >= service.Env.MAX_PASSWORD_ATTEMPT || clientdbData.MPINFailedCount >= service.Env.MAX_MPIN_ATTEMPT {
				service.Zerologs.Info().Msg("AuthHandler(): MOBILE NO: " + clientdbData.MobileNo + "IS BLOCKED  :=  ")
				c.Writer.Write([]byte(helper.BlockUsertemplate))
				return
			}
			c.Writer.Write([]byte(helper.Redirecttemplate))
		}
		return
	}
}
