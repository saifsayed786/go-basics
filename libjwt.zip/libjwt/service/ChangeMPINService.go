package service

import (
	"github.com/MACMREPO/libdb/clientmaster"
	"github.com/MACMREPO/libjwt/model"
)

func ChangeMPINService(MobileNo string, changempin model.ChangeMpin) (map[string]string, error) {
	token := make(map[string]string)
	var clientdbData clientmaster.JwtAuthMaster
	err := Db.Client.Where("mobile_no=?", MobileNo).First(&clientdbData).Error
	if err != nil {
		Zerologs.Error().Msg("ChangeMpin(): User data not found for mobileno=" + MobileNo + " and error is " + err.Error())
		return nil, err
	}
	if changempin.OldMpin != clientdbData.MPIN {
		Zerologs.Info().Msg("ChangeMpin(): User " + MobileNo + " entered incorrect old MPIN.")
		token["errMsg"] = "Old mpin is not correct"
		return token, nil
	}
	if changempin.NewMpin == clientdbData.MPIN {
		Zerologs.Info().Msg("ChangeMpin(): User " + MobileNo + "enterd same value for old and new MPIN.")
		token["errMsg"] = "New MPIN should not be same as old MPIN."
		return token, nil
	}
	err = Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", clientdbData.MobileNo).Updates(clientmaster.JwtAuthMaster{MPIN: changempin.NewMpin}).Error
	if err != nil {
		// fmt.Println(err)
		Zerologs.Error().Msg("ChangeMpin(): MPIN update query failed for mobileno=" + clientdbData.MobileNo + " and error is " + err.Error())
		return nil, err
	}
	Zerologs.Info().Msg("ChangeMpin(): User " + MobileNo + " successfully changed MPIN .")
	token["Msg"] = "MPIN changed successfully...!"
	return token, nil
}
