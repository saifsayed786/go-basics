package model

import (
	"time"

	"gorm.io/gorm"
)

type Loginmodel struct {
	Mobileno string `json:"Mobileno" binding:"required"`
	Email    string `json:"Email"`
}

type LoginModel struct {
	gorm.Model
	Id              string    `json:"id"`
	MobileNo        string    `json:"mobileNo"`
	OTP             int       `json:"otp"`
	IsPaperTrade    bool      `json:"ispapertrade"`
	UserType        string    `json:"usertype"`
	SessionKey      string    `json:"sessionkey"`
	LastUpdatedTime time.Time `json:"time"`
}

type Loginresponse struct {
	Mobile_no string `json:"mobile_no"`
	Otp       string `json:"otp"`
}

type CommonOtpmodel struct {
	gorm.Model
	Actiontype int `json:"actiontype"`
	// Userid       string `json:"userid"`
	OldNumber string `json:"oldnumber"`
	Userdata  string `json:"userdata"`
	OTP       string
	Status    int `json:"status"`
}

type TokenDetails struct {
	AccessToken  string
	RefreshToken string
	AccessUuid   string
	RefreshUuid  string
	AtExpires    int64
	RtExpires    int64
}
type OtpVerifyModel struct {
	MobileNo string `json:"mobileno"`
	Otp      string `json:"otp"`
}

type VerifyOTPResponseModel struct {
	IsErr bool `json:"isErr"`
	Msg string `json:"msg"`
	OtpCnt int `json:"otpCnt,omitempty"`
	Flag string `json:"flag,omitempty"`
}
