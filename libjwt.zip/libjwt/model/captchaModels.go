package model

type VerifyCaptchaReqModel_Web struct {
	Digits   string `json:"digits"`
	MobileNo string `json:"mobileno"`
	Type     int    `json:"type"`
}
type VerifyCaptchaReqModel_Mob struct {
	Digits   string `json:"digits"`
	MobileNo string `json:"mobileno"`
	DeviceId string `json:"deviceid"`
	Type     int    `json:"type"`
}

type ReloadCaptchaReqModel_Mob struct {
	DeviceId string `json:"deviceid"`
}

type ReloadCaptchaReqModel_Web struct {
	MobileNo string `json:"MobileNo"`
}
