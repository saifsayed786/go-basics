package service

import (
	"fmt"
	"sync"

	"github.com/golobby/container/v3"
)

type Q struct {
	bucket *LinkedList
	m      *sync.Mutex
	cond   *sync.Cond
	name   string
}

func (q *Q) Init(name string) error {
	q.name = name
	q.bucket = &LinkedList{}
	q.m = &sync.Mutex{}
	q.cond = sync.NewCond(q.m)
	go q.Dequeue()
	container.NamedSingleton(name, func() *Q {
		return q
	})
	return nil
}

func (q *Q) Enqueue(val interface{}, fp func(interface{})) {

	q.cond.L.Lock()
	defer q.cond.L.Unlock()
	q.bucket.Insert(val, fp)
	q.cond.Broadcast()
}

func (q *Q) Dequeue() {
	for {
		q.cond.L.Lock()
		q.cond.Wait()
		newBucket := q.bucket
		q.bucket = &LinkedList{}
		q.cond.L.Unlock()
		if newBucket.head == nil {
			continue
		}
		list := newBucket.head
		for list != nil {
			list.fp(list.value)
			list = list.next
		}
	}
}

func (q *Q) EnqueueBulk(val []interface{}, fp func(interface{})) {
	if len(val) > 0 {
		fmt.Println("Input Val len: ", len(val))
		q.cond.L.Lock()
		defer q.cond.L.Unlock()
		for i := range val {
			if len(val)%100 == 0 {
				fmt.Println("i: ", i)
			}
			q.bucket.Insert(val[i], fp)
		}
		q.cond.Broadcast()
		fmt.Println("After singnal BCast")
	}
}
