package service

// import (
// 	"bytes"
// 	"encoding/json"
// 	"io/ioutil"
// 	"net/http"
// 	"os"
// 	"time"

// 	"github.com/MACMREPO/libdb/clientmaster"
// 	"github.com/MACMREPO/libjwt/helper"
// 	"github.com/MACMREPO/libjwt/model"
// 	"github.com/google/uuid"
// )

// func KycDataHandlerService(UserDataModel clientmaster.JwtAuthMaster) (map[string]string, error) {
// 	var dataModel model.UpdatedataModel
// 	dataModel.Name = UserDataModel.Name
// 	dataModel.Mobileno = UserDataModel.MobileNo
// 	var guid uuid.UUID
// 	var guidData clientmaster.MobileGuidMaster
// 	err := Db.Client.Where("mobile_no=?", UserDataModel.MobileNo).First(&guidData).Error
// 	if err != nil {
// 		guid = uuid.New()
// 		guidData.UserGuid = guid
// 		guidData.MobileNo = UserDataModel.MobileNo
// 		err = Db.Client.Create(&guidData).Error
// 		if err != nil {
// 			Zerologs.Error().Msg("KycDataHandler(): Error in create query for guidData for mobileno=" + UserDataModel.MobileNo + " is " + err.Error())
// 			// fmt.Println(err)
// 			return nil, err
// 		}
// 		dataModel.Guid = guid
// 	} else {
// 		guid = guidData.UserGuid
// 		dataModel.Guid = guid
// 	}

// 	token, err := GenerateJWTWithRefresh(UserDataModel.MobileNo, UserDataModel.Email, "") //Samir Pending
// 	if err != nil {
// 		Zerologs.Error().Msg("KycDataHandler(): Error in GenerateJWTWithRefresh for mobileno=" + UserDataModel.MobileNo + " and email=" + UserDataModel.Email + " is " + err.Error())
// 		return nil, err
// 	}
// 	var Email clientmaster.TblMobileEmailMapping
// 	err = Db.Client.Where("email=?", UserDataModel.Email).First(&Email).Error
// 	if err != nil {
// 		var TblMobileEmailMapping clientmaster.TblMobileEmailMapping
// 		err = Db.Client.Where("mobile_no=?", UserDataModel.MobileNo).First(&TblMobileEmailMapping).Error
// 		if err != nil {
// 			Email.MobileNo = UserDataModel.MobileNo
// 			Email.Email = UserDataModel.Email
// 			Email.EmailVerified = true
// 			err = Db.Client.Create(&Email).Error
// 			if err != nil {
// 				Zerologs.Error().Msg("KycDataHandler(): Error in create query for TblMobileEmailMapping for mobileno=" + UserDataModel.MobileNo + " and email=" + UserDataModel.Email + " is " + err.Error())
// 				// fmt.Println(err)
// 				return nil, err
// 			}
// 			UserDataModel.UserGuid = helper.UuidToString(guid)
// 			UserDataModel.LastPassword_UpdatedTime = time.Now()
// 			UserDataModel.LastMPIN_UpdatedTime = time.Now()
// 			UserDataModel.UserActivatedTime = time.Now()
// 			password := RandPass()
// 			MD5Pass := GetMD5Hash(password)
// 			UserDataModel.Password = MD5Pass
// 			UserDataModel.Refreshtoken = token["refresh_token"]
// 			err := Db.Client.Create(&UserDataModel).Error
// 			if err != nil {
// 				Zerologs.Error().Msg("KycDataHandler(): Error in create query for JwtAuthMaster for mobileno=" + UserDataModel.MobileNo + " is " + err.Error())
// 				return nil, err
// 			}

// 			UserDataModel.Password = password
// 			err = PasswordEmail(UserDataModel)
// 			if err != nil {
// 				Zerologs.Error().Msg("KycDataHandler(): Random password not send to  emailId " + UserDataModel.Email + err.Error())
// 				return nil, err
// 			}
// 			err = AddWatchList(UserDataModel.MobileNo)
// 			if err != nil {
// 				Zerologs.Error().Msg("KycDataHandler(): Watchlist not added for mobileNo: " + UserDataModel.MobileNo + err.Error())
// 				return nil, err
// 			}
// 			var jwtauthmaster clientmaster.JwtAuthMaster
// 			err = Db.Client.Where("mobile_no=?", UserDataModel.MobileNo).First(&jwtauthmaster).Error
// 			if err != nil {
// 				Zerologs.Error().Msg("KycDataHandler(): JwtAuthMaster data not found for mobileno=" + UserDataModel.MobileNo + " and error is " + err.Error())
// 				return nil, err
// 			}

// 			var passwordhistory clientmaster.PasswordHistory
// 			passwordhistory.MobileNo = jwtauthmaster.MobileNo
// 			passwordhistory.LastPassword = jwtauthmaster.Password
// 			passwordhistory.LastPassword_UpdatedTime = time.Now()
// 			err = Db.Client.Create(&passwordhistory).Error
// 			if err != nil {
// 				Zerologs.Error().Msg("KycDataHandler(): Error while add data in password history for mobileno=" + UserDataModel.MobileNo + " and error is " + err.Error())
// 				// fmt.Println(err)
// 				return nil, err
// 			}

// 			var socialData model.SocialModel
// 			socialData.GUID = guid
// 			socialData.Mobileno = UserDataModel.MobileNo
// 			socialData.Email = UserDataModel.Email
// 			socialData.ID = jwtauthmaster.ID
// 			if jwtauthmaster.Name == "" {
// 				socialData.Name = UserDataModel.MobileNo
// 			} else {
// 				socialData.Name = jwtauthmaster.Name
// 			}
// 			socialData.Username = jwtauthmaster.Name
// 			socialData.Password = UserDataModel.Password
// 			socialData.Avatar = ""
// 			// err = AddSociaInfo(socialData)
// 			// if err != nil {
// 			// 	Zerologs.Error().Msg("KycDataHandler():Social data not added for mobileNo: " + UserDataModel.MobileNo + err.Error())
// 			// 	return
// 			// }
// 		} else {
// 			var NewEmail clientmaster.TblMobileEmailMapping
// 			NewEmail.MobileNo = UserDataModel.MobileNo
// 			NewEmail.Email = UserDataModel.Email
// 			NewEmail.EmailVerified = true
// 			err = Db.Client.Create(&NewEmail).Error
// 			if err != nil {
// 				Zerologs.Error().Msg("KycDataHandler(): Error while add data in TblMobileEmailMapping for mobileno=" + UserDataModel.MobileNo + " and email=" + UserDataModel.Email + " and error is " + err.Error())
// 				// fmt.Println(err)
// 				return nil, err
// 			}
// 			updateData := make(map[string]interface{})
// 			updateData["user_guid"] = helper.UuidToString(guid)
// 			updateData["mobile_verified"] = UserDataModel.MobileVerified
// 			updateData["client_id"] = UserDataModel.ClientID
// 			updateData["activated"] = UserDataModel.Activated
// 			updateData["name"] = UserDataModel.Name
// 			updateData["email"] = UserDataModel.Email
// 			updateData["email_verified"] = UserDataModel.EmailVerified
// 			updateData["gender"] = UserDataModel.Gender
// 			updateData["kyc_done"] = UserDataModel.KYCDone
// 			updateData["pan"] = UserDataModel.Pan
// 			updateData["default_password"] = UserDataModel.Default_password
// 			updateData["refreshtoken"] = token["refresh_token"]
// 			err := Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", UserDataModel.MobileNo).Updates(updateData).Error
// 			// err := Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", UserDataModel.MobileNo).Updates(clientmaster.JwtAuthMaster{UserGuid: helper.UuidToString(guid), MobileVerified: UserDataModel.MobileVerified, ClientID: UserDataModel.ClientID, Activated: UserDataModel.Activated, Name: UserDataModel.Name, Email: UserDataModel.Email, EmailVerified: UserDataModel.EmailVerified, Gender: UserDataModel.Gender, KYCDone: UserDataModel.KYCDone, Pan: UserDataModel.Pan, Default_password: UserDataModel.Default_password, Refreshtoken: token["refresh_token"]}).Error
// 			if err != nil {
// 				Zerologs.Error().Msg("KycDataHandler(): JwtAuthMaster update query failed for mobileno=" + UserDataModel.MobileNo + " and error is " + err.Error())
// 				return nil, err
// 			}

// 			sStage := os.Getenv("STAGE")
// 			facetradepath := ""
// 			if sStage == "" {
// 				facetradepath = "https://www.nuuu.com"
// 			} else {
// 				facetradepath = "http://facetrade-" + sStage + "-service:8085"
// 			}
// 			url := facetradepath + "/facetrade/jwtauth/updatedata"
// 			jsonStr, err := json.Marshal(&dataModel)
// 			if err != nil {
// 				Zerologs.Error().Err(err).Msg("KycDataHandler(): Error While marshalling model")
// 				return nil, err
// 			}
// 			resp, err := http.Post(url, "application/json", bytes.NewBuffer(jsonStr))
// 			if err != nil {
// 				Zerologs.Error().Err(err).Msg("KycDataHandler(): Error While send request to url=" + url + " and error is " + err.Error())
// 				return nil, err
// 			}
// 			defer resp.Body.Close()
// 			//Read the response body
// 			_, err = ioutil.ReadAll(resp.Body)
// 			if err != nil {
// 				Zerologs.Error().Err(err).Msg("KycDataHandler(): Error While read response body of url=" + url + " and error is " + err.Error())
// 				return nil, err
// 			}
// 		}
// 	} else {
// 		updateData := make(map[string]interface{})
// 		updateData["mobile_verified"] = UserDataModel.MobileVerified
// 		updateData["email"] = UserDataModel.Email
// 		updateData["user_guid"] = helper.UuidToString(guid)
// 		updateData["client_id"] = UserDataModel.ClientID
// 		updateData["activated"] = UserDataModel.Activated
// 		updateData["name"] = UserDataModel.Name
// 		updateData["email_verified"] = UserDataModel.EmailVerified
// 		updateData["gender"] = UserDataModel.Gender
// 		updateData["kyc_done"] = UserDataModel.KYCDone
// 		updateData["pan"] = UserDataModel.Pan
// 		updateData["default_password"] = UserDataModel.Default_password
// 		updateData["refreshtoken"] = token["refresh_token"]
// 		err := Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", Email.MobileNo).Updates(updateData).Error
// 		// err := Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", Email.MobileNo).Updates(clientmaster.JwtAuthMaster{MobileVerified: UserDataModel.MobileVerified, Email: UserDataModel.Email, UserGuid: helper.UuidToString(guid), ClientID: UserDataModel.ClientID, Activated: UserDataModel.Activated, Name: UserDataModel.Name, EmailVerified: UserDataModel.EmailVerified, Gender: UserDataModel.Gender, KYCDone: UserDataModel.KYCDone, Pan: UserDataModel.Pan, Default_password: UserDataModel.Default_password, Refreshtoken: token["refresh_token"]}).Error
// 		if err != nil {
// 			Zerologs.Error().Msg("KycDataHandler(): JwtAuthMaster update query failed for mobileno=" + UserDataModel.MobileNo + " and error is " + err.Error())
// 			return nil, err
// 		}

// 		sStage := os.Getenv("STAGE")
// 		facetradepath := ""
// 		if sStage == "" {
// 			facetradepath = "https://www.nuuu.com"
// 		} else {
// 			facetradepath = "http://facetrade-" + sStage + "-service:8085"
// 		}
// 		url := facetradepath + "/facetrade/jwtauth/updatedata"
// 		jsonStr, err := json.Marshal(&dataModel)
// 		if err != nil {
// 			Zerologs.Error().Err(err).Msg("KycDataHandler(): Error While marshalling model")
// 			return nil, err
// 		}
// 		resp, err := http.Post(url, "application/json", bytes.NewBuffer(jsonStr))
// 		if err != nil {
// 			Zerologs.Error().Err(err).Msg("KycDataHandler(): Error While send request to url=" + url + " and error is " + err.Error())
// 			return nil, err
// 		}
// 		defer resp.Body.Close()
// 		//Read the response body
// 		_, err = ioutil.ReadAll(resp.Body)
// 		if err != nil {
// 			Zerologs.Error().Err(err).Msg("KycDataHandler(): Error While read response body of url=" + url + " and error is " + err.Error())
// 			return nil, err
// 		}
// 	}
// 	Zerologs.Info().Msg("KYC DONE FOR MOBILE NO:=  " + UserDataModel.MobileNo + " AT TIME " + time.Now().Format("2006-01-02 15:04:05"))
// 	// token["url"] = "/sign/glogin"
// 	token["url"] = Env.GOOGLE_MAIN_PAGE
// 	return token, nil
// }
