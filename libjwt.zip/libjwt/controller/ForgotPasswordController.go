package controller

import (
	"net/http"

	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/model"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/gin"
)

func Forgot_Password(c *gin.Context) {
	libhttp.CoreHeader(c)
	var forgetpassword model.ForgetPassword
	if err := c.BindJSON(&forgetpassword); err != nil {
		// service.Zerologs.Error().Msg("Forgot_Password(): Error in c.BindJSON is " + err.Error())
		c.JSON(http.StatusBadRequest, err)
		return
	}
	response := service.ForgotPasswordService(forgetpassword)
	c.JSON(response.StatusCode, response)
}
