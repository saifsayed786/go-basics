package service

import (
	"strconv"
	"time"

	"github.com/MACMREPO/libdb/clientmaster"
	"github.com/MACMREPO/libjwt/model"
)

func VerifyOTPWebService(RetriveState string, VerifyModel model.OtpVerifyModel) (map[string]string, error) {
	token := make(map[string]string)
	rotp, err := RedisLib.Client.Get(VerifyModel.MobileNo).Result()
	var userdata clientmaster.TblMobileOtp
	err = Db.Client.Where("mobile_no=?", VerifyModel.MobileNo).First(&userdata).Error
	if err != nil {
		Zerologs.Error().Msg("Verify_OTP(): User " + VerifyModel.MobileNo + " Not found in  clientmaster.TblMobileOtp")
		return nil, err
	}
	if VerifyModel.Otp != rotp {
		if userdata.OtpAttempt >= Env.MAX_OTP_ATTEMPT {
			Zerologs.Error().Msg(" user " + VerifyModel.MobileNo + " is blocked for 15 minutes ")
			token["errMsg"] = " User is blocked, please try again after 15 minutes "
			return token, nil
		}
		Zerologs.Error().Msg("Verify_OTP(): User " + VerifyModel.MobileNo + " enter invalid OTP ")
		attempt := (userdata.OtpAttempt) + 1
		err := Db.Client.Model(clientmaster.TblMobileOtp{}).Where("mobile_no=?", VerifyModel.MobileNo).Updates(clientmaster.TblMobileOtp{OtpAttempt: attempt, OtpBlockTime: time.Now()}).Error
		if err != nil {
			Zerologs.Error().Msg("Verify_OTP(): Data update failed in TblMobileOtp for MobileNo=" + VerifyModel.MobileNo + " and Error=" + err.Error())
			return nil, err
		}
		remainingcount := Env.MAX_OTP_ATTEMPT - attempt
		if remainingcount == 0 {
			token["errMsg"] = "User is blocked for 15 minutes"
		} else {
			if attempt == 2 {
				imgBase64Str := CreateCaptcha(RetriveState)
				token["img64"] = imgBase64Str
				token["errMsg"] = "Invalid OTP. " + strconv.Itoa(remainingcount) + " attempts remaining "
				token["isOtp"] = "1"
				return token, nil
			} else {
				token["errMsg"] = "Invalid OTP. " + strconv.Itoa(remainingcount) + " attempts remaining "
				// token["otpCnt"] = strconv.Itoa(attempt)
				return token, nil
			}

		}

	}
	if userdata.OtpAttempt >= 3 {
		Zerologs.Error().Msg(" user " + VerifyModel.MobileNo + " is blocked for 15 minutes ")
		token["errMsg"] = "User is blocked for 15 minutes"
		return token, nil
	} else {
		err := Db.Client.Model(clientmaster.TblMobileOtp{}).Updates(clientmaster.TblMobileOtp{OtpAttempt: 0}).Error
		if err != nil {
			Zerologs.Error().Msg("Verify_OTP(): OtpAttempt update failed in TblMobileOtp for MobileNo=" + VerifyModel.MobileNo + " and Error=" + err.Error())
			return nil, err
		}
		var UserData clientmaster.TblMobileEmailMapping
		err = Db.Client.Where("mobile_no=?", VerifyModel.MobileNo).First(&UserData).Error
		if err != nil {
			token["Msg"] = "Success"
			token["Flag2"] = "Newly registered"
			return token, nil
		}
		token["Msg"] = "Success"
		token["Flag1"] = "Already registered"
		return token, nil
	}
}
