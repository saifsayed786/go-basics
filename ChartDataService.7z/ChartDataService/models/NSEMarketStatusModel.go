package models

type NSEMarketStatusModel struct {
	ExchangeId   int16 `json:"exId"`
	MarketType   int16 `json:"mkttyp"`
	Time         int   `json:"time"`
	MarketStatus int16 `json:"mktstatus"`
}
