package model

type HyperMpinResponse struct {
	Status string `json:"status"`
	Code   int    `json:"code"`
	Data   struct {
		Status      string `json:"status"`
		SessionKey  string `json:"sessionKey"`
		Server      string `json:"server"`
		Preferences struct {
			Theme          string `json:"theme"`
			Lastupdate     int64  `json:"lastupdate"`
			Version        string `json:"version"`
			PreTradeValues struct {
				StockValue      int     `json:"stockValue"`
				IndexValue      int     `json:"indexValue"`
				OptionValueLow  int     `json:"optionValueLow"`
				OptionValueHigh int     `json:"optionValueHigh"`
				CurrValueLow    float64 `json:"currValueLow"`
				CurrValueMedium float64 `json:"currValueMedium"`
				CurrValueHigh   int     `json:"currValueHigh"`
				EurValueLow     float64 `json:"eurValueLow"`
				EurValueMedium  float64 `json:"eurValueMedium"`
				EurValueHigh    int     `json:"eurValueHigh"`
				TotalBuyAmt     int     `json:"totalBuyAmt"`
			} `json:"preTradeValues"`
			OrderBookColumns []struct {
				Key        string `json:"key"`
				Value      string `json:"value"`
				IsChecked  bool   `json:"isChecked"`
				IsDisabled bool   `json:"isDisabled,omitempty"`
			} `json:"orderBookColumns"`
			TradeBookColumns []struct {
				Key        string `json:"key"`
				Value      string `json:"value"`
				IsChecked  bool   `json:"isChecked"`
				IsDisabled bool   `json:"isDisabled,omitempty"`
			} `json:"tradeBookColumns"`
			PositionBookColumns []struct {
				Key        string `json:"key"`
				Value      string `json:"value"`
				IsChecked  bool   `json:"isChecked"`
				IsDisabled bool   `json:"isDisabled,omitempty"`
			} `json:"positionBookColumns"`
			HoldingBookColumns []struct {
				Key        string `json:"key"`
				Value      string `json:"value"`
				IsChecked  bool   `json:"isChecked"`
				IsDisabled bool   `json:"isDisabled,omitempty"`
			} `json:"holdingBookColumns"`
			WSave []struct {
				Root struct {
					Type    string `json:"type"`
					Content []struct {
						Type    string `json:"type"`
						Content []struct {
							Type    string `json:"type"`
							Content []struct {
								Type           string        `json:"type"`
								Content        []interface{} `json:"content"`
								Width          float64       `json:"width"`
								MinWidth       int           `json:"minWidth"`
								Height         int           `json:"height"`
								MinHeight      int           `json:"minHeight"`
								ID             string        `json:"id"`
								Maximised      bool          `json:"maximised"`
								IsClosable     bool          `json:"isClosable"`
								ReorderEnabled bool          `json:"reorderEnabled"`
								Title          string        `json:"title"`
								ComponentType  string        `json:"componentType"`
								ComponentState struct {
								} `json:"componentState"`
							} `json:"content"`
							Width           float64 `json:"width"`
							MinWidth        int     `json:"minWidth"`
							Height          int     `json:"height"`
							MinHeight       int     `json:"minHeight"`
							ID              string  `json:"id"`
							IsClosable      bool    `json:"isClosable"`
							Maximised       bool    `json:"maximised"`
							ActiveItemIndex int     `json:"activeItemIndex"`
						} `json:"content"`
						Width      float64 `json:"width"`
						MinWidth   int     `json:"minWidth"`
						Height     int     `json:"height"`
						MinHeight  int     `json:"minHeight"`
						ID         string  `json:"id"`
						IsClosable bool    `json:"isClosable"`
					} `json:"content"`
					Width      float64 `json:"width"`
					MinWidth   int     `json:"minWidth"`
					Height     int     `json:"height"`
					MinHeight  int     `json:"minHeight"`
					ID         string  `json:"id"`
					IsClosable bool    `json:"isClosable"`
				} `json:"root,omitempty"`
				OpenPopouts []interface{} `json:"openPopouts,omitempty"`
				Settings    struct {
					ConstrainDragToContainer bool   `json:"constrainDragToContainer"`
					ReorderEnabled           bool   `json:"reorderEnabled"`
					PopoutWholeStack         bool   `json:"popoutWholeStack"`
					BlockedPopoutsThrowError bool   `json:"blockedPopoutsThrowError"`
					ClosePopoutsOnUnload     bool   `json:"closePopoutsOnUnload"`
					ResponsiveMode           string `json:"responsiveMode"`
					TabOverlapAllowance      int    `json:"tabOverlapAllowance"`
					ReorderOnTabMenuClick    bool   `json:"reorderOnTabMenuClick"`
					TabControlOffset         int    `json:"tabControlOffset"`
					PopInOnClose             bool   `json:"popInOnClose"`
				} `json:"settings,omitempty"`
				Dimensions struct {
					BorderWidth     int `json:"borderWidth"`
					BorderGrabWidth int `json:"borderGrabWidth"`
					MinItemHeight   int `json:"minItemHeight"`
					MinItemWidth    int `json:"minItemWidth"`
					HeaderHeight    int `json:"headerHeight"`
					DragProxyWidth  int `json:"dragProxyWidth"`
					DragProxyHeight int `json:"dragProxyHeight"`
				} `json:"dimensions,omitempty"`
				Header struct {
					Show        string `json:"show"`
					Popout      bool   `json:"popout"`
					Dock        string `json:"dock"`
					Close       string `json:"close"`
					Maximise    string `json:"maximise"`
					Minimise    string `json:"minimise"`
					TabDropdown string `json:"tabDropdown"`
				} `json:"header,omitempty"`
				Resolved bool `json:"resolved,omitempty"`
			} `json:"w_save"`
			WSel int `json:"w_sel"`
			WMap struct {
				Num0 []string      `json:"0"`
				Num1 []interface{} `json:"1"`
				Num2 []interface{} `json:"2"`
				Num3 []interface{} `json:"3"`
				Num4 []interface{} `json:"4"`
				Num5 []interface{} `json:"5"`
			} `json:"w_map"`
			WIplist struct {
				Num1 struct {
				} `json:"1"`
				Num2 struct {
				} `json:"2"`
				Num3 struct {
				} `json:"3"`
				Num4 struct {
				} `json:"4"`
				Num5 struct {
				} `json:"5"`
			} `json:"w_iplist"`
			WWarr  []int         `json:"w_warr"`
			WSarr  []interface{} `json:"w_sarr"`
			WSkmap struct {
				Num6 struct {
				} `json:"6"`
				Num7 struct {
				} `json:"7"`
				Num8 struct {
				} `json:"8"`
				Num9 struct {
				} `json:"9"`
				Num10 struct {
				} `json:"10"`
			} `json:"w_skmap"`
			WSlarr []interface{} `json:"w_slarr"`
			LwMap  struct {
				Nfo string `json:"NFO"`
			} `json:"lwMap"`
			Watchlistname []string `json:"watchlistname"`
			DefaultMW     string   `json:"defaultMW"`
			Stocks        []string `json:"stocks"`
			Currentpage   string   `json:"currentpage"`
			Pagetitle     string   `json:"pagetitle"`
		} `json:"preferences"`
	} `json:"data"`
}
