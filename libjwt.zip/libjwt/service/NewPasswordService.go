package service

import (
	"net/http"
	"time"

	"github.com/MACMREPO/libdb/clientmaster"
	"github.com/MACMREPO/libjwt/helper"
	"github.com/MACMREPO/libjwt/model"
)

func NewPasswordWeb(RetrievedState string, newpassword model.NewPassword) model.NewPasswordResponse {
	var responseModel model.NewPasswordResponse
	// val, err := RedisLib.Client.Get(RetrievedState).Result()
	val, err := getDataFromRedis(RetrievedState)
	if err != nil {
		Zerologs.Error().Msg("NewPassword(): Redis Get failed RetrievedState:" + err.Error())
		responseModel.IsErr = true
		responseModel.Msg = err.Error()
		responseModel.StatusCode = http.StatusInternalServerError
		return responseModel
	}
	// var clientdbData clientmaster.JwtAuthMaster
	// err = Db.Client.Where("user_guid=?", val).First(&clientdbData).Error
	clientdbData, err := getJwtAuthMasterDB(helper.CLIENT_USERGUID, val)
	if err != nil {
		Zerologs.Error().Msg("NewPassword():data not found in jwtauth master for guid= " + val + err.Error())
		responseModel.IsErr = true
		responseModel.Msg = err.Error()
		responseModel.StatusCode = http.StatusInternalServerError
		return responseModel
	}

	// var passwordhistory []clientmaster.PasswordHistory
	// Db.Client.Where("mobile_no=?", clientdbData.MobileNo).Last(&passwordhistory).Limit(3)
	passwordhistory, _ := findPasswordHistoryLimit(helper.CLIENT_MOBILE_PARAM, clientdbData.MobileNo)
	if len(passwordhistory) == 0 {
		Zerologs.Info().Msg("NewPassword():Data not found in password history table where mobileNo: " + clientdbData.MobileNo)
		responseModel.IsErr = true
		responseModel.Msg = err.Error()
		responseModel.StatusCode = http.StatusInternalServerError
		return responseModel
	}

	for i := range passwordhistory {
		if newpassword.NewPassword == passwordhistory[i].LastPassword {
			responseModel.IsErr = true
			responseModel.Msg = "Current password should not be same as last 3 passwords"
			responseModel.StatusCode = http.StatusInternalServerError
			return responseModel
		}
	}

	// err = Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", clientdbData.MobileNo).Updates(clientmaster.JwtAuthMaster{Password: newpassword.NewPassword, IsPasswordReset: true, PasswordFailedCount: 0}).Error
	err = updateJWTAuthMasterModel(helper.CLIENT_MOBILE_PARAM, clientdbData.MobileNo, clientmaster.JwtAuthMaster{Password: newpassword.NewPassword, IsPasswordReset: true, PasswordFailedCount: 0})
	if err != nil {
		Zerologs.Error().Msg("NewPassword():updates failed Password and PasswordFailedCount where mobileNo: " + clientdbData.MobileNo + err.Error())
		responseModel.IsErr = true
		responseModel.Msg = err.Error()
		responseModel.StatusCode = http.StatusInternalServerError
		return responseModel
	}
	var password clientmaster.PasswordHistory
	password.MobileNo = clientdbData.MobileNo
	password.LastPassword = newpassword.NewPassword
	password.LastPassword_UpdatedTime = time.Now()
	err = Db.Client.Create(&password).Error
	if err != nil {
		Zerologs.Error().Msg("NewPassword(): Error while inserting data in password history for mobileNo= " + clientdbData.MobileNo + err.Error())
		responseModel.IsErr = true
		responseModel.Msg = err.Error()
		responseModel.StatusCode = http.StatusInternalServerError
		return responseModel
	}
	// if clientdbData.KYCDone {
	// 	if !clientdbData.IsMPIN_Reset {
	// 		Zerologs.Info().Msg(" NewPassword(): Password reset  successfully for user mobileno= " + clientdbData.MobileNo)
	// 		token["Msg"] = "Password reset successfully"
	// 		token["url"] = "/sign/glogin"
	// 		return token, nil
	// 	} else {
	// 		Zerologs.Info().Msg(" NewPassword(): Password reset  successfully for user mobileno= " + clientdbData.MobileNo)
	// 		token["Msg"] = "Password reset successfully"
	// 		token["isMpinSet"] = "true"
	// 		token["url"] = "/sign/glogin"
	// 		return token, nil
	// 	}
	// } else {
	Zerologs.Info().Msg(" NewPassword(): Password reset  successfully for user mobileno= " + clientdbData.MobileNo)
	responseModel.IsErr = false
	responseModel.Msg = "Password reset successfully"
	responseModel.StatusCode = http.StatusOK
	responseModel.Url = "/sign/glogin"
	return responseModel
	// }
}
