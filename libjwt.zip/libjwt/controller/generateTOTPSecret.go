package controller

import (
	"bytes"
	"encoding/base64"
	"fmt"
	"image/png"
	"io/ioutil"
	"strings"

	"github.com/MACMREPO/libjwt/helper"
	"github.com/gin-gonic/gin"
	"github.com/pquerna/otp"
	"github.com/pquerna/otp/totp"
)

func GenerateTOTPSecret(c *gin.Context) {
	// var TotpReq model.TotpRequest
	// err := c.BindJSON(&TotpReq)
	// if err != nil {
	// 	fmt.Println(err)
	// }
	key, err := totp.Generate(totp.GenerateOpts{
		Issuer:      "nuuu.com",
		AccountName: "samirdparab@gmail.com",
		// AccountName: TotpReq.Email,
	})
	if err != nil {
		panic(err)
	}
	var buf bytes.Buffer
	img, err := key.Image(200, 200)
	if err != nil {
		panic(err)
	}
	png.Encode(&buf, img)
	imgBase64Str := base64.StdEncoding.EncodeToString(buf.Bytes())
	totptemplate := strings.Replace(helper.TOTPTemplate, "<PNGDATA>", imgBase64Str, 1)
	totptemplate = strings.Replace(totptemplate, "<Secret>", key.Secret(), 1)
	c.Writer.Write([]byte(totptemplate))
	//display(key, buf.Bytes())
	//c.JSON(http.StatusOK, "")
}

func display(key *otp.Key, data []byte) {
	fmt.Printf("Issuer:       %s\n", key.Issuer())
	fmt.Printf("Account Name: %s\n", key.AccountName())
	fmt.Printf("Secret:       %s\n", key.Secret())
	fmt.Println("Writing PNG to qr-code.png....")
	ioutil.WriteFile("qr-code.png", data, 0644)
	fmt.Println("")
	fmt.Println("Please add your TOTP to your OTP Application now!")
	fmt.Println("")
}
