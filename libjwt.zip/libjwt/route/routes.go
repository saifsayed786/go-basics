package route

import (
	"errors"
	"fmt"

	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/controller"
	"github.com/MACMREPO/libjwt/helper"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/contrib/sessions"
	"github.com/gin-gonic/gin"
	"golang.org/x/oauth2"
	"golang.org/x/oauth2/google"
)

func InitGoogleauth(router *gin.RouterGroup) error {
	if service.Env == nil {
		fmt.Println("Env is Null in LibJWT")
		return errors.New("Env is Null in LibJWT")
	}
	if service.Env.GOOGLE_CLIENTID == "" {
		fmt.Println("service.Env.GOOGLE_CLIENTID is Null in LibJWT")
		return errors.New("service.Env.GOOGLE_CLIENTID is Null in LibJWT")
	}
	if service.Env.GOOGLE_CLIENTSECRET == "" {
		fmt.Println("service.Env.GOOGLE_CLIENTSECRET is Null in LibJWT")
		return errors.New("service.Env.GOOGLE_CLIENTSECRET is Null in LibJWT")
	}
	if service.Env.GOOGLE_REDIRECT_URL == "" {
		fmt.Println("service.Env.GOOGLE_REDIRECT_URL is Null in LibJWT")
		return errors.New("service.Env.GOOGLE_REDIRECT_URL is Null in LibJWT")
	}
	fmt.Println("CLientID = " + service.Env.GOOGLE_CLIENTID)
	fmt.Println("ClientSecret = " + service.Env.GOOGLE_CLIENTSECRET)
	fmt.Println("RedirectURL = " + service.Env.GOOGLE_REDIRECT_URL)
	helper.Conf = &oauth2.Config{
		ClientID:     service.Env.GOOGLE_CLIENTID,
		ClientSecret: service.Env.GOOGLE_CLIENTSECRET,
		RedirectURL:  service.Env.GOOGLE_REDIRECT_URL,
		Scopes: []string{
			"https://www.googleapis.com/auth/userinfo.profile",
			"https://www.googleapis.com/auth/userinfo.email",
			// "https://www.googleapis.com/auth/user.phonenumbers",
		},
		Endpoint: google.Endpoint,
	}
	// conf = &oauth2.Config{
	// 	ClientID:     "9165696624-81gc4gnko4t509t12upsacdk8882u5an.apps.googleusercontent.com",
	// 	ClientSecret: "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",
	// 	RedirectURL:  "https://www.nuuu.com/sign/auth",
	// 	Scopes: []string{
	// 		"https://www.googleapis.com/auth/userinfo.profile",
	// 		"https://www.googleapis.com/auth/userinfo.email",
	// 	},
	// 	Endpoint: google.Endpoint,
	// }

	if helper.Conf == nil {
		fmt.Println("Conf is Null in LibJWT")
		return errors.New("conf is Null in LibJWT")
	}

	router.Use(sessions.Sessions("goquestsession", service.Store))
	//mstock 2.0
	//web login
	router.OPTIONS("/login", libhttp.CORSMiddleware())
	router.POST("/login", controller.NormalLoginHandler)

	//Register user
	router.OPTIONS("/addmobileapi", libhttp.CORSMiddleware())
	router.POST("/addmobileapi", controller.Add_Mobile)

	router.OPTIONS("/sendmobileotp", libhttp.CORSMiddleware())
	router.POST("/sendmobileotp", controller.GenerateOTP_NEW)

	router.OPTIONS("/mainlogin", libhttp.CORSMiddleware())
	router.POST("/mainlogin", controller.Login_Mobile)

	router.OPTIONS("/forgotpassword", libhttp.CORSMiddleware())
	router.POST("/forgotpassword", controller.Forgot_Password)

	router.OPTIONS("/setpass", libhttp.CORSMiddleware())
	router.POST("/setpass", controller.Set_Password)

	router.OPTIONS("/unblockuser", libhttp.CORSMiddleware())
	router.GET("/unblockuser", controller.UnblockUsrController)

	router.OPTIONS("/verifymobileotp", libhttp.CORSMiddleware())
	router.POST("/verifymobileotp", controller.VerifyOTPController)

	//mstock 2.0

	router.OPTIONS("/glogin", libhttp.CORSMiddleware())
	router.GET("/glogin", controller.GLoginHandler) //Render view Landing Page

	// router.OPTIONS("/auth", libhttp.CORSMiddleware())
	// router.GET("/auth", controller.AuthHandler) // Handling Google Authetication
	router.OPTIONS("/gettoken", libhttp.CORSMiddleware())
	router.GET("/gettoken", controller.GetTokenHandler) // Get Refresh Adn Acces token
	router.OPTIONS("/addmobile", libhttp.CORSMiddleware())
	router.POST("/addmobile", controller.AddMobileHandler) // Mobile Page VAlidation
	router.OPTIONS("/mpin", libhttp.CORSMiddleware())
	router.GET("/mpin", controller.AddMPINHandler) // Mobile Page VAlidation
	router.OPTIONS("/mpinapi", libhttp.CORSMiddleware())
	router.POST("/mpinapi", controller.AddMPINApiHandler) // Mobile Page VAlidation
	router.OPTIONS("/setmpin", libhttp.CORSMiddleware())
	router.GET("/setmpin", controller.SetMPINHandler)
	router.OPTIONS("/setmpinapi", libhttp.CORSMiddleware())
	router.POST("/setmpinapi", controller.SetMPINApiHandler)
	router.OPTIONS("/registerhandler", libhttp.CORSMiddleware())
	router.POST("/registerhandler", controller.Register)

	router.OPTIONS("/forgetpassword", libhttp.CORSMiddleware())
	router.POST("/forgetpassword", controller.ForgetPassword)
	router.OPTIONS("/newpassword", libhttp.CORSMiddleware())
	router.POST("/newpassword", controller.NewPassword)
	router.OPTIONS("/newpass", libhttp.CORSMiddleware())
	router.POST("/newpass", controller.New_Password)
	router.OPTIONS("/register", libhttp.CORSMiddleware())
	router.GET("/register", controller.RegisterTempController)
	router.OPTIONS("/forgotpass", libhttp.CORSMiddleware())
	router.GET("/forgotpass", controller.ForgotPassTempController)
	router.OPTIONS("/setpassword", libhttp.CORSMiddleware())
	router.GET("/setpassword", controller.SetPassController)

	router.OPTIONS("/kyc", libhttp.CORSMiddleware())
	router.POST("/kyc", controller.KycDataHandler)
	// router.OPTIONS("/unblockuser", libhttp.CORSMiddleware())
	router.POST("/unblockuser", controller.UnblockUserHandler)
	router.OPTIONS("/getprofile", libhttp.CORSMiddleware())
	router.GET("/getprofile", controller.GetProfileHandler)
	router.OPTIONS("/googleauth", libhttp.CORSMiddleware())
	router.POST("/googleauth", controller.GoogleAuth)

	router.OPTIONS("/setnewmpin", libhttp.CORSMiddleware())
	router.POST("/setnewmpin", controller.SetMPIN)
	router.OPTIONS("/addmpin", libhttp.CORSMiddleware())
	router.POST("/addmpin", controller.AddMPINApiHandler)
	router.OPTIONS("/normallogin", libhttp.CORSMiddleware())
	router.POST("/normallogin", controller.NormalLogin)

	router.OPTIONS("/getAccessToken", libhttp.CORSMiddleware())
	router.GET("/getAccessToken", controller.GetAccessToken)
	router.OPTIONS("/getaccesstokenonrefreshtoken", libhttp.CORSMiddleware())
	router.GET("/getaccesstokenonrefreshtoken", controller.GetAccessTokenOnRefreshToken)

	router.OPTIONS("/fingerprintlogin", libhttp.CORSMiddleware())
	router.GET("/fingerprintlogin", controller.FingerPrint_Login)
	router.OPTIONS("/forgotmpin", libhttp.CORSMiddleware())
	router.POST("/forgotmpin", controller.Forgot_MPin)
	router.OPTIONS("/changempin", libhttp.CORSMiddleware())
	router.POST("/changempin", controller.ChangeMpin)
	router.OPTIONS("/changepassword", libhttp.CORSMiddleware())
	router.POST("/changepassword", controller.ChangePassword)
	router.OPTIONS("/validatelogin", libhttp.CORSMiddleware())
	router.POST("/validatelogin", controller.ValidateLogin)
	router.OPTIONS("/clearjwt", libhttp.CORSMiddleware())
	router.GET("/clearjwt", controller.ClearJwt)
	router.OPTIONS("/taxbuddy", libhttp.CORSMiddleware())
	router.GET("/taxbuddy", controller.TaxBuddyHandler)
	router.POST("/hypersynclogin", controller.NewHyperSyncLoginHandler)
	// router.GET("/gettotp", GenerateTOTPSecret)
	router.OPTIONS("/greewarelogin", libhttp.CORSMiddleware())
	router.GET("/greewarelogin", controller.GreenWareAccessTokenController)

	router.OPTIONS("/entertotp", libhttp.CORSMiddleware())
	router.GET("/entertotp", controller.TotpController)
	router.OPTIONS("/addprofile", libhttp.CORSMiddleware())
	router.POST("/addprofile", controller.AddProfilePic)
	router.OPTIONS("/removeprofile", libhttp.CORSMiddleware())
	router.POST("/removeprofile", controller.RemoveProfilePic)
	router.OPTIONS("/forgotmpintemp", libhttp.CORSMiddleware())
	router.GET("/forgotmpintemp", controller.ForgotMpinController)
	router.OPTIONS("/forgotmpinapi", libhttp.CORSMiddleware())
	router.POST("/forgotmpinapi", controller.ForgotMpinApiHandler)

	router.POST("/verifycaptchaapi", service.VerifyCaptcha_Web)
	router.POST("/reloadcaptcha", service.ReloadCaptcha_Web)
	router.POST("/verifycaptcha", service.VerifyCaptcha_Mob)
	router.POST("/refreshcaptcha", service.ReloadCaptcha_Mob)
	router.OPTIONS("/verifyotpweb", libhttp.CORSMiddleware())
	router.POST("/verifyotpweb", controller.VerifyOTPWeb)
	router.POST("/update/stockalCustId", controller.StockalHandler)
	router.OPTIONS("/addreferral", libhttp.CORSMiddleware())
	router.POST("/addreferral", controller.AddReferral)

	//totp api mstock

	// router.OPTIONS("/enabletotp", libhttp.CORSMiddleware())
	// router.POST("/enabletotp", controller.EnableTOTP)
	// router.OPTIONS("/verifytotp", libhttp.CORSMiddleware())
	// router.POST("/verifytotp", controller.TotpAuthenticate)
	// router.OPTIONS("/checktotp", libhttp.CORSMiddleware())
	// router.POST("/checktotp", controller.TotpAuthenticateHandler)
	// router.OPTIONS("/verifytotpformobile", libhttp.CORSMiddleware())
	// router.POST("/verifytotpformobile", controller.TotpAuthenticateForMobile)
	// router.OPTIONS("/disabletotp", libhttp.CORSMiddleware())
	// router.POST("/disabletotp", controller.DisableTOTPForMobile)
	// router.OPTIONS("/checktotpformobile", libhttp.CORSMiddleware())
	// router.POST("/checktotpformobile", controller.TotpAuthenticateHandlerForMobile)

	return nil
}
