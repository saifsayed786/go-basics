package controller

import (
	"net/http"
	"strconv"

	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/gin"
)

func RemoveProfilePic(c *gin.Context) {
	libhttp.CoreHeader(c)
	mobile_no, err := service.GetUser(c)
	if err != nil {
		service.Zerologs.Error().Err(err).Msg("RemoveProfilePic(): Unauthorized token")
		c.JSON(http.StatusUnauthorized, "Unauthorized")
		return
	}
	MobileNo := strconv.FormatUint(uint64(mobile_no), 10)
	if service.Env.AWS_S3_REGION == "" {
		service.Zerologs.Error().Msg("service.Env.AWS_S3_REGION not Found ")
		c.JSON(http.StatusBadRequest, "")
		return
	}
	if service.Env.AWS_ACCESS_KEY_ID == "" {
		service.Zerologs.Error().Msg("service.Env.AWS_ACCESS_KEY_ID not Found ")
		c.JSON(http.StatusBadRequest, "")
		return
	}
	if service.Env.AWS_SECRET_ACCESS_KEY == "" {
		service.Zerologs.Error().Msg("service.Env.AWS_SECRET_ACCESS_KEY not Found ")
		c.JSON(http.StatusBadRequest, "")
		return
	}

	response, err := service.RemoveProfilePicService(MobileNo)
	if err != nil {
		c.JSON(http.StatusInternalServerError, err)
		return
	}
	c.JSON(http.StatusOK, response)
}
