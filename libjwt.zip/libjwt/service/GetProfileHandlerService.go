package service

import (
	"github.com/MACMREPO/libdb/clientmaster"
	"github.com/MACMREPO/libjwt/model"
)

func GetProfileHandlerService(MobileNo string) (model.Profile, error) {
	var UserData model.Profile
	var UserModel clientmaster.JwtAuthMaster
	err := Db.Client.Where("mobile_no = ?", MobileNo).First(&UserModel).Error
	if err != nil {
		Zerologs.Error().Msg("GetProfileHandler(): Error in Getting Profile data from JwtAuthMaster for mobileno=" + MobileNo + " and error is " + err.Error())
		return UserData, err
	}
	var TblMobileEmailMapping clientmaster.TblMobileEmailMapping
	err = Db.Client.Where("mobile_no = ? AND email=?", MobileNo, UserModel.Email).First(&TblMobileEmailMapping).Error
	if err != nil {
		Zerologs.Error().Msg("GetProfileHandler(): Error in Getting  data from clientmaster.TblMobileEmailMapping for mobileno=" + MobileNo + " and error is " + err.Error())
		return UserData, err
	}

	var ReferralData clientmaster.ReferralMaster
	Db.Client.Where("mobile_no = ?", MobileNo).First(&ReferralData)

	istotp := TblMobileEmailMapping.IsTotpEnable
	if istotp {
		UserData.IsTotpEnabled = 1
	} else {
		UserData.IsTotpEnabled = 0
	}
	UserData.CLIENT_ID_MAIL = UserModel.Email
	UserData.UCC_CLIENT_ID = UserModel.ClientID
	UserData.UCLIENT_ID = UserModel.ClientID
	UserData.CLIENT_ID = UserModel.ClientID
	UserData.MOBILE_NO = UserModel.MobileNo
	UserData.SEX = UserModel.Gender
	UserData.CLIENT_NAME = UserModel.Name
	UserData.PAN = UserModel.Pan
	UserData.PAN_NO = UserModel.Pan
	if UserModel.Picture == "" {
		UserModel.Picture = Default_Profile_Pic
	}
	UserData.PICTURE = UserModel.Picture
	UserData.KYC_DONE = UserModel.KYCDone
	UserData.FullName = UserModel.Name
	UserData.Activated = UserModel.Activated
	UserData.ReferralCode = ReferralData.ReferralCode
	// fmt.Println("GetProfileHandler(): UserData=", UserData)
	return UserData, nil
}
