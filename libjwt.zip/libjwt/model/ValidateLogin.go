package model

type ValidateLoginModel struct {
	AccessToken string `json:"access_token"`
}

type ValidateLoginResponse struct {
	IsErr        bool   `json:"isErr"`
	Msg          string `json:"msg"`
	StatusCode   int    `json:"statusCode"`
	Url          string `json:"url"`
	RefreshToken string `json:"refresh_token"`
}
