package model

type HyperLoginmodel struct {
	UID        string `json:"uid"`
	Pwd        string `json:"pwd"`
	BrokerID   string `json:"brokerId"`
	Source     string `json:"source"`
	DeviceName string `json:"deviceName"`
	DeviceInfo string `json:"deviceInfo"`
}
type HypersyncLoginModel struct {
	UID         string `json:"uid"`
	Pwd         string `json:"pwd"`
	BrokerID    string `json:"brokerId"`
	Source      string `json:"source"`
	DeviceName  string `json:"deviceName"`
	DeviceInfo  string `json:"deviceInfo"`
	BuildNumber string `json:"buildNumber"`
}
