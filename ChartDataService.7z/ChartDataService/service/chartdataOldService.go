package service

import (
	"chartdataservice/models"
	"encoding/csv"
	"errors"
	"fmt"
	
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/TecXLab/liblogs"
)

var chTruedata = make(chan string, 200000)
var FileWritingModel = make(chan models.TrueDataChartModel, 50000)

type FileModel struct {
}

func EnqueueChTrueData(ch chan string, val string) {
	ch <- val
}
func AddFileToQueue(val string) {
	EnqueueChTrueData(chTruedata, val)
}
func DequeueChTrueData(ch chan string) {
	for m := range ch {
		SaveHistory_Old(m)
	}
}
func EnqueueFileWriting(ch chan models.TrueDataChartModel, val models.TrueDataChartModel) {
	ch <- val
}
func AddWritingToQueue(val models.TrueDataChartModel) {
	EnqueueFileWriting(FileWritingModel, val)
}
func DequeueFileWriting(ch chan models.TrueDataChartModel) {
	for m := range ch {
		//time1 := time.Now()
		FileWriting3(GetContractDetail(int(m.Token), m.Exch), m.Tf, true, m.ChartDataModel, m.Exch, m.Date, nil, m.Date)
		//fmt.Println("##file writing time %s", time.Since(time1), m.Date)
	}
}
func ReadDictionary(path string) [][]string {
	csvFile, err := os.Open(path)
	if err != nil {
		fmt.Println(err)
	}
	// fmt.Println("Successfully Opened CSV file")
	defer csvFile.Close()

	csvLines, err := csv.NewReader(csvFile).ReadAll()
	if err != nil {
		zerologs.Err(err).Msg("In SaveHistory")
		Logger("In SaveHistory", err, liblogs.Error, liblogs.ZEROLOG)

	}

	DayDictionary := make([][]string, 0)
	TimeDictionary := make([]string, 0)

	prevdate := ""
	var startDate int64
	// var endDate int64

	for j := range csvLines {

		if prevdate != "" && csvLines[j][0] != prevdate { //02062021  //01062021
			// endDate = 0
			startDate = 0
			// TimeDictionary = append(TimeDictionary, strings.Join(csvLines[j], ","))
			if len(TimeDictionary) > 0 {
				DayDictionary = append(DayDictionary, TimeDictionary)
			}

			TimeDictionary = make([]string, 0)
		}

		if startDate == 0 {
			strStartDate, _ := time.Parse("2006010215:04:05", csvLines[j][0]+"09:15:00")
			startDate = strStartDate.Unix()
			// strEndDate, _ := time.Parse("2006010215:04:05", csvLines[j][0]+"15:29:00")
			// endDate = strEndDate.Unix()
		}

		strTime, err := time.Parse("2006010215:04:05", csvLines[j][0]+csvLines[j][1]+":00")
		if err != nil {
			Logger("In Chart History", err, liblogs.Error, liblogs.ZEROLOG)

			break
		}

		if startDate == 0 || startDate <= strTime.Unix() {
			// if endDate == 0 || strTime.Unix() <= endDate {
			TimeDictionary = append(TimeDictionary, strings.Join(csvLines[j], ","))
			// }
		}

		if j == len(csvLines)-1 {
			if len(TimeDictionary) > 0 {
				DayDictionary = append(DayDictionary, TimeDictionary)
			}
		}

		prevdate = csvLines[j][0]
	}
	return DayDictionary
}

func SaveHistory_Old(path string) {
	// path := "D:\\GitHub\\KubeVolumeData\\chartdataservice\\TrueData\\Equity\\Adjusted"
	Dictionary := ReadDictionary(path)
	filenameArr := strings.Split(path, "\\")
	filename := filenameArr[(len(filenameArr) - 1)]
	Logger("Start "+path+" "+time.Now().Local().Format("0201200615:04:05"), nil, liblogs.Info, liblogs.PRINT)

	for i, v := range MinuteMap {
		ReadAndCreateMinutesFile(Dictionary, filename, int(v), i)
		// ReadAndCreateMinutesFile(Dictionary, filename, int(v), i)
		// ReadAndCreateMinutesFile(Dictionary, filename, int(v), i)
		// ReadAndCreateMinutesFile(Dictionary, filename, int(v), i)
		// ReadAndCreateMinutesFile(Dictionary, filename, int(v), i)
		// ReadAndCreateMinutesFile(Dictionary, filename, int(v), i)
		// ReadAndCreateMinutesFile(Dictionary, filename, int(v), i)
		// ReadAndCreateMinutesFile(Dictionary, filename, int(v), i)
		// ReadAndCreateMinutesFile(Dictionary, filename, int(v), i)
		// ReadAndCreateMinutesFile(Dictionary, filename, int(v), i)
		// ReadAndCreateMinutesFile(Dictionary, filename, int(v), i)
		// ReadAndCreateMinutesFile(Dictionary, filename, int(v), i)
		// ReadAndCreateMinutesFile(Dictionary, filename, int(v), i)
		// ReadAndCreateMinutesFile(Dictionary, filename, int(v), i)
	}
	fmt.Println("End" + path + " " + time.Now().Local().Format("0201200615:04:05"))

}

func ReadAndCreateMinutesFile(Dictionary [][]string, FileName string, minute int, folderName string) {
	prevMinute := minute
	newpath := "D:\\GitHub\\KubeVolumeData\\chartdataservice\\nse1\\" + strings.Replace(FileName, ".csv", "", -1)
	if _, err := os.Stat(newpath); errors.Is(err, os.ErrNotExist) {
		err := os.MkdirAll(newpath, 0777)
		if err != nil {
			Logger("Message: ", err, liblogs.Error, liblogs.PRINT)

		}
	}
	newpath = newpath + "//" + folderName + "//"

	if _, err := os.Stat(newpath); errors.Is(err, os.ErrNotExist) {
		err := os.MkdirAll(newpath, 0777)
		if err != nil {
			Logger("Message: ", err, liblogs.Error, liblogs.PRINT)

		}
	}
	for values := range Dictionary {
		fileName := strings.Split(Dictionary[values][0], ",")[0]
		//"2020-06-29T00:00:00+0530

		file, err := os.OpenFile(newpath+fileName+".csv", os.O_APPEND|os.O_WRONLY, 0777)
		if os.IsNotExist(err) {
			file, err = os.Create(newpath + fileName + ".csv")

			if err != nil {
				Logger("failed creating file: ", err, liblogs.Error, liblogs.ZEROLOG)

			}
		}
		defer file.Close()

		arrDaywise := Dictionary[values]

		var arrInsertLines []string

		for i := 0; i < len(arrDaywise)-1; i++ {

			if minute == 374 {
				minute = len(arrDaywise) - 1
			}

			OpenPrice := ""
			ClosePrice := ""
			var HighPrice float64
			var LowPrice float64
			var TotalVolume int64
			Date := ""
			Time := ""

			//to handle last record incase duration less than target minute
			if len(arrDaywise)-i < minute {
				minute = len(arrDaywise) - i
			}
			for j := 0; j < minute; j++ {

				arrHistory := strings.Split(arrDaywise[i], ",")
				Date = arrHistory[0]

				NewHighPrice, _ := strconv.ParseFloat(arrHistory[3], 64)
				NewLowPrice, _ := strconv.ParseFloat(arrHistory[4], 64)
				if HighPrice <= NewHighPrice {
					HighPrice = NewHighPrice
				}

				if LowPrice >= NewLowPrice {
					LowPrice = NewLowPrice
				}
				if j == 0 {
					OpenPrice = arrHistory[2]
					LowPrice, _ = strconv.ParseFloat(arrHistory[4], 64)
					Time = arrHistory[1]
				}
				if j == minute-1 {
					ClosePrice = arrHistory[5]
				}

				Volume, _ := strconv.ParseInt(arrHistory[6], 0, 0)
				TotalVolume += Volume

				if j < minute-1 {
					i += 1
				}
			}

			TimeStamp, err := time.Parse("2006010215:04:05", Date+Time+":00")
			if err != nil {

				Logger("Message: ", err, liblogs.Error, liblogs.PRINT)

			}
			sLineToInsert := TimeStamp.Format("2006-01-02T15:04:05") + "+0530" + "," + OpenPrice + "," + fmt.Sprint(HighPrice) + "," + fmt.Sprint(LowPrice) + "," + fmt.Sprint(ClosePrice) + "," + fmt.Sprint(TotalVolume)
			arrInsertLines = append(arrInsertLines, sLineToInsert)
			minute = prevMinute
		}
		for index := len(arrInsertLines) - 1; index >= 0; index-- {
			_, err = file.WriteString(arrInsertLines[index] + "\n")
			if err != nil {

				Logger(fmt.Sprintf("failed writing to file: %s", err), err, liblogs.Error, liblogs.PRINT)

			}
		}
		if minute == 374 {
			// WeekDictionary = append(WeekDictionary, arrInsertLines)
		}
	}

	if minute == 374 {
		//call week from day create
		// CreateWeekFile(WeekDictionary, FileName, "1Week")
	}
}

func UpDateTrueStore() {
	path := "D:\\Chart_Data\\NSE(Equity+Indices)-1min-(01Jun2017to31Aug2022)-Adjusted\\Equity\\Adjusted"
	files, err := os.ReadDir(path)
	if err != nil {
		fmt.Println(err)
	}
	// var FileCount = 1
	for i := range files {
		// if i > 0 {
		// 	break
		// }
		time1 := time.Now()
		symbol := strings.Split(files[i].Name(), ".")[0]

		// if _, err := os.Stat("D:\\GitHub\\KubeVolumeData\\chartdataservice\\nse_5_Years\\" + symbol); errors.Is(err, os.ErrNotExist) {
		// 	fmt.Println(symbol + " --> " + strconv.Itoa(FileCount))
		// 	FileCount++
		// 	continue
		// } else {
		// 	continue
		// }
		//fmt.Println(time.Now().String() + " " + symbol)
		tokenNumber := GetToken(ExIds["nseeq"], symbol)
		if tokenNumber < 0 {
			continue
		}

		csvFile, err := os.Open(path + "\\" + files[i].Name())
		if err != nil {
			fmt.Println(err)
		}
		defer csvFile.Close()
		var ComapanyNameMap = make(map[string][]string)
		csvLines, err := csv.NewReader(csvFile).ReadAll()
		if err != nil {
			zerologs.Err(err).Msg("In SaveHistory")
		}
		for values := range csvLines {
			minData := strings.Join(csvLines[values], ",")
			ComapanyNameMap[csvLines[values][0]] = append(ComapanyNameMap[csvLines[values][0]], minData)
		}
		//var DateCount = 1
		for date, values := range ComapanyNameMap {
			//fmt.Println(time.Now().String() + " " + date)
			// if DateCount > 5 {
			// 	break
			// }
			// DateCount++
			var NewChartRespModel models.NewChartRespModel
			NewChartRespModel.ExchID = ExIds["nseeq"]
			NewChartRespModel.DateTime = date
			//time1 := time.Now()
			for i := range values {
				sCSV := values[i]
				sCSVArr := strings.Split(sCSV, ",")
				dt := sCSVArr[0]
				dtime := sCSVArr[1]
				dt_time := dt + dtime + ":00"
				dtlog, err := time.Parse("2006010215:04:05", dt_time)
				if err != nil {
					fmt.Println(err)
				}
				Dtlogtime := dtlog.Format("2006-01-02T15:04:05")
				Op := StringToFloat64_New(sCSVArr[2])
				Hp := StringToFloat64_New(sCSVArr[3])
				Lp := StringToFloat64_New(sCSVArr[4])
				Cp := StringToFloat64_New(sCSVArr[5])
				Vl := StringToFloat64_New(sCSVArr[6])
				NewChartRespModel.ChartHLOCModel = append(NewChartRespModel.ChartHLOCModel, models.ChartHLOCModel{ExchId: 2, NToken: int(tokenNumber), NOpenPrice: Op, NHighPrice: Hp, NLowPrice: Lp, NClosingPrice: Cp, NVolume: Vl, DtLogDateTime: Dtlogtime})
			}
			SaveHistoryDeqNew(NewChartRespModel)
			//fmt.Println("Date Store Update time %s", time.Since(time1), date)
			for tf, v := range Store[tokenNumber][ExIds["nseeq"]].StoreMap {
				// if tf != "1Min" {
				// 	continue
				// }
				//time1 := time.Now()
				var TrueDataChartModel models.TrueDataChartModel
				TrueDataChartModel.ChartDataModel.CSVMap = v.CSVMap
				TrueDataChartModel.ChartDataModel.KeySlice = v.KeySlice
				TrueDataChartModel.Date = date
				TrueDataChartModel.Exch = ExIds["nseeq"]
				TrueDataChartModel.Symbol = files[i].Name()
				TrueDataChartModel.Tf = tf
				TrueDataChartModel.Token = int(tokenNumber)
				AddWritingToQueue(TrueDataChartModel)
				//FileWriting3(GetContractDetail(int(TrueDataChartModel.Token), TrueDataChartModel.Exch), TrueDataChartModel.Tf, true, TrueDataChartModel.ChartDataModel, TrueDataChartModel.Exch, TrueDataChartModel.Date, nil, TrueDataChartModel.Date)
				//fmt.Println("TF Enqu time %s", time.Since(time1))
			}
			//Store[tokenNumber][ExIds["nseeq"]].StoreMap = nil
			for k := range Store[tokenNumber][ExIds["nseeq"]].StoreMap {
				delete(Store[tokenNumber][ExIds["nseeq"]].StoreMap, k)
			}
		}
		fmt.Println(time.Now().String()+" :: Date Store Update time %s", time.Since(time1), symbol)
	}
}
