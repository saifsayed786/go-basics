package controller

import (
	"net/http"

	"github.com/MACMREPO/libjwt/model"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/gin"
)

func NewHyperSyncLoginHandler(c *gin.Context) {
	var mpinmodel model.HypersyncModel
	err := c.BindJSON(&mpinmodel)
	if err != nil {
		c.JSON(http.StatusBadRequest, "")
		return
	}
	key, err := service.NewHyperSyncLogin(mpinmodel)
	if err == nil {
	}
	c.JSON(http.StatusOK, key)
}
