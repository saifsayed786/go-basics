package service

// import (
// 	"time"

// 	"github.com/MACMREPO/libdb/clientmaster"
// 	"github.com/MACMREPO/libjwt/model"
// )

// func SetMPINApiService(RetrievedState string, setmpinmodel model.SetMpinModel) (map[string]string, error) {
// 	token := make(map[string]string)
// 	val, err := RedisLib.Client.Get(RetrievedState).Result()
// 	if err != nil {
// 		Zerologs.Error().Msg("SetMPINApiHandler(): Val[guid] not getting from redis by using retrieved state" + RetrievedState + err.Error())
// 		return nil, err
// 	}
// 	var clientdbData clientmaster.JwtAuthMaster
// 	err = Db.Client.Where("user_guid=?", val).First(&clientdbData).Error
// 	if err != nil {
// 		Zerologs.Error().Msg("SetMPINApiHandler(): User data not found in JwtAuthMaster where user_guid=  " + val + err.Error())
// 		return nil, err
// 	} else {
// 		err = Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", clientdbData.MobileNo).Updates(clientmaster.JwtAuthMaster{LastMPIN_UpdatedTime: time.Now(), MPIN: setmpinmodel.NewMpin, IsMPIN_Reset: true}).Error
// 		if err != nil {
// 			Zerologs.Error().Msg("SetMPINApiHandler(): setmpin update query failed where mobile_no:=" + clientdbData.MobileNo + " " + err.Error())
// 			return nil, err
// 		}
// 		token["Msg"] = "Mpin set successfully"
// 		token["url"] = "/sign/glogin"
// 		Zerologs.Info().Msg("SetMPINApiHandler(): Mpin successfully set for mobileno:=" + clientdbData.MobileNo)
// 	}
// 	return token, nil
// }

// func SetMPINService(MobileNo string, setmpinmodel model.SetMpinModel) (map[string]string, error) {
// 	var clientdbData clientmaster.JwtAuthMaster
// 	err := Db.Client.Where("mobile_no=?", MobileNo).First(&clientdbData).Error
// 	if err != nil {
// 		Zerologs.Error().Msg("SetMPIN(): User data not found for mobileno=" + MobileNo + " and error is " + err.Error())
// 		return nil, err
// 	} else {
// 		err = Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", clientdbData.MobileNo).Updates(clientmaster.JwtAuthMaster{LastMPIN_UpdatedTime: time.Now(), MPIN: setmpinmodel.NewMpin, IsMPIN_Reset: true}).Error
// 		if err != nil {
// 			Zerologs.Error().Msg("SetMPIN(): setmpin update query failed for mobileno=" + clientdbData.MobileNo + " and error is " + err.Error())
// 			return nil, err
// 		}

// 		token, err := GenerateJWTWithRefresh(clientdbData.MobileNo, clientdbData.Email, "") //Samir pending
// 		if err != nil {
// 			// fmt.Println("GenerateJWTWithRefresh Erro = " + err.Error())
// 			Zerologs.Error().Msg("SetMPIN(): Error in GenerateJWTWithRefresh for mobileno=" + clientdbData.MobileNo + " and email=" + clientdbData.Email + " is " + err.Error())
// 			return nil, err
// 		}
// 		if clientdbData.KYCDone == true {
// 			if clientdbData.Activated {
// 				//new hypersync code ---start---
// 				token["isKyc"] = "true"
// 				token["isActivated"] = "true"
// 				token["isMpinSet"] = "true"
// 				// token["refresh_token"] = clientdbData.Refreshtoken
// 				Zerologs.Info().Msg("SetMPIN(): Mpin successfully set for mobileno:=" + clientdbData.MobileNo)
// 				return token, nil
// 				//new hypersync code ---end---

// 				//old hypersync code--- start -----
// 				// // if clientdbData.IsMPIN_Reset == false {
// 				// // 	token["isKyc"] = "true"
// 				// // 	token["isActivated"] = "true"
// 				// // 	token["isMpinSet"] = "false"
// 				// // 	token["refresh_token"] = clientdbData.Refreshtoken
// 				// // 	c.JSON(http.StatusOK, token)
// 				// // 	return
// 				// // }
// 				// loginModel := model.HyperLoginmodel{
// 				// 	UID:        clientdbData.ClientID + "-" + setmpinmodel.BrokerID,
// 				// 	Pwd:        clientdbData.Password,
// 				// 	BrokerID:   setmpinmodel.BrokerID,
// 				// 	Source:     setmpinmodel.Source,
// 				// 	DeviceName: setmpinmodel.DeviceName,
// 				// 	DeviceInfo: setmpinmodel.DeviceInfo,
// 				// }
// 				// key, IsMPINRequired, err := HypersyncLogin(loginModel)
// 				// fmt.Println("hypersync devicempin key: ", key)
// 				// if err == nil {
// 				// 	token["devicekey"] = key
// 				// 	if IsMPINRequired {
// 				// 		token["isKyc"] = "true"
// 				// 		token["isActivated"] = "true"
// 				// 		token["isMpinSet"] = "true"
// 				// 		token["refresh_token"] = clientdbData.Refreshtoken
// 				// 		c.JSON(http.StatusOK, token)
// 				// 		return
// 				// 	}
// 				// }
// 				// token["isKyc"] = "true"
// 				// token["isMpinSet"] = "true"
// 				// token["isActivated"] = "true"
// 				// token["refresh_token"] = clientdbData.Refreshtoken
// 				// c.JSON(http.StatusOK, token)
// 				//old hypersync code ---end -----

// 			} else {
// 				// if clientdbData.IsMPIN_Reset == false {
// 				// 	token["isKyc"] = "true"
// 				// 	token["isActivated"] = "false"
// 				// 	token["isMpinSet"] = "false"
// 				// 	token["refresh_token"] = clientdbData.Refreshtoken
// 				// 	c.JSON(http.StatusOK, token)
// 				// 	return
// 				// }
// 				token["hypersyncAccessToken"] = ""
// 				token["isKyc"] = "true"
// 				token["isMpinSet"] = "false"
// 				token["isActivated"] = "false"
// 				// token["refresh_token"] = clientdbData.Refreshtoken
// 				return token, nil
// 			}
// 		} else {
// 			token["isKyc"] = "false"
// 			token["isActivated"] = "false"
// 			token["Msg"] = "Login Success"
// 			// token["refresh_token"] = clientdbData.Refreshtoken
// 			return token, nil

// 		}
// 		// token := make(map[string]string)
// 		// token["isMpinSet"] = "true"
// 		// token["Msg"] = "move to add mpin"
// 		// c.JSON(http.StatusOK, token)
// 	}
// }
