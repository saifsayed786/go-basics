package model

type ConvtoDelModel struct {
	Exchange     string `json:"exchange,omitempty"`
	UserType     string `json:"user_type,omitempty"`
	Seg          string `json:"seg,omitempty"`
	ExchClientID string `json:"exch_client_id,omitempty"`
	Securityid   string `json:"securityid,omitempty"`
	ClientID     string `json:"client_id,omitempty"`
	Productto    string `json:"productto,omitempty"`
	Buysell      string `json:"buysell,omitempty"`
	UserID       string `json:"user_id,omitempty"`
	Source       string `json:"source,omitempty"`
	ClientType   string `json:"client_type,omitempty"`
	TokenID      string `json:"token_id,omitempty"`
	Productfrom  string `json:"productfrom,omitempty"`
	InstType     string `json:"inst_type,omitempty"`
	Quantity     string `json:"quantity,omitempty"`
}
