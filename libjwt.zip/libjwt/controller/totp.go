package controller

// import (
// 	"bytes"
// 	"encoding/base64"
// 	"fmt"
// 	"image/png"
// 	"net/http"
// 	"strconv"
// 	"time"

// 	"github.com/MACMREPO/libdb/clientmaster"
// 	"github.com/MACMREPO/libhttp"

// 	"github.com/MACMREPO/libjwt/dgoogauth"
// 	"github.com/MACMREPO/libjwt/model"
// 	"github.com/MACMREPO/libjwt/service"
// 	"github.com/gin-gonic/contrib/sessions"
// 	"github.com/gin-gonic/gin"
// 	"github.com/pquerna/otp/totp"
// )

// func TotpAuthenticate(c *gin.Context) {
// 	libhttp.CoreHeader(c)
// 	session := sessions.Default(c)
// 	retrievedState := session.Get("state")
// 	cquery := c.Query("state")
// 	if retrievedState != cquery {
// 		// service.Zerologs.Error().Msg("TotpAuthenticate(): retrievedState and cquery is not equal:=  " + retrievedState.(string) + " -- " + cquery)
// 		// c.AbortWithError(http.StatusUnauthorized, fmt.Errorf("Invalid session state: %s", retrievedState))
// 		// return
// 	}
// 	mobile_no, err := service.GetUser(c)
// 	if err != nil {
// 		service.Zerologs.Error().Err(err).Msg("TotpAuthenticate(): Unauthorized")
// 		c.JSON(http.StatusUnauthorized, "Unauthorized")
// 		return
// 	}
// 	MobileNo := strconv.FormatUint(uint64(mobile_no), 10)
// 	fmt.Println("MobileNo ", MobileNo)
// 	var objTotp model.TotpAuthModel
// 	err = c.BindJSON(&objTotp)
// 	if err != nil {
// 		service.Zerologs.Error().Msg("TotpAuthenticate(): Error in BindJSON() objTotp: " + err.Error())
// 		c.JSON(http.StatusBadRequest, err)
// 		return
// 	}
// 	token := make(map[string]string)
// 	if objTotp.TOTP == "" {
// 		service.Zerologs.Info().Msg("TotpAuthenticate(): TOTP can not be empty")
// 		token["errMsg"] = "TOTP can not be empty"
// 		c.JSON(http.StatusInternalServerError, token)
// 		return
// 	}
// 	if objTotp.Password == "" {
// 		service.Zerologs.Info().Msg("TotpAuthenticate(): Password can not be empty")
// 		token["errMsg"] = "Password can not be empty"
// 		c.JSON(http.StatusInternalServerError, token)
// 		return
// 	}
// 	fmt.Println("RequestModel= ", objTotp)
// 	RetrievedState := retrievedState.(string)
// 	// RedirectUrl, err := service.RedisLib.Client.Get(RetrievedState + "-RedirectUrl").Result()
// 	if err != nil {
// 		service.Zerologs.Error().Msg("TotpAuthenticate(): RedirectUrl not getting from redis by using retrieved state for user mobileNo:= " + MobileNo + " and RetrievedState is = " + RetrievedState + err.Error())
// 		c.JSON(http.StatusInternalServerError, "RedirectUrl null")
// 		return
// 	}
// 	var clientData clientmaster.TblMobileEmailMapping
// 	err = service.Db.Client.Where("mobile_no=?", MobileNo).First(&clientData).Error
// 	if err != nil {
// 		service.Zerologs.Error().Msg("TotpAuthenticate(): User data not found in TblMobileEmailMapping for mobileno=" + MobileNo + " and error is " + err.Error())
// 		c.JSON(http.StatusInternalServerError, "data not found in db")
// 		return
// 	}
// 	fmt.Println("SecretKey= ", clientData.TotpSecretKey)
// 	otpc := dgoogauth.OTPConfig{
// 		Secret:      clientData.TotpSecretKey,
// 		WindowSize:  3,
// 		HotpCounter: 0,
// 		// UTC:         true,
// 	}
// 	fmt.Println("otpc= ", otpc)
// 	val, err := otpc.Authenticate(objTotp.TOTP)
// 	if err != nil {
// 		service.Zerologs.Error().Msg("TotpAuthenticate(): Error in otpc.Authenticate() is " + err.Error())
// 		c.JSON(http.StatusInternalServerError, err)
// 		return
// 	}
// 	fmt.Println("val= ", val)
// 	if !val {
// 		service.Zerologs.Info().Msg("TotpAuthenticate(): User " + MobileNo + " enter wrong TOTP ")
// 		token["errMsg"] = " UnAuthenticated, please enter correct TOTP "
// 		c.JSON(http.StatusUnauthorized, token)
// 		return
// 	} else {
// 		var clientdbData clientmaster.JwtAuthMaster
// 		err = service.Db.Client.Where("mobile_no=?", MobileNo).First(&clientdbData).Error
// 		if err != nil {
// 			service.Zerologs.Error().Msg("TotpAuthenticate(): User data not found in JwtAuthMaster where mobileNo=  " + MobileNo + err.Error())
// 			c.JSON(http.StatusInternalServerError, "clientdbData not found")
// 			return
// 		}
// 		if clientdbData.Password == objTotp.Password {
// 			err = service.Db.Client.Where("mobile_no=? AND email=?", MobileNo, clientData.Email).Updates(clientmaster.TblMobileEmailMapping{IsTotpEnable: true, TotpStatus: true}).Error
// 			if err != nil {
// 				service.Zerologs.Error().Msg("TotpAuthenticate(): IsTotpEnable update query failed where MobileNo:=  " + MobileNo + " and email " + clientData.Email + err.Error())
// 				return
// 			}
// 			c.JSON(http.StatusOK, "TOTP successfully enabled")
// 		} else {
// 			service.Zerologs.Info().Msg("TotpAuthenticate():User " + MobileNo + " enter wrong password ")
// 			token["errMsg"] = " Wrong password "
// 			c.JSON(http.StatusInternalServerError, token)
// 			return
// 		}

// 	}

// }
// func TotpAuthenticateHandler(c *gin.Context) {
// 	libhttp.CoreHeader(c)
// 	session := sessions.Default(c)
// 	retrievedState := session.Get("state")
// 	cquery := c.Query("state")
// 	if retrievedState != cquery {
// 		// service.Zerologs.Error().Msg("TotpAuthenticate(): retrievedState and cquery is not equal:=  " + retrievedState.(string) + " -- " + cquery)
// 		// c.AbortWithError(http.StatusUnauthorized, fmt.Errorf("Invalid session state: %s", retrievedState))
// 		// return
// 	}
// 	if retrievedState == nil {
// 		service.Zerologs.Info().Msg("TotpAuthenticateHandler(): RetrievedState is null ")
// 		return
// 	}
// 	RetrievedState := retrievedState.(string)
// 	guid, err := service.RedisLib.Client.Get(RetrievedState).Result()
// 	if err != nil {
// 		service.Zerologs.Error().Msg("TotpAuthenticateHandler():UserGuid not getting from redis by using retrieved state:= " + RetrievedState + err.Error())
// 		c.JSON(http.StatusInternalServerError, "RetrievedState null")
// 		return
// 	}
// 	var clientdbData clientmaster.JwtAuthMaster
// 	err = service.Db.Client.Where("user_guid=?", guid).First(&clientdbData).Error
// 	if err != nil {
// 		service.Zerologs.Error().Msg("AddMPINApiHandler(): User not found in clientmaster.JwtAuthMaster where user_guid=  " + guid + err.Error())
// 		c.JSON(http.StatusInternalServerError, "clientdbData not found")
// 		return
// 	}
// 	var objTotp model.TotpAuthModel
// 	err = c.BindJSON(&objTotp)
// 	if err != nil {
// 		service.Zerologs.Error().Msg("TotpAuthenticateHandler(): Error in BindJSON() objTotp: " + err.Error())
// 		c.JSON(http.StatusBadRequest, err)
// 		return
// 	}
// 	RedirectUrl, err := service.RedisLib.Client.Get(RetrievedState + "-RedirectUrl").Result()
// 	if err != nil {
// 		service.Zerologs.Error().Msg("TotpAuthenticateHandler(): RedirectUrl not getting from redis by using retrieved state for user mobileNo:= " + clientdbData.MobileNo + " and RetrievedState is = " + RetrievedState + err.Error())
// 		c.JSON(http.StatusInternalServerError, "RedirectUrl null")
// 		return
// 	}
// 	token := make(map[string]string)
// 	var clientData clientmaster.TblMobileEmailMapping
// 	err = service.Db.Client.Where("mobile_no=?", clientdbData.MobileNo).First(&clientData).Error
// 	if err != nil {
// 		service.Zerologs.Error().Msg("TotpAuthenticateHandler(): User data not found in TblMobileEmailMapping for mobileno=" + clientdbData.MobileNo + " and error is " + err.Error())
// 		c.JSON(http.StatusInternalServerError, "data not found in db")
// 		return
// 	}
// 	otpc := &dgoogauth.OTPConfig{
// 		Secret:      clientData.TotpSecretKey,
// 		WindowSize:  3,
// 		HotpCounter: 0,
// 		// UTC:         true,
// 	}
// 	val, err := otpc.Authenticate(objTotp.TOTP)
// 	if err != nil {
// 		service.Zerologs.Error().Msg("TotpAuthenticateHandler(): Error in otpc.Authenticate() is " + err.Error())
// 		c.JSON(http.StatusInternalServerError, err)
// 		return
// 	}
// 	if !val {
// 		service.Zerologs.Info().Msg("TotpAuthenticateHandler(): User " + clientdbData.MobileNo + " enter wrong TOTP ")
// 		token["errMsg"] = " UnAuthenticated, please enter correct TOTP "
// 		c.JSON(http.StatusUnauthorized, token)
// 		return
// 	} else {
// 		sAccountcode := clientdbData.ClientID + "-" + "NIT" //service.Env.BROKERID
// 		token, err = service.GenerateJWTWithRefresh(clientdbData.MobileNo, clientdbData.Email, sAccountcode)
// 		if err != nil {
// 			service.Zerologs.Error().Msg("TotpAuthenticateHandler(): Error in service.GenerateJWTWithRefresh for mobileno=" + clientdbData.MobileNo + " and email=" + clientdbData.Email + " is " + err.Error())
// 			c.JSON(http.StatusInternalServerError, "")
// 			return
// 		}
// 		hypersyncereq := model.HypersyncModel{
// 			Uid:      clientdbData.ClientID + "_" + "NIT", // + "-" + mpinmodel.BrokerID,
// 			BrokerId: "NIT",
// 			System:   "NIT",
// 		}
// 		key, err := service.NewHyperSyncLogin(hypersyncereq)
// 		if err == nil {
// 			if RedirectUrl == "" || RedirectUrl == "https://www.foocut.com/trade" || RedirectUrl == "https://www.foocut.com/trade/" {
// 				err = service.Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", clientdbData.MobileNo).Updates(clientmaster.JwtAuthMaster{HyperSyncAccessToken: key}).Error
// 				if err != nil {
// 					service.Zerologs.Error().Msg("TotpAuthenticateHandler(): HyperSyncAccessToken update query failed where mobile_no:= " + clientdbData.MobileNo + err.Error())
// 					return
// 				}
// 				service.Zerologs.Info().Msg("TotpAuthenticateHandler(): USER LOGIN SUCCESSFULLY FOR MOBILE NO:=  " + clientdbData.MobileNo + " AT " + time.Now().Format("2006-01-02 15:04:05"))
// 				token["hyperSyncAccessToken"] = key // hypersync access token return
// 				c.JSON(http.StatusOK, token)
// 				return
// 			} else {
// 				err = service.Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", clientdbData.MobileNo).Updates(clientmaster.JwtAuthMaster{HyperSyncAccessToken: key}).Error
// 				if err != nil {
// 					service.Zerologs.Error().Msg("TotpAuthenticateHandler(): HyperSyncAccessToken update query failed where mobile_no:= " + clientdbData.MobileNo + err.Error())
// 					return
// 				}
// 				service.Zerologs.Info().Msg("TotpAuthenticateHandler(): USER LOGIN SUCCESSFULLY FOR MOBILE NO:=  " + clientdbData.MobileNo + " AT " + time.Now().Format("2006-01-02 15:04:05"))
// 				token["url"] = RedirectUrl
// 				token["hyperSyncAccessToken"] = key // hypersync access token return
// 				c.JSON(http.StatusOK, token)
// 				return
// 			}
// 		} else {
// 			service.Zerologs.Error().Msg("TotpAuthenticateHandler(): Hypersync login failed for :=  " + clientdbData.MobileNo + " AT " + time.Now().Format("2006-01-02 15:04:05"))
// 			if RedirectUrl == "" || RedirectUrl == "https://www.foocut.com/trade" || RedirectUrl == "https://www.foocut.com/trade/" {
// 				// err = service.Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", clientdbData.MobileNo).Updates(clientmaster.JwtAuthMaster{HyperSyncAccessToken: key}).Error
// 				// if err != nil {
// 				// 	service.Zerologs.Error().Msg("TotpAuthenticateHandler(): HyperSyncAccessToken update query failed where mobile_no:= " + clientdbData.MobileNo + err.Error())
// 				// 	return
// 				// }
// 				service.Zerologs.Info().Msg("TotpAuthenticateHandler(): USER LOGIN SUCCESSFULLY FOR MOBILE NO:=  " + clientdbData.MobileNo + " AT " + time.Now().Format("2006-01-02 15:04:05"))
// 				token["hyperSyncAccessToken"] = "" // hypersync access token return
// 				c.JSON(http.StatusOK, token)
// 				return
// 			} else {
// 				// err = service.Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", clientdbData.MobileNo).Updates(clientmaster.JwtAuthMaster{HyperSyncAccessToken: key}).Error
// 				// if err != nil {
// 				// 	service.Zerologs.Error().Msg("TotpAuthenticateHandler(): HyperSyncAccessToken update query failed where mobile_no:= " + clientdbData.MobileNo + err.Error())
// 				// 	return
// 				// }
// 				service.Zerologs.Info().Msg("TotpAuthenticateHandler(): USER LOGIN SUCCESSFULLY FOR MOBILE NO:=  " + clientdbData.MobileNo + " AT " + time.Now().Format("2006-01-02 15:04:05"))
// 				token["url"] = RedirectUrl
// 				token["hyperSyncAccessToken"] = "" // hypersync access token return
// 				c.JSON(http.StatusOK, token)
// 				return
// 			}
// 		}
// 	}

// }

// func EnableTOTP(c *gin.Context) {
// 	libhttp.CoreHeader(c)
// 	type Otpmodel struct {
// 		Otp string `json:"otp"`
// 	}
// 	mobile_no, err := service.GetUser(c)
// 	if err != nil {
// 		service.Zerologs.Error().Err(err).Msg("EnableTOTP(): Unauthorized")
// 		c.JSON(http.StatusUnauthorized, "Unauthorized")
// 		return
// 	}
// 	token := make(map[string]string)
// 	MobileNo := strconv.FormatUint(uint64(mobile_no), 10)
// 	var reqOtp Otpmodel
// 	if err := c.BindJSON(&reqOtp); err != nil {
// 		service.Zerologs.Error().Msg("EnableTOTP(): Error in c.BindJSON is " + err.Error())
// 		return
// 	}
// 	if reqOtp.Otp == "" {
// 		service.Zerologs.Info().Msg("EnableTOTP(): OTP can not be empty")
// 		token["errMsg"] = "OTP can not be empty"
// 		c.JSON(http.StatusInternalServerError, token)
// 		return
// 	}
// 	resp := service.Verify_OTP(MobileNo, reqOtp.Otp)
// 	if resp["Msg"] == "Success" {
// 		//totp generated only for first email present in jwtauthmaster table.
// 		var Tbl_MobileEmailMapping clientmaster.TblMobileEmailMapping
// 		err = service.Db.Client.Where("mobile_no=?", MobileNo).First(&Tbl_MobileEmailMapping).Error
// 		if err != nil {
// 			service.Zerologs.Error().Msg("EnableTOTP(): User data not found in clientmaster.TblMobileEmailMapping for :=  " + MobileNo + " and " + Tbl_MobileEmailMapping.Email + err.Error())
// 			c.JSON(500, err.Error())
// 			// fmt.Println(err)
// 			return
// 		}
// 		if !Tbl_MobileEmailMapping.IsTotpEnable {
// 			img64, secretKey, err := service.GenerateTotpSecret(Tbl_MobileEmailMapping.Email)
// 			if err != nil {
// 				service.Zerologs.Error().Msg("EnableTOTP(): Error found in GenerateTotpSecret for :=  " + MobileNo + " and " + Tbl_MobileEmailMapping.Email + err.Error())
// 				c.JSON(500, err.Error())
// 				// fmt.Print(err)
// 				return
// 			}
// 			c.JSON(http.StatusOK, gin.H{"img64": img64, "secretKey": secretKey})
// 			return
// 		} else {
// 			token["errMsg"] = "TOTP service already enabled"
// 			c.JSON(http.StatusInternalServerError, token)
// 			return
// 		}
// 	} else {
// 		token["errMsg"] = "Invalid OTP"
// 		c.JSON(http.StatusInternalServerError, token)
// 	}
// }
// func GenerateTOTPForMobile(c *gin.Context) {
// 	libhttp.CoreHeader(c)
// 	mobile_no, err := service.GetUser(c)
// 	if err != nil {
// 		service.Zerologs.Error().Err(err).Msg("GenerateTOTPForMobile(): Unauthorized")
// 		c.JSON(http.StatusUnauthorized, "Unauthorized")
// 		return
// 	}
// 	token := make(map[string]string)
// 	MobileNo := strconv.FormatUint(uint64(mobile_no), 10)
// 	var reqOtp model.Otpmodel
// 	if err := c.BindJSON(&reqOtp); err != nil {
// 		service.Zerologs.Error().Msg("GenerateTOTPForMobile(): Error in c.BindJSON is " + err.Error())
// 		c.JSON(http.StatusBadRequest, err)
// 		return
// 	}
// 	resp := service.Verify_OTP(MobileNo, reqOtp.Otp)
// 	if resp["Msg"] == "Success" {
// 		//totp generated only for first email present in jwtauthmaster table.
// 		var Tbl_MobileEmailMapping clientmaster.TblMobileEmailMapping
// 		err = service.Db.Client.Where("mobile_no=?", MobileNo).First(&Tbl_MobileEmailMapping).Error
// 		if err != nil {
// 			service.Zerologs.Error().Msg("GenerateTOTPForMobile(): User data not found in clientmaster.TblMobileEmailMapping for :=  " + MobileNo + " and " + Tbl_MobileEmailMapping.Email + err.Error())
// 			c.JSON(http.StatusInternalServerError, err)
// 			return
// 		}
// 		if !Tbl_MobileEmailMapping.IsTotpEnable {
// 			Reponse, err := GenerateTotpSecretForMobile(Tbl_MobileEmailMapping.Email)
// 			if err != nil {
// 				service.Zerologs.Error().Msg("GenerateTOTPForMobile(): Error found in GenerateTotpSecret for :=  " + MobileNo + " and " + Tbl_MobileEmailMapping.Email + err.Error())
// 				c.JSON(http.StatusInternalServerError, err)
// 				return
// 			}
// 			TotpData := Reponse.(model.GenerateTOTPModel)
// 			token["QRCode"] = TotpData.QRCode
// 			token["Secretkey"] = TotpData.SecretKey
// 			token["Msg"] = "Show TOTP QR Screen"
// 			c.JSON(http.StatusOK, token)
// 		} else {
// 			token["errMsg"] = "TOTP service already enabled"
// 			c.JSON(http.StatusInternalServerError, token)
// 		}
// 	} else {
// 		token["errMsg"] = "Invalid OTP"
// 		c.JSON(http.StatusInternalServerError, token)
// 	}
// }
// func GenerateTotpSecretForMobile(email string) (interface{}, error) {
// 	key, err := totp.Generate(totp.GenerateOpts{
// 		Issuer:      "nuuu.com",
// 		AccountName: email,
// 	})
// 	if err != nil {
// 		service.Zerologs.Error().Msg("GenerateTotpSecretForMobile(): Error in totp.Generate() for Email=" + email + " and error=" + err.Error())
// 		return nil, err
// 	}
// 	var buf bytes.Buffer
// 	img, err := key.Image(200, 200)
// 	if err != nil {
// 		service.Zerologs.Error().Msg("GenerateTotpSecretForMobile(): Error in key.Image() for Email=" + email + " and error=" + err.Error())
// 		return nil, err
// 	}
// 	png.Encode(&buf, img)
// 	secretKey := key.Secret()
// 	imgBase64Str := base64.StdEncoding.EncodeToString(buf.Bytes())
// 	var TOTPModel model.GenerateTOTPModel
// 	TOTPModel.QRCode = imgBase64Str
// 	TOTPModel.SecretKey = secretKey
// 	err = service.Db.Client.Model(&clientmaster.TblMobileEmailMapping{}).Where("email=?", email).Update("totp_secret_key", secretKey).Error
// 	if err != nil {
// 		service.Zerologs.Error().Msg("GenerateTotpSecretForMobile(): secret key update query failed where email:=  " + email + err.Error())
// 		return nil, err
// 	}
// 	return TOTPModel, nil
// }
// func TotpAuthenticateForMobile(c *gin.Context) {
// 	libhttp.CoreHeader(c)
// 	mobile_no, err := service.GetUser(c)
// 	if err != nil {
// 		service.Zerologs.Error().Err(err).Msg("TotpAuthenticateForMobile(): Unauthorized")
// 		c.JSON(http.StatusUnauthorized, "Unauthorized")
// 		return
// 	}
// 	MobileNo := strconv.FormatUint(uint64(mobile_no), 10)
// 	var objTotp model.TotpAuthModel
// 	err = c.BindJSON(&objTotp)
// 	if err != nil {
// 		service.Zerologs.Error().Msg("TotpAuthenticateForMobile(): Error in BindJSON() objTotp: " + err.Error())
// 		c.JSON(http.StatusBadRequest, err)
// 		return
// 	}
// 	token := make(map[string]string)
// 	var clientData clientmaster.TblMobileEmailMapping
// 	err = service.Db.Client.Where("mobile_no=?", MobileNo).First(&clientData).Error
// 	if err != nil {
// 		service.Zerologs.Error().Msg("TotpAuthenticateForMobile(): User data not found in TblMobileEmailMapping for mobileno=" + MobileNo + " and error is " + err.Error())
// 		c.JSON(http.StatusInternalServerError, "data not found in db")
// 		return
// 	}
// 	otpc := dgoogauth.OTPConfig{
// 		Secret:      clientData.TotpSecretKey,
// 		WindowSize:  3,
// 		HotpCounter: 0,
// 		// UTC:         true,
// 	}
// 	val, err := otpc.Authenticate(objTotp.TOTP)
// 	if err != nil {
// 		service.Zerologs.Error().Msg("TotpAuthenticateForMobile(): Error in otpc.Authenticate() is " + err.Error())
// 		c.JSON(http.StatusInternalServerError, err)
// 		return
// 	}
// 	if !val {
// 		service.Zerologs.Info().Msg("TotpAuthenticateForMobile(): User " + MobileNo + " enter wrong TOTP ")
// 		token["errMsg"] = " UnAuthenticated, please enter correct TOTP "
// 		c.JSON(http.StatusUnauthorized, token)
// 	} else {
// 		var clientdbData clientmaster.JwtAuthMaster
// 		err = service.Db.Client.Where("mobile_no=?", MobileNo).First(&clientdbData).Error
// 		if err != nil {
// 			service.Zerologs.Error().Msg("TotpAuthenticateForMobile(): User data not found in JwtAuthMaster where mobileNo=  " + MobileNo + err.Error())
// 			c.JSON(http.StatusInternalServerError, "clientdbData not found")
// 			return
// 		}
// 		if clientdbData.Password == objTotp.Password {
// 			err = service.Db.Client.Where("mobile_no=? AND email=?", MobileNo, clientData.Email).Updates(clientmaster.TblMobileEmailMapping{IsTotpEnable: true, TotpStatus: true}).Error
// 			if err != nil {
// 				service.Zerologs.Error().Msg("TotpAuthenticateForMobile(): IsTotpEnable update query failed where MobileNo:=  " + MobileNo + " and email " + clientData.Email + err.Error())
// 				c.JSON(http.StatusInternalServerError, err)
// 				return
// 			}
// 			token["Msg"] = "TOTP successfully enabled"
// 			c.JSON(http.StatusOK, token)
// 		} else {
// 			service.Zerologs.Info().Msg("TotpAuthenticateForMobile():User " + MobileNo + " enter wrong password ")
// 			token["errMsg"] = " Wrong password"
// 			c.JSON(http.StatusInternalServerError, token)
// 		}
// 	}
// }
// func DisableTOTPForMobile(c *gin.Context) {
// 	libhttp.CoreHeader(c)
// 	mobile_no, err := service.GetUser(c)
// 	if err != nil {
// 		service.Zerologs.Error().Err(err).Msg("DisableTOTPForMobile(): Unauthorized")
// 		c.JSON(http.StatusUnauthorized, "Unauthorized")
// 		return
// 	}
// 	MobileNo := strconv.FormatUint(uint64(mobile_no), 10)
// 	var VerifyModel model.OtpVerifyModel
// 	if err := c.BindJSON(&VerifyModel); err != nil {
// 		service.Zerologs.Error().Err(err).Msg("DisableTOTPForMobile(): error BindJSON " + err.Error())
// 		c.JSON(http.StatusBadRequest, err)
// 		return
// 	}
// 	VerifyModel.MobileNo = MobileNo
// 	token := make(map[string]string)
// 	rotp, err := service.RedisLib.Client.Get(VerifyModel.MobileNo).Result()
// 	if err != nil {
// 		service.Zerologs.Error().Err(err).Msg("DisableTOTPForMobile(): Error in getting otp for mobileNo=" + MobileNo + " and error is " + err.Error())
// 		c.JSON(http.StatusInternalServerError, err)
// 		return
// 	}
// 	var userdata clientmaster.TblMobileOtp
// 	err = service.Db.Client.Where("mobile_no=?", VerifyModel.MobileNo).First(&userdata).Error
// 	if err != nil {
// 		service.Zerologs.Error().Msg("DisableTOTPForMobile(): User " + VerifyModel.MobileNo + " Not found in  clientmaster.TblMobileOtp")
// 		c.JSON(http.StatusInternalServerError, err)
// 		return
// 	}
// 	if VerifyModel.Otp != rotp {
// 		if userdata.OtpAttempt >= service.Env.MAX_OTP_ATTEMPT {
// 			service.Zerologs.Error().Msg("DisableTOTPForMobile(): user " + VerifyModel.MobileNo + " is blocked for 15 minutes ")
// 			token["errMsg"] = "User is blocked, please try again after 15 minutes"
// 			c.JSON(http.StatusInternalServerError, token)
// 			return
// 		}
// 		service.Zerologs.Error().Msg("DisableTOTPForMobile(): User " + VerifyModel.MobileNo + " enter invalid OTP ")
// 		attempt := (userdata.OtpAttempt) + 1
// 		err := service.Db.Client.Model(clientmaster.TblMobileOtp{}).Where("mobile_no=?", VerifyModel.MobileNo).Updates(clientmaster.TblMobileOtp{OtpAttempt: attempt, OtpBlockTime: time.Now()}).Error
// 		if err != nil {
// 			service.Zerologs.Error().Msg("DisableTOTPForMobile(): Error in update OtpAttempt in TblMobileOtp for mobileNo=" + MobileNo + " and error=" + err.Error())
// 			c.JSON(http.StatusInternalServerError, err)
// 			return
// 		}
// 		remainingcount := service.Env.MAX_OTP_ATTEMPT - attempt
// 		if remainingcount == 0 {
// 			token["errMsg"] = "User is blocked for 15 minutes"
// 		} else {
// 			token["errMsg"] = "Invalid OTP. " + strconv.Itoa(remainingcount) + " attempts remaining "
// 		}
// 		c.JSON(http.StatusInternalServerError, token)
// 		return
// 	}
// 	if userdata.OtpAttempt >= 3 {
// 		service.Zerologs.Error().Msg(" user " + VerifyModel.MobileNo + " is blocked for 15 minutes ")
// 		token["errMsg"] = "User is blocked for 15 minutes"
// 		c.JSON(http.StatusInternalServerError, token)
// 	} else {
// 		err := service.Db.Client.Model(clientmaster.TblMobileOtp{}).Where("mobile_no=?", VerifyModel.MobileNo).Update("otp_attempt", 0).Error
// 		if err != nil {
// 			service.Zerologs.Error().Msg("DisableTOTPForMobile(): Error in update OtpAttempt to 0 in TblMobileOtp for mobileNo=" + MobileNo + " and error=" + err.Error())
// 			c.JSON(http.StatusInternalServerError, token)
// 			return
// 		}
// 		var ClientData clientmaster.JwtAuthMaster
// 		err = service.Db.Client.Where("mobile_no=?", MobileNo).First(&ClientData).Error
// 		if err != nil {
// 			service.Zerologs.Error().Msg("DisableTOTPForMobile(): User data not found in JwtAuthMaster where mobileNo=  " + MobileNo + err.Error())
// 			c.JSON(http.StatusInternalServerError, "clientdbData not found")
// 			return
// 		}
// 		UpdateTotpData := make(map[string]interface{})
// 		UpdateTotpData["is_totp_enable"] = false
// 		UpdateTotpData["totp_status"] = false
// 		err = service.Db.Client.Model(clientmaster.TblMobileEmailMapping{}).Where("mobile_no=? AND email=?", MobileNo, ClientData.Email).Updates(UpdateTotpData).Error
// 		if err != nil {
// 			service.Zerologs.Error().Msg("DisableTOTPForMobile(): Error in update TotpStatus and IsTotpEnable to false in TblMobileEmailMapping for mobileNo=" + MobileNo + " and error=" + err.Error())
// 			c.JSON(http.StatusInternalServerError, token)
// 			return
// 		}
// 		token["Msg"] = "TOTP disabled successfully"
// 		c.JSON(http.StatusOK, token)
// 	}
// }
// func TotpAuthenticateHandlerForMobile(c *gin.Context) {
// 	libhttp.CoreHeader(c)
// 	mobile_no, err := service.GetUser(c)
// 	if err != nil {
// 		service.Zerologs.Error().Err(err).Msg("TotpAuthenticateHandlerForMobile(): Unauthorized")
// 		c.JSON(http.StatusUnauthorized, "Unauthorized")
// 		return
// 	}
// 	MobileNo := strconv.FormatUint(uint64(mobile_no), 10)
// 	var clientdbData clientmaster.JwtAuthMaster
// 	err = service.Db.Client.Where("mobile_no=?", MobileNo).First(&clientdbData).Error
// 	if err != nil {
// 		service.Zerologs.Error().Msg("TotpAuthenticateHandlerForMobile(): User not found in clientmaster.JwtAuthMaster where MobileNo=  " + MobileNo + err.Error())
// 		c.JSON(http.StatusInternalServerError, "clientdbData not found")
// 		return
// 	}
// 	var objTotp model.TotpAuthModel
// 	err = c.BindJSON(&objTotp)
// 	if err != nil {
// 		service.Zerologs.Error().Msg("TotpAuthenticateHandlerForMobile(): Error in BindJSON() objTotp: " + err.Error())
// 		c.JSON(http.StatusBadRequest, err)
// 		return
// 	}
// 	token := make(map[string]string)
// 	var clientData clientmaster.TblMobileEmailMapping
// 	err = service.Db.Client.Where("mobile_no=?", clientdbData.MobileNo).First(&clientData).Error
// 	if err != nil {
// 		service.Zerologs.Error().Msg("TotpAuthenticateHandlerForMobile(): User data not found in TblMobileEmailMapping for mobileno=" + clientdbData.MobileNo + " and error is " + err.Error())
// 		c.JSON(http.StatusInternalServerError, "data not found in db")
// 		return
// 	}
// 	otpc := &dgoogauth.OTPConfig{
// 		Secret:      clientData.TotpSecretKey,
// 		WindowSize:  3,
// 		HotpCounter: 0,
// 		// UTC:         true,
// 	}
// 	val, err := otpc.Authenticate(objTotp.TOTP)
// 	if err != nil {
// 		service.Zerologs.Error().Msg("TotpAuthenticateHandlerForMobile(): Error in otpc.Authenticate() is " + err.Error())
// 		c.JSON(http.StatusInternalServerError, err)
// 		return
// 	}
// 	if !val {
// 		service.Zerologs.Info().Msg("TotpAuthenticateHandlerForMobile(): User " + clientdbData.MobileNo + " enter wrong TOTP ")
// 		token["errMsg"] = " UnAuthenticated, please enter correct TOTP "
// 		c.JSON(http.StatusUnauthorized, token)
// 		return
// 	} else {
// 		sAccountcode := clientdbData.ClientID + "-" + "NIT" //service.Env.BROKERID
// 		token, err = service.GenerateJWTWithRefresh(clientdbData.MobileNo, clientdbData.Email, sAccountcode)
// 		if err != nil {
// 			service.Zerologs.Error().Msg("TotpAuthenticateHandlerForMobile(): Error in service.GenerateJWTWithRefresh for mobileno=" + clientdbData.MobileNo + " and email=" + clientdbData.Email + " is " + err.Error())
// 			c.JSON(http.StatusInternalServerError, err)
// 			return
// 		}
// 		var greenWareReq model.GreenwareRequestModel
// 		greenWareReq.SsoBy = "mobile+user_type"
// 		greenWareReq.Param1 = clientdbData.MobileNo
// 		greenWareReq.Param2 = 1
// 		// mfaccesstoken := GreenWareLogin(greenWareReq)
// 		// token["mftoken"] = mfaccesstoken
// 		hypersyncereq := model.HypersyncModel{
// 			Uid:      clientdbData.ClientID + "_" + "NIT", // + "-" + mpinmodel.BrokerID,
// 			BrokerId: "NIT",
// 			System:   "NIT",
// 		}
// 		key, err := service.NewHyperSyncLogin(hypersyncereq)
// 		service.Zerologs.Info().Msg("TotpAuthenticateHandlerForMobile(): HyperSyncAccessToken for mobileNo:=" + clientdbData.MobileNo + " hypersyncToken " + key)
// 		if err == nil {
// 			token["hyperSyncAccessToken"] = key // hypersync access token return
// 			err = service.Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", clientdbData.MobileNo).Updates(clientmaster.JwtAuthMaster{HyperSyncAccessToken: key}).Error
// 			if err != nil {
// 				service.Zerologs.Error().Msg("AddMPIN(): HyperSyncAccessToken update query failed where mobile_no:= " + clientdbData.MobileNo + err.Error())
// 				c.JSON(http.StatusInternalServerError, err)
// 				return
// 			}
// 			service.Zerologs.Info().Msg(" MOBILE NO: " + clientdbData.MobileNo + "Is login successfully at :=  " + time.Now().Format("2006-01-02 15:04:05"))
// 			token["isKyc"] = "true"
// 			token["isActivated"] = "true"
// 			// token["refresh_token"] = clientdbData.Refreshtoken
// 			token["Msg"] = "login successfully"
// 			c.JSON(http.StatusOK, token)
// 		} else {
// 			service.Zerologs.Info().Msg(" MOBILE NO: " + clientdbData.MobileNo + "Is login successfully at :=  " + time.Now().Format("2006-01-02 15:04:05"))
// 			token["isKyc"] = "true"
// 			token["isMpinSet"] = "true"
// 			token["hyperSyncAccessToken"] = ""
// 			token["hyperSyncLogin"] = "Error"
// 			token["isActivated"] = "true"
// 			// token["refresh_token"] = clientdbData.Refreshtoken
// 			c.JSON(http.StatusOK, token)
// 		}
// 	}
// }
