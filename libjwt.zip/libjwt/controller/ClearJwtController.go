package controller

import (
	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/gin"
)

func ClearJwt(c *gin.Context) {
	libhttp.CoreHeader(c)
	MobileNo := c.Query("mobileno")

	service.ClearJwtService(MobileNo)
}
