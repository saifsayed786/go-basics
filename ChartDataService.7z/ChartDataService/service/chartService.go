package service

import (
	"bytes"
	"chartdataservice/models"
	"encoding/json"
	"fmt"
	"github.com/TecXLab/liblogs"
	"io/ioutil"
	"os"
	"strconv"
	"time"
)

type ChartService interface {
	GetChartId(clientid string, userid string) []models.ChartRequestModel
	SaveChart(cchartId string, userId string, savemodel models.ChartIDWiseModel) interface{}
	LoadChart(userid string, chartId string) interface{}
	DeleteChart(chartid string, userid string) (interface{}, error)
}

type chartService struct {
}

func NewChartService() ChartService {
	return &chartService{}
}

// GetCharts implements ChartService
func (*chartService) GetChartId(clientid string, userid string) []models.ChartRequestModel {
	previouspath := os.Getenv("FILE_USERDATA_PATH")

	if _, err := os.Stat(previouspath + "tradingview/" + userid); os.IsNotExist(err) {
		Logger("File does not exist for MobileNumber : "+userid, nil, liblogs.Info, liblogs.ZEROLOG)
		return nil
	}
	zerologs.Info().Msg("In FilePath : " + previouspath)
	jsonFile, err := os.Open(previouspath + "tradingview/" + userid + "/summary.txt")
	if err != nil {
		Logger("In GetChartId : "+userid, err, liblogs.Error, liblogs.ZEROLOG)

		return nil
	}

	defer jsonFile.Close()
	byteValue, _ := ioutil.ReadAll(jsonFile)

	var Arrchart []models.ChartRequestModel

	err = json.Unmarshal(byteValue, &Arrchart)
	if err != nil {
		Logger("In GetChartId : ", err, liblogs.Error, liblogs.ZEROLOG)

		return nil
	}

	return Arrchart
}

// DeleteChart implements ChartService
func (*chartService) DeleteChart(chartid string, userid string) (interface{}, error) {
	//	url := "?client=client_id&user=user_id"
	var chart []models.DeleteChartModel
	// resp, err := http.Get(url)
	// if err != nil {
	// 	zerologs.Error().Err(err).Msg("Error while fetch chart")
	// }
	// defer resp.Body.Close()
	// body, err := io.ReadAll(resp.Body)
	path := os.Getenv("FILE_USERDATA_PATH")

	data, err := ioutil.ReadFile(path + userid + "/summary.txt")
	if err != nil {
		Logger("Message: ", err, liblogs.Error, liblogs.PRINT)

		return nil, err
	}

	err = json.Unmarshal(data, &chart)

	if err != nil {
		fmt.Println(err)
		return nil, err
	}

	blank := []models.DeleteChartModel{}
	for _, v := range chart {
		id, _ := strconv.Atoi(chartid)
		if id == v.Id {
			continue
		}
		blank = append(blank, v)
	}

	reqBodyBytes := new(bytes.Buffer)
	json.NewEncoder(reqBodyBytes).Encode(blank)
	filedata := reqBodyBytes.Bytes() // this is the []byte

	err = os.WriteFile(path+userid+"/summary.txt", filedata, 0644)
	if err != nil {
		Logger("Message: ", err, liblogs.Error, liblogs.PRINT)

		return nil, err
	}

	e := os.Remove(path + userid + "/" + chartid + ".txt")
	if e != nil {
		Logger("Message: ", e, liblogs.Error, liblogs.PRINT)

		return nil, e
	}
	// fmt.Println(body)
	return "Successfully Deleted", nil
}

// LoadChart implements ChartService
func (*chartService) LoadChart(userid string, chart string) interface{} {
	previouspath := os.Getenv("FILE_USERDATA_PATH")

	zerologs.Info().Msg(previouspath)
	if _, err := os.Stat(previouspath + "tradingview/" + userid); os.IsNotExist(err) {
		Logger("File does not exist for MobileNumber : "+userid, nil, liblogs.Info, liblogs.ZEROLOG)

		return nil
	}

	if _, err := os.Stat(previouspath + "tradingview/" + userid + "/" + chart + ".txt"); os.IsNotExist(err) {
		Logger("In LoadChart : ", err, liblogs.Error, liblogs.ZEROLOG)

		return nil
	}
	jsonFile, err := os.Open(previouspath + "tradingview/" + userid + "/" + chart + ".txt")
	if err != nil {
		Logger("In LoadChart : ", err, liblogs.Error, liblogs.ZEROLOG)

		return nil
	}

	defer jsonFile.Close()
	byteValue, _ := ioutil.ReadAll(jsonFile)

	jsonFile, err = os.Open(previouspath + "tradingview/" + userid + "/" + "summary.txt")
	if err != nil {
		Logger("In LoadChart : ", err, liblogs.Error, liblogs.ZEROLOG)

		return nil
	}
	var ChartResponse models.ChartIDWiseModel
	var Arrchart []models.ChartRequestModel

	json.Unmarshal(byteValue, &Arrchart)
	result := string(byteValue)

	ChartResponse.Content = result

	defer jsonFile.Close()
	byteValue, _ = ioutil.ReadAll(jsonFile)

	json.Unmarshal(byteValue, &Arrchart)

	for i := 0; i < len(Arrchart); i++ {
		if string(Arrchart[i].Id) == chart {
			ChartResponse.Name = Arrchart[i].Name
			ChartResponse.Resolution = Arrchart[i].Resolution
			ChartResponse.Symbol = Arrchart[i].Symbol
		}
	}
	return ChartResponse
}

// SaveChart implements ChartService
func (*chartService) SaveChart(chartId string, userId string, savemodel models.ChartIDWiseModel) interface{} {
	previouspath := os.Getenv("FILE_USERDATA_PATH")

	if savemodel.Name == "" || savemodel.Content == "" {
		Logger("Some data is missing", nil, liblogs.Info, liblogs.ZEROLOG)

		return nil
	}

	if _, err := os.Stat(previouspath + "tradingview/" + userId); os.IsNotExist(err) {
		err = os.Mkdir(previouspath+"tradingview/"+userId, 0777)
		if err != nil {
			Logger("Something went wrong", err, liblogs.Error, liblogs.ZEROLOG)

		} else {
			Logger("File folder created for userid : "+userId+" Previouspath : "+previouspath+"tradingview/"+userId, nil, liblogs.Info, liblogs.ZEROLOG)

		}
		// return nil
	}

	var arrChart []models.ChartRequestModel

	var summaryModel models.ChartRequestModel
	summaryModel.Id = fmt.Sprint(time.Now().Unix())
	summaryModel.Name = savemodel.Name
	summaryModel.Resolution = savemodel.Resolution
	summaryModel.Timestamp = uint64(time.Now().Unix())
	summaryModel.Symbol = savemodel.Symbol

	arrChart = append(arrChart, summaryModel)
	dataBytes, err := json.Marshal(arrChart)
	if err != nil {
		Logger("In SaveChart : ", err, liblogs.Error, liblogs.ZEROLOG)

		return nil
	}

	if _, err := os.Stat(previouspath + "tradingview//" + userId + "//" + "summary.txt"); os.IsNotExist(err) {
		err := os.WriteFile(previouspath+"tradingview//"+userId+"//"+"summary.txt", dataBytes, 0777)
		if err != nil {
		Logger("In SaveChart : ", err, liblogs.Error, liblogs.ZEROLOG)

			return nil
		}
	} else {
		jsonFile, err := os.Open(previouspath + "tradingview//" + userId + "//" + "summary.txt")
		if err != nil {
			Logger("In SaveChart : ", err, liblogs.Error, liblogs.ZEROLOG)
			return nil
		}

		defer jsonFile.Close()
		byteValue, _ := ioutil.ReadAll(jsonFile)

		var Arrchart []models.ChartRequestModel

		err = json.Unmarshal(byteValue, &Arrchart)
		Arrchart = append(Arrchart, summaryModel)

		dataBytes, err := json.Marshal(Arrchart)
		if err != nil {
			zerologs.Err(err).Msg("In SaveChart : ")
			return nil
		}
		err = ioutil.WriteFile(previouspath+"tradingview//"+userId+"//"+"summary.txt", dataBytes, 0777)
		if err != nil {
			Logger("In SaveChart : ", err, liblogs.Error, liblogs.ZEROLOG)

			return nil
		}

	}

	dataBytes, err = json.Marshal(savemodel.Content)
	if err != nil {

		Logger("In SaveChart : ", err, liblogs.Error, liblogs.ZEROLOG)

		return nil
	}

	err = ioutil.WriteFile(previouspath+"tradingview//"+userId+"//"+string(summaryModel.Id)+".txt", dataBytes, 0777)
	if err != nil {
		Logger("In SaveChart : ", err, liblogs.Error, liblogs.ZEROLOG)

		return nil
	}

	return summaryModel.Id
}
