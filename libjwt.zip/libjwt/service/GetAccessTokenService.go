package service

import (
	"errors"
	"fmt"
	"strconv"

	"github.com/MACMREPO/libjwt/helper"
	"github.com/gin-gonic/gin"
)

func GetAccessTokenService(c *gin.Context, refreshToken string) (map[string]string, error) {
	token := make(map[string]string)
	fmt.Println("GetAccessToken(): refresh_token=" + refreshToken)
	// var userData clientmaster.JwtAuthMaster
	// err := Db.Client.Where("refreshtoken=?", refreshToken).First(&userData).Error
	// if err != nil {
	// 	Zerologs.Error().Msg("GetAccessToken(): Error while fetching data from database using refreshtoken:" + refreshToken + err.Error())
	// 	c.JSON(http.StatusInternalServerError, "refresh_token not found")
	// } else {
	// 	token, err := GenerateJWTWithRefresh(userData.MobileNo, userData.Email)
	// 	if err != nil {
	// 		Zerologs.Error().Msg("GetAccessToken(): Error in GenerateJWTWithRefresh for mobileno=" + userData.MobileNo + " and email=" + userData.Email + " is " + err.Error())
	// 		c.JSON(http.StatusInternalServerError, "")
	// 		return
	// 	}

	// 	token["isKyc"] = strconv.FormatBool(userData.KYCDone)
	// 	token["isMpinSet"] = strconv.FormatBool(userData.IsMPIN_Reset)
	// 	token["isActivated"] = strconv.FormatBool(userData.Activated)
	// 	c.JSON(http.StatusOK, token)
	// }
	response, err := ValidateRefreshToken(refreshToken)
	if err != nil {
		Zerologs.Error().Err(err).Msg("GetAccessToken(): Error in ValidateRefreshToken for refreshToken=" + refreshToken)
		// fmt.Println("GetAccessToken(): Error in ValidateRefreshToken for refreshToken=" + refreshToken)
		return nil, err
	}
	// fmt.Println("GetAccessToken(): ValidateRefreshToken access_token=" + response)
	c.Request.Header.Set("Authorization", "Bearer "+response)
	MobileNo, err := GetUser(c)
	if err != nil {
		Zerologs.Error().Err(err).Msg("GetAccessToken(): Error in GetUser")
		fmt.Println("GetAccessToken(): Error in GetUser is " + err.Error())
		return nil, errors.New("Unauthorized")
	}
	mobileno := strconv.FormatUint(uint64(MobileNo), 10)
	// fmt.Println("GetAccessToken(): mobileno=" + mobileno)
	// var userData clientmaster.JwtAuthMaster
	// err = Db.Client.Where("mobile_no=?", mobileno).First(&userData).Error
	userData, err := getJwtAuthMasterDB(helper.CLIENT_MOBILE_PARAM, mobileno)
	if err != nil {
		Zerologs.Error().Msg("GetAccessToken(): User data not found for mobileno=" + mobileno + " and error is " + err.Error())
		return nil, err
	}
	// fmt.Println("GetAccessToken(): DB userData=", userData)
	token["isKyc"] = strconv.FormatBool(userData.KYCDone)
	token["isMpinSet"] = strconv.FormatBool(userData.IsMPIN_Reset)
	token["isActivated"] = strconv.FormatBool(userData.Activated)
	token["access_token"] = response
	token["refresh_token"] = refreshToken
	token["url"] = Env.GOOGLE_MAIN_PAGE
	return token, nil
}

func GetAccessTokenOnRefreshTokenService(c *gin.Context, refreshToken string) (map[string]string, error) {
	token := make(map[string]string)
	response, err := ValidateRefreshTokenForAccessToken(refreshToken)
	if err != nil {
		Zerologs.Error().Err(err).Msg("GetAccessToken(): Error in ValidateRefreshToken for refreshToken=" + refreshToken)
		// fmt.Println("GetAccessToken(): Error in ValidateRefreshToken for refreshToken=" + refreshToken)
		// fmt.Println("GetAccessToken(): Error in ValidateRefreshToken for refreshToken=" + refreshToken)
		return nil, errors.New("Unauthorized")
	}
	// fmt.Println("GetAccessToken(): ValidateRefreshToken access_token=" + response)
	c.Request.Header.Set("Authorization", "Bearer "+response)
	MobileNo, err := GetUser(c)
	if err != nil {
		Zerologs.Error().Err(err).Msg("GetAccessToken(): Error in GetUser")
		// fmt.Println("GetAccessToken(): Error in GetUser is " + err.Error())
		return nil, errors.New("Unauthorized")
	}
	mobileno := strconv.FormatUint(uint64(MobileNo), 10)
	// fmt.Println("GetAccessToken(): mobileno=" + mobileno)
	// var userData clientmaster.JwtAuthMaster
	// err = Db.Client.Where("mobile_no=?", mobileno).First(&userData).Error
	userData, err := getJwtAuthMasterDB(helper.CLIENT_MOBILE_PARAM, mobileno)
	if err != nil {
		Zerologs.Error().Msg("GetAccessToken(): User data not found for mobileno=" + mobileno + " and error is " + err.Error())
		return nil, err
	}
	// fmt.Println("GetAccessToken(): DB userData=", userData)
	token["isKyc"] = strconv.FormatBool(userData.KYCDone)
	token["isMpinSet"] = strconv.FormatBool(userData.IsMPIN_Reset)
	token["isActivated"] = strconv.FormatBool(userData.Activated)
	token["access_token"] = response
	token["refresh_token"] = refreshToken
	token["url"] = Env.GOOGLE_MAIN_PAGE
	return token, nil
}
