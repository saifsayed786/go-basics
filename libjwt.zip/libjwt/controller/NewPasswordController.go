package controller

import (
	"net/http"

	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/model"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/contrib/sessions"
	"github.com/gin-gonic/gin"
)

func NewPassword(c *gin.Context) {
	libhttp.CoreHeader(c)
	session := sessions.Default(c)
	retrievedState := session.Get("state")
	if retrievedState == nil {
		service.Zerologs.Info().Msg("NewPassword(): RetriveState is Nil")
		return
	}
	cquery := c.Query("state")
	if retrievedState != cquery {
		//Pending
		//c.AbortWithError(http.StatusUnauthorized, fmt.Errorf("Invalid session state: %s", retrievedState))
		//return
	}
	var newpassword model.NewPassword
	if err := c.BindJSON(&newpassword); err != nil {
		service.Zerologs.Error().Msg("NewPassword(): Error while json binding model= " + newpassword.OldPassword + newpassword.NewPassword + newpassword.Pwd + err.Error())
		c.JSON(http.StatusBadRequest, "")
		return
	}
	RetrievedState := retrievedState.(string)
	response := service.NewPasswordWeb(RetrievedState, newpassword)

	c.JSON(200, response.StatusCode)

}
