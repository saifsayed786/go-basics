package service

import (
	"os"
	"strings"

	"github.com/MACMREPO/libjwt/helper"
	"github.com/gin-gonic/contrib/sessions"
)

var (
	Store sessions.Store
)

func InitLoginPage() error {
	Store = sessions.NewCookieStore([]byte(Env.JWT_SECRET))
	maintemplate, err := os.ReadFile(Env.GOOGLE_LOGIN_PAGE)
	if err != nil {
		Zerologs.Error().Msg("InitLoginPage(): Error in ReadFile for maintemplate is " + err.Error())
		return err
	}
	stemplate := string(maintemplate)
	index := strings.Index(stemplate, "<GloginURL>")
	helper.Lefttemplate = stemplate[0:index]
	helper.Righttemplate = stemplate[index:]
	helper.Righttemplate = strings.Replace(helper.Righttemplate, "<GloginURL>", "", 1)
	//Righttemplate = strings.Replace(Righttemplate, "<RegisterURL>", "", 1)
	//Righttemplate = strings.Replace(Righttemplate, "<UnblockuserURL>", "", 1)
	//Righttemplate = strings.Replace(Righttemplate, "<ForgotpasswordURL>", "", 1)
	mobiletemplate, err := os.ReadFile(Env.GOOGLE_MOBILE_PAGE)
	if err != nil {
		Zerologs.Error().Msg("InitLoginPage(): Error in ReadFile for mobiletemplate is " + err.Error())
		return err
	}
	helper.Mobiletemplate = mobiletemplate
	// mobiletemp := string(Mobiletemplate[:])
	// fmt.Println("Mobiletemplate : " + mobiletemp)
	redirecttemplate, err := os.ReadFile(Env.GOOGLE_REDIRECT_PAGE)
	if err != nil {
		Zerologs.Error().Msg("InitLoginPage(): Error in ReadFile for redirecttemplate is " + err.Error())
		return err
	}
	helper.Redirecttemplate = redirecttemplate
	mpintemplate, err := os.ReadFile(Env.GOOGLE_MPIN_PAGE)
	if err != nil {
		Zerologs.Error().Msg("InitLoginPage(): Error in ReadFile for mpintemplate is " + err.Error())
		return err
	}
	helper.Mpintemplate = mpintemplate
	setmpintemplate, err := os.ReadFile(Env.GOOGLE_SETMPIN_PAGE)
	if err != nil {
		Zerologs.Error().Msg("InitLoginPage(): Error in ReadFile for setmpintemplate is " + err.Error())
		return err
	}
	helper.SetMpintemplate = setmpintemplate
	registerTemplate, err := os.ReadFile(Env.GOOGLE_REGISTER_PAGE)
	if err != nil {
		Zerologs.Error().Msg("InitLoginPage(): Error in ReadFile for registerTemplate is " + err.Error())
		return err
	}
	helper.RegisterTemplate = registerTemplate
	//fmt.Println("RegisterTemplate read")
	forgetPassTemplate, err := os.ReadFile(Env.GOOGLE_FORGOT_PAGE)
	if err != nil {
		Zerologs.Error().Msg("InitLoginPage(): Error in ReadFile for forgetPassTemplate is " + err.Error())
		return err
	}
	helper.ForgetPassTemplate = forgetPassTemplate
	//fmt.Println("ForgetPassTemplate read")
	setPassTemplate, err := os.ReadFile(Env.GOOGLE_SETPASSWORD_PAGE)
	if err != nil {
		Zerologs.Error().Msg("InitLoginPage(): Error in ReadFile for setPassTemplate is " + err.Error())
		return err
	}
	helper.SetPasswordTemplate = setPassTemplate
	unblockUsrTemplate, err := os.ReadFile(Env.GOOGLE_UNBLOCK_PAGE)
	if err != nil {
		Zerologs.Error().Msg("InitLoginPage(): Error in ReadFile for unblockUsrTemplate is " + err.Error())
		return err
	}
	helper.UnblockUsrTemplate = unblockUsrTemplate

	// setMpinTemplate, err := os.ReadFile(Env.GOOGLE_SETMPIN_PAGE)
	// if err != nil {
	// 	fmt.Println(err)
	// 	return err
	// }
	// SetMpinTemplate = setMpinTemplate

	tOTPTemplate, err := os.ReadFile("totp.html")
	if err != nil {
		Zerologs.Error().Msg("InitLoginPage(): Error in ReadFile for tOTPTemplate is " + err.Error())
		return err
	}
	helper.TOTPTemplate = string(tOTPTemplate)
	totptemplate, err := os.ReadFile(Env.GOOGLE_TOTP_PAGE)
	if err != nil {
		Zerologs.Error().Msg("InitLoginPage(): Error in ReadFile for totptemplate is " + err.Error())
		return err
	}
	helper.TOTP_Template = totptemplate

	forgotmpintemp, err := os.ReadFile(Env.GOOGLE_FORGOTMPIN_PAGE)
	if err != nil {
		Zerologs.Error().Msg("InitLoginPage(): Error in ReadFile for totptemplate is " + err.Error())
		return err
	}
	helper.ForgotMpinTemplate = forgotmpintemp

	blockUserTemp, err := os.ReadFile(Env.BLOCK_USER_PAGE)
	if err != nil {
		Zerologs.Error().Msg("InitLoginPage(): Error in ReadFile for blockUserTemp  " + err.Error())
		return err
	}
	helper.BlockUsertemplate = blockUserTemp

	return nil
}
