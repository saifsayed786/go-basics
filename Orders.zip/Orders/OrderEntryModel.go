package model

type OrderEntryModel struct {
	ExchClientID      string `json:"exch_client_id,omitempty"`
	Quantity          string `json:"quantity,omitempty"`
	Triggerprice      string `json:"triggerprice,omitempty"`
	Securityid        string `json:"securityid,omitempty"`
	Source            string `json:"source,omitempty"`
	ClientID          string `json:"client_id,omitempty"`
	Productlist       string `json:"productlist,omitempty"`
	Buysell           string `json:"buysell,omitempty"`
	InstType          string `json:"inst_type,omitempty"`
	UserType          string `json:"user_type,omitempty"`
	OrderType         string `json:"OrderType,omitempty"`
	TokenID           string `json:"token_id,omitempty"`
	UserID            string `json:"user_id,omitempty"`
	Quantitytype      string `json:"quantitytype,omitempty"`
	Disclosequantity  string `json:"Disclosequantity,omitempty"`
	ProductList       string `json:"ProductList,omitempty"`
	Price             string `json:"price,omitempty"`
	Exchange          string `json:"exchange,omitempty"`
	OfflineFlag       string `json:"offline_flag,omitempty"`
	MarketProflag     string `json:"marketProflag,omitempty"`
	MarketProVal      string `json:"marketProVal,omitempty"`
	ParticipantType   string `json:"ParticipantType,omitempty"`
	Settlor           string `json:"settlor,omitempty"`
	Gtcflag           string `json:"Gtcflag,omitempty"`
	EncashFlag        string `json:"EncashFlag,omitempty"`
	PanID             string `json:"pan_id,omitempty"`
	GTDdate           string `json:"GTDdate,omitempty"`
	OrderNumber       string `json:"order_number,omitempty"`
	OrderSerialNumber string `json:"order_serial_number,omitempty"`
	Algoid            string `json:"algoid,omitempty"`
	Remarks1          string `json:"remarks1,omitempty"`
	Remarks2          string `json:"remarks2,omitempty"`
}
