package model

import "github.com/google/uuid"

type UpdatedataModel struct {
	Guid     uuid.UUID `json:"guid"`
	Name     string    `json:"name"`
	Mobileno string    `json:"mobileno"`
}
