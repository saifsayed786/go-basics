package model

type GttCancelOrderModel struct {
	Triggerprice      string `json:"triggerprice,omitempty"`
	Source            string `json:"source,omitempty"`
	ClientType        string `json:"client_type,omitempty"`
	ClientID          string `json:"client_id,omitempty"`
	ExchSegment       string `json:"exch_segment,omitempty"`
	Productlist       string `json:"productlist,omitempty"`
	UserType          string `json:"user_type,omitempty"`
	TokenID           string `json:"token_id,omitempty"`
	OrdStatus         string `json:"ord_status,omitempty"`
	QtyRemng          int64  `json:"qty_remng,omitempty"`
	Quantity          string `json:"quantity,omitempty"`
	TradedQty         string `json:"traded_qty,omitempty"`
	Buysell           string `json:"buysell,omitempty"`
	Disclosequantity  string `json:"disclosequantity,omitempty"`
	OrderSErialNumber string `json:"order_serial_number,omitempty"`
	OfflineFlag       bool   `json:"offline_flag,omitempty"`
	OrderType         string `json:"OrderType,omitempty"`
	ExchClientID      string `json:"exch_client_id,omitempty"`
	Securityid        string `json:"securityid,omitempty"`
	Exchange          string `json:"exchange,omitempty"`
	Scripname         string `json:"scripname,omitempty"`
	UserID            string `json:"user_id,omitempty"`
	OrderNumber       string `json:"order_number,omitempty"`
	Quantitytype      string `json:"quantitytype,omitempty"`
	Price             string `json:"price,omitempty"`
	MarketProflag     string `json:"marketProflag,omitempty"`
	MarketProVal      string `json:"marketProVal,omitempty"`
	ParticipantType   string `json:"ParticipantType,omitempty"`
	Settlor           string `json:"settlor,omitempty"`
	Gtcflag           string `json:"Gtcflag,omitempty"`
	EncashFlag        string `json:"EncashFlag,omitempty"`
	PanID             string `json:"pan_id,omitempty"`
	GttFlag           string `json:"GttFlag,omitempty"`
	ILegValue         string `json:"iLegValue,omitempty"`
}
