package model

type TotpAuthModel struct {
	TOTP     string `json:"totp"`
	Password string `json:"password"`
}
