package controller

import (
	"net/http"

	"github.com/MACMREPO/libdb/clientmaster"
	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/gin"
)

func AddReferral(c *gin.Context) {
	libhttp.CoreHeader(c)
	var Referralreq clientmaster.ReferralMaster
	if err := c.BindJSON(&Referralreq); err != nil {
		service.Zerologs.Error().Msg("AddReferral(): Error c.BindJSON stockalreq model " + err.Error())
		c.JSON(http.StatusBadRequest, "Bad request")
		return
	}
	response, err := service.AddReferralService(Referralreq)
	if err != nil {
		c.JSON(http.StatusInternalServerError, err)
		return
	}
	c.JSON(http.StatusOK, response)
}
