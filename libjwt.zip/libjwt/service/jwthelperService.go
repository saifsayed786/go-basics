package service

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io/ioutil"
	"net/http"
	"net/url"
	"os"
	"strconv"
	"strings"
	"time"

	"github.com/MACMREPO/libdb"
	"github.com/MACMREPO/libdb/clientmaster"
	"github.com/MACMREPO/libdb/jwtauth"
	"github.com/MACMREPO/libenv"
	"github.com/MACMREPO/libinterface"
	"github.com/MACMREPO/libjwt/helper"
	"github.com/MACMREPO/libjwt/model"
	"github.com/MACMREPO/libredis"
	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt"
	"github.com/golobby/container/v3"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/rs/zerolog"
)

var (
	Env *libenv.Env
	Db  *libdb.ClientDB
	// jdb      *libdb.JwtAuthMasterDB
	Wdb      *libdb.WatchListDB
	RedisLib *libredis.RedisClient

	hmacSampleSecret            []byte
	Zerologs                    zerolog.Logger
	JwtCounterVecRequested      *prometheus.CounterVec
	JwtCounterVecRequestFailure *prometheus.CounterVec
	JwtCounterVecSuccess        *prometheus.CounterVec
	JwtCounterVecFailure        *prometheus.CounterVec
	State                       string
)

const (
	BaseUrl             = "https://www.nuuu.com"
	Default_Profile_Pic = "https://s3.ap-south-1.amazonaws.com/image.nuuu.com/images/user-profile.svg"
)

func InitJwt() error {
	err := container.Resolve(&Env)
	if err != nil {
		fmt.Println("Env Lib is Not register please register with init")
		return err
	}

	err = container.NamedResolve(&Zerologs, "zerologs")
	if err != nil {
		fmt.Println("Log Lib is Not register please register with init")
		return err
	}

	var clientdb libdb.ClientDB
	err = clientdb.Connect()
	if err != nil {
		fmt.Println("Database is Not Connected" + err.Error())
		return err
	}
	var userdb libinterface.IDBContext
	err = container.NamedResolve(&userdb, Env.DI_DB_CLINTMASTER)
	if err != nil {
		fmt.Println("Database Lib Not Initialize" + err.Error())
	}
	Db = userdb.(*libdb.ClientDB)

	//
	// var jwtauthdb libdb.JwtAuthMasterDB
	// err = jwtauthdb.Connect()
	// if err != nil {
	// 	fmt.Println("Database is Not Connected" + err.Error())
	// 	return err
	// }
	// var jwtidb libinterface.IDBContext
	// err = container.NamedResolve(&jwtidb, Env.DI_DB_JWTAUTH)
	// if err != nil {
	// 	fmt.Println("Database Lib Not Initialize" + err.Error())
	// }
	// jdb = jwtidb.(*libdb.JwtAuthMasterDB)

	err = container.Resolve(&RedisLib)
	if err != nil {
		fmt.Println("RedisLib Lib Not Initialize" + err.Error())
	}

	if Env.JWT_SECRET == "" {
		fmt.Println("Env.JWT_SECRET Not FOUND")
	}

	if Env.MY_POD_NAME == "" {
		fmt.Println("Env.MY_POD_NAME Not FOUND")
	}
	hmacSampleSecret = []byte(Env.JWT_SECRET)

	JwtCounterVecRequested = prometheus.NewCounterVec(
		prometheus.CounterOpts{
			Name: "JWT_RRQUESTED",
			Help: "Total Requested JWT Token .",
		},
		[]string{"jwt"},
	)
	err = prometheus.Register(JwtCounterVecRequested)
	if err != nil {
		Zerologs.Error().Msg("Error while registering promethus " + Env.MY_POD_NAME + "_JWT_RRQUESTED" + "  " + err.Error())
		return err
	}

	JwtCounterVecRequestFailure = prometheus.NewCounterVec(
		prometheus.CounterOpts{
			Name: "JWT_RRQUESTED_FAILURE",
			Help: "Total Requested Failure JWT Token .",
		},
		[]string{"jwt"},
	)
	err = prometheus.Register(JwtCounterVecRequestFailure)
	if err != nil {
		Zerologs.Error().Msg("Error while registering promethus " + Env.MY_POD_NAME + "_JWT_RRQUESTED_FAILURE" + "  " + err.Error())
		return err
	}
	JwtCounterVecSuccess = prometheus.NewCounterVec(
		prometheus.CounterOpts{
			Name: "JWT_SUCCESS",
			Help: "Total Success JWT Token .",
		},
		[]string{"jwt"},
	)
	err = prometheus.Register(JwtCounterVecSuccess)
	if err != nil {
		Zerologs.Error().Msg("Error while registering promethus " + Env.MY_POD_NAME + "_JWT_SUCCESS" + "  " + err.Error())
		return err
	}
	JwtCounterVecFailure = prometheus.NewCounterVec(
		prometheus.CounterOpts{
			Name: "JWT_FAILURE",
			Help: "Total Failure JWT Token .",
		},
		[]string{"jwt"},
	)
	err = prometheus.Register(JwtCounterVecFailure)
	if err != nil {
		Zerologs.Error().Msg("Error while registering promethus " + Env.MY_POD_NAME + "_JWT_FAILURE" + "  " + err.Error())
		return err
	}

	err = InitLoginPage()
	if err != nil {
		Zerologs.Error().Msg("Error while registering promethus " + Env.MY_POD_NAME + "_JWT_FAILURE" + "  " + err.Error())
		//		return err
	}
	return nil
}

func GenerateAccessTokenOnRefreshToken(token *jwt.Token) (string, error) {
	claims := token.Claims.(jwt.MapClaims)
	smobileno := claims[helper.Name]
	objRole := claims[helper.Role]
	semail := claims["email"]
	sclientid := claims["clientid"]
	//smfclientid := claims["mfclientid"] //samir pending
	if smobileno == "" {
		return "", nil
	}
	accesstoken := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		helper.Name:  smobileno,
		helper.Role:  objRole,
		"mobileno":   smobileno,
		"email":      semail,
		"clientid":   sclientid,
		"name":       smobileno,
		"mfclientid": smobileno,
		// "mfclientid": "9673780788", //Samir Hardcoded Need to Change
		"iat": time.Now().Unix(),
		// Token Expire Time change from 20 minutes to 30 days for refresh_token
		// "exp": time.Now().Add(time.Minute * time.Duration(Env.JWT_TOKEN_TIMETOEXPIRE)).Unix(),
		"exp": time.Now().AddDate(0, 0, Env.JWT_ACCESS_TOKEN_TIME_TO_EXPIRE_IN_DAY).Unix(),
		"nbf": time.Date(2015, 10, 10, 12, 0, 0, 0, time.UTC).Unix(),
		"aud": Env.JWTAUDIENCE,
		"iss": Env.JWTISSUER,
	})
	tokenString, err := accesstoken.SignedString(hmacSampleSecret)
	if err != nil {
		JwtCounterVecRequestFailure.WithLabelValues("jwt").Inc()
		Zerologs.Error().Msg("GenerateJWT  SignedString Error :=" + err.Error())
		return "", err
	}
	return tokenString, nil
}

func GenerateJWT(username string) (string, error) {
	if JwtCounterVecRequested != nil {
		JwtCounterVecRequested.WithLabelValues("jwt").Inc()
	}
	Zerologs.Info().Msg("GenerateJWT  started for user =" + username)
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"name":     username,
		"mobileno": username,
		"clientid": username,
		"nbf":      time.Date(2015, 10, 10, 12, 0, 0, 0, time.UTC).Unix(),
	})
	tokenString, err := token.SignedString(hmacSampleSecret)
	Zerologs.Info().Msg("GenerateJWT  SignedString:=" + tokenString)
	if err != nil {
		JwtCounterVecRequestFailure.WithLabelValues("jwt").Inc()
		Zerologs.Error().Msg("GenerateJWT  SignedString Error :=" + err.Error())
		return "", err
	}
	return tokenString, nil
}

// func InitGoogleauthOldx(router *gin.RouterGroup) error {
// 	redirectURL := Env.GOOGLE_REDIRECT_URL //"http://localhost:8087/auth/"
// 	credFile := Env.GOOGLE_SECRET_PATH     // "/googlesecret.json"
// 	fmt.Println(redirectURL + " -- " + credFile)
// 	if _, err := os.Stat(credFile); errors.Is(err, os.ErrNotExist) {
// 		fmt.Println("GoogleSecret.json file not exist" + err.Error())
// 		return err
// 	}
// 	scopes := []string{
// 		"https://www.googleapis.com/auth/userinfo.profile",
// 		"https://www.googleapis.com/auth/userinfo.email",
// 		// You have to select your own scope from here -> https://developers.google.com/identity/protocols/googlescopes#google_sign-in
// 	}
// 	secret := []byte(hmacSampleSecret)
// 	google.Setup(redirectURL, credFile, scopes, secret)

// 	sessionName := "goquestsession"
// 	router.Use(google.Session(sessionName))
// 	router.GET("/glogin", loginhandler)
// 	private := router.Group("/auth")
// 	//private.Use(google.Auth())
// 	private.Use(authandler)
// 	private.GET("/", UserInfoHandler)
// 	private.GET("/api", func(ctx *gin.Context) {
// 		ctx.JSON(200, gin.H{"message": "Hello from private for groups"})
// 	})
// 	return nil
// }

func UserInfoHandler(ctx *gin.Context) {
	// var (
	// 	res goauth.Userinfo
	// 	ok  bool
	// )

	val := ctx.MustGet("user")
	print(val)
	// if res, ok = val.(goauth.Userinfo); !ok {
	// 	res = goauth.Userinfo{Name: "no user"}
	// }

	ctx.JSON(http.StatusOK, gin.H{"Hello": "from private", "user": ""}) //val.data.email
}

func GenerateKubeAdminClaim(mobileno string) (map[string]string, error) {
	var tokenmap = make(map[string]string)
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		helper.Name: mobileno,
		helper.Role: [2]string{"admin", "kubeadmin"},
		"mobileno":  mobileno,
		"name":      mobileno,
		"iat":       time.Now().Unix(),
		// Token Expire Time change from 20 minutes to 30 days for refresh_token
		// "exp": time.Now().Add(time.Minute * time.Duration(Env.JWT_TOKEN_TIMETOEXPIRE)).Unix(),
		"exp": time.Now().AddDate(0, 0, Env.JWT_REFRESH_TOKEN_TIME_TO_EXPIRE_IN_DAYS).Unix(),
		"nbf": time.Date(2015, 10, 10, 12, 0, 0, 0, time.UTC).Unix(),
		"aud": Env.JWTAUDIENCE,
		"iss": Env.JWTISSUER,
	})
	tokenString, err := token.SignedString(hmacSampleSecret)
	if err != nil {
		JwtCounterVecRequestFailure.WithLabelValues("jwt").Inc()
		Zerologs.Error().Msg("GenerateJWT  SignedString Error :=" + err.Error())
		return nil, err
	}
	// err = RedisLib.Client.Set(tokenString, mobileno, time.Hour*480).Err()
	// if err != nil {
	// 	fmt.Println(err)
	// }
	tokenmap["access_token"] = tokenString
	return tokenmap, nil
}

func GenerateJWTWithRefresh(mobileno string, email string, accountcode string) (model.TokenModel, error) {
	var TokenModel model.TokenModel
	if JwtCounterVecRequested != nil {
		JwtCounterVecRequested.WithLabelValues("jwt").Inc()
	}
	refreshToken := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		helper.Name:  mobileno,
		helper.Role:  [2]string{"HTrade", "MF"},
		"mobileno":   mobileno,
		"email":      email,
		"clientid":   accountcode,
		"mfclientid": mobileno,
		"exp":        time.Now().AddDate(0, 0, Env.JWT_REFRESH_TOKEN_TIME_TO_EXPIRE_IN_DAYS).Unix(),
	})

	refreshtokenString, err := refreshToken.SignedString(hmacSampleSecret)
	if err != nil {
		JwtCounterVecRequestFailure.WithLabelValues("jwt").Inc()
		Zerologs.Error().Msg("GenerateJWT  Refresh SignedString Error :=" + err.Error())
		return TokenModel, err
	}
	TokenModel.RefreshToken = refreshtokenString
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		helper.Name:  mobileno,
		helper.Role:  [2]string{"HTrade", "MF"},
		"mobileno":   mobileno,
		"email":      email,
		"clientid":   accountcode,
		"name":       mobileno,
		"mfclientid": mobileno,
		"iat":        time.Now().Unix(),
		// Token Expire Time change from 20 minutes to 30 days for refresh_token
		// "exp": time.Now().Add(time.Minute * time.Duration(Env.JWT_TOKEN_TIMETOEXPIRE)).Unix(),
		"exp": time.Now().AddDate(0, 0, Env.JWT_ACCESS_TOKEN_TIME_TO_EXPIRE_IN_DAY).Unix(),
		"nbf": time.Date(2015, 10, 10, 12, 0, 0, 0, time.UTC).Unix(),
		"aud": Env.JWTAUDIENCE,
		"iss": Env.JWTISSUER,
	})

	tokenString, err := token.SignedString(hmacSampleSecret)
	if err != nil {
		JwtCounterVecRequestFailure.WithLabelValues("jwt").Inc()
		Zerologs.Error().Msg("GenerateJWT  SignedString Error :=" + err.Error())
		return TokenModel, err

	}
	TokenModel.AccessToken = tokenString
	TokenModel.Url = Env.GOOGLE_MAIN_PAGE
	return TokenModel, nil

}
func ValidateRefreshTokenForAccessToken(refreshtoken string) (string, error) {
	token, err := jwt.Parse(refreshtoken, func(token *jwt.Token) (interface{}, error) {
		// Don't forget to validate the alg is what you expect:
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("Unexpected signing method: %v", token.Header["alg"])
		}

		// hmacSampleSecret is a []byte containing your secret, e.g. []byte("my_secret_key")
		return hmacSampleSecret, nil
	})

	if err != nil {
		JwtCounterVecFailure.WithLabelValues("jwt").Inc()
		Zerologs.Error().Msg("GetUser  :=" + err.Error())
		return "", err
	}
	if token == nil {
		JwtCounterVecFailure.WithLabelValues("jwt").Inc()
		err := errors.New("token is null")
		Zerologs.Error().Msg("GetUser  Split  Error Token :=" + err.Error())
		return "", err
	}
	if token.Claims == nil {
		JwtCounterVecFailure.WithLabelValues("jwt").Inc()
		err := errors.New("token  claims is null")
		Zerologs.Error().Msg("GetUser  Split  Error Token :=" + err.Error())
		return "", err
	}
	// var sClaim string
	// if claims, ok := token.Claims.(jwt.MapClaims); ok && token.Valid {
	// 	sClaim = claims["mobileno"].(string)
	// } else {
	// 	JwtCounterVecFailure.WithLabelValues("jwt").Inc()
	// 	err := errors.New("claim Not Found")
	// 	Zerologs.Error().Msg("GetUser  Split  Error Token :=" + err.Error())
	// 	return "", err
	// }
	return GenerateAccessTokenOnRefreshToken(token)
}

func ValidateRefreshToken(refreshtoken string) (string, error) {
	token, err := jwt.Parse(refreshtoken, func(token *jwt.Token) (interface{}, error) {
		// Don't forget to validate the alg is what you expect:
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("Unexpected signing method: %v", token.Header["alg"])
		}

		// hmacSampleSecret is a []byte containing your secret, e.g. []byte("my_secret_key")
		return hmacSampleSecret, nil
	})

	if err != nil {
		JwtCounterVecFailure.WithLabelValues("jwt").Inc()
		Zerologs.Error().Msg("GetUser  :=" + err.Error())
		return "", err
	}
	if token == nil {
		JwtCounterVecFailure.WithLabelValues("jwt").Inc()
		err := errors.New("token is null")
		Zerologs.Error().Msg("GetUser  Split  Error Token :=" + err.Error())
		return "", err
	}
	if token.Claims == nil {
		JwtCounterVecFailure.WithLabelValues("jwt").Inc()
		err := errors.New("token  claims is null")
		Zerologs.Error().Msg("GetUser  Split  Error Token :=" + err.Error())
		return "", err
	}
	var sClaim string
	if claims, ok := token.Claims.(jwt.MapClaims); ok && token.Valid {
		sClaim = claims["mobileno"].(string)
	} else {
		JwtCounterVecFailure.WithLabelValues("jwt").Inc()
		err := errors.New("claim Not Found")
		Zerologs.Error().Msg("GetUser  Split  Error Token :=" + err.Error())
		return "", err
	}
	return GenerateJWT(sClaim)
}

func GetUser(c *gin.Context) (uint, error) {
	jwttoken := c.GetHeader("Authorization")
	if jwttoken == "" {
		if JwtCounterVecFailure != nil {
			JwtCounterVecFailure.WithLabelValues("jwt").Inc()
		}
		return 0, errors.New("token not found")
	}
	strArr := strings.Split(jwttoken, " ")
	if len(strArr) == 2 {
		jwttoken = strArr[1]
	} else {
		if JwtCounterVecFailure != nil {
			JwtCounterVecFailure.WithLabelValues("jwt").Inc()
		}
		err := errors.New("authorization is not in proper format")
		Zerologs.Error().Msg("GetUser  Split  Error Token :=" + jwttoken + ", Error:=" + err.Error())
		return 0, err
	}

	token, err := jwt.Parse(jwttoken, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			if JwtCounterVecFailure != nil {
				JwtCounterVecFailure.WithLabelValues("jwt").Inc()
			}
			err := fmt.Errorf("unexpected signing method: %v", token.Header["alg"])
			Zerologs.Error().Msg("GetUser  Jwt Parse :=" + err.Error())
			return nil, err
		}
		return hmacSampleSecret, nil
	})
	if err != nil {
		if JwtCounterVecFailure != nil {
			JwtCounterVecFailure.WithLabelValues("jwt").Inc()
		}
		Zerologs.Error().Msg("GetUser  :=" + err.Error())
		return 0, err
	}
	if token == nil {
		if JwtCounterVecFailure != nil {
			JwtCounterVecFailure.WithLabelValues("jwt").Inc()
		}
		err := errors.New("token is null")
		Zerologs.Error().Msg("GetUser  Split  Error Token :=" + err.Error())
		return 0, err
	}
	if token.Claims == nil {
		if JwtCounterVecFailure != nil {
			JwtCounterVecFailure.WithLabelValues("jwt").Inc()
		}
		err := errors.New("token  claims is null")
		Zerologs.Error().Msg("GetUser  Split  Error Token :=" + err.Error())
		return 0, err
	}

	var sClaim string
	if claims, ok := token.Claims.(jwt.MapClaims); ok && token.Valid {
		sClaim = claims["mobileno"].(string)
	} else {
		if JwtCounterVecFailure != nil {
			JwtCounterVecFailure.WithLabelValues("jwt").Inc()
		}
		err := errors.New("claim Not Found")
		Zerologs.Error().Msg("GetUser  Split  Error Token :=" + err.Error())
		return 0, err
	}
	u64, err := strconv.ParseUint(sClaim, 10, 64)
	if err != nil {
		if JwtCounterVecFailure != nil {
			JwtCounterVecFailure.WithLabelValues("jwt").Inc()
		}
		Zerologs.Error().Msg("GetUser ParseUint  sClaim:=" + sClaim + " " + err.Error())
		return 0, err
	}
	if JwtCounterVecSuccess != nil {
		JwtCounterVecSuccess.WithLabelValues("jwt").Inc()
	}
	return uint(u64), nil
}

// func loginhandler(c *gin.Context) {
// 	loginURL := google.GetLoginURL(state)
// 	stemplate := Lefttemplate + loginURL + Righttemplate
// 	state = randToken()
// 	session := sessions.Default(c)
// 	session.Set("state", state)
// 	session.Save()
// 	c.Writer.Write([]byte(stemplate))
// }

// func randToken() string {
// 	b := make([]byte, 32)
// 	rand.Read(b)
// 	return base64.StdEncoding.EncodeToString(b)
// }

// func GetLoginURL(state string) string {
// 	return conf.AuthCodeURL(state)
// }

// func authandler(ctx *gin.Context) {
// 	session := sessions.Default(ctx)
// 	retrievedState := session.Get("state")
// 	//oldstate := ctx.Query("state") problem need to check

// 	if retrievedState != state {
// 		ctx.AbortWithError(http.StatusUnauthorized, fmt.Errorf("Invalid session state: %s", retrievedState))
// 		return
// 	}

// 	tok, err := conf.Exchange(oauth2.NoContext, ctx.Query("code"))
// 	if err != nil {
// 		ctx.AbortWithError(http.StatusBadRequest, err)
// 		return
// 	}

// 	client := conf.Client(oauth2.NoContext, tok)
// 	email, err := client.Get("https://www.googleapis.com/oauth2/v3/userinfo")
// 	if err != nil {
// 		ctx.AbortWithError(http.StatusBadRequest, err)
// 		return
// 	}
// 	defer email.Body.Close()
// 	data, err := ioutil.ReadAll(email.Body)
// 	if err != nil {
// 		glog.Errorf("[Gin-OAuth] Could not read Body: %s", err)
// 		ctx.AbortWithError(http.StatusInternalServerError, err)
// 		return
// 	}

// 	var user User
// 	err = json.Unmarshal(data, &user)
// 	if err != nil {
// 		glog.Errorf("[Gin-OAuth] Unmarshal userinfo failed: %s", err)
// 		ctx.AbortWithError(http.StatusInternalServerError, err)
// 		return
// 	}
// 	// save userinfo, which could be used in Handlers
// 	ctx.Set("user", user)

// }

func AddJwtMaster(jwtdata interface{}) (string, error) {
	data := jwtdata.(model.JwtMaster)
	var clientdb clientmaster.JwtAuthMaster
	clientdb.MobileNo = data.MobileNo
	clientdb.MobileOtp = data.MobileOtp
	clientdb.MobileVerified = data.MobileVerified
	clientdb.Email = data.Email
	clientdb.ClientID = data.ClientID
	clientdb.Password = data.Password
	clientdb.Activated = data.Activated
	clientdb.UserGuid = data.UserGuid
	clientdb.Sub = data.Sub
	if data.Name == "" {
		clientdb.Name = data.MobileNo
	} else {
		clientdb.Name = data.Name
	}

	clientdb.GivenName = data.GivenName
	clientdb.FamilyName = data.FamilyName
	clientdb.Profile = data.Profile
	clientdb.Picture = data.Picture
	clientdb.EmailVerified = data.EmailVerified
	clientdb.Gender = data.Gender
	clientdb.KYCDone = data.KYCDone
	clientdb.MPIN = data.MPIN
	clientdb.PasswordFailedCount = data.PasswordFailedCount
	clientdb.LastPassword_UpdatedTime = time.Now()
	clientdb.IsPasswordReset = data.IsPasswordReset
	clientdb.LastMPIN_UpdatedTime = time.Now()
	clientdb.UserActivatedTime = time.Now()
	clientdb.IsMPIN_Reset = data.IsMPIN_Reset
	clientdb.HyperSyncAccessToken = data.HyperSyncAccessToken
	clientdb.Pan = data.Pan
	clientdb.Default_password = data.Default_password
	clientdb.Refreshtoken = data.Refreshtoken
	// clientdb.ExpiresInDays = data.ExpiresInDays
	err := Db.Client.Create(&clientdb).Error
	if err != nil {
		fmt.Println(err)
		return "", err
	} else {
		return "success", nil
	}

}

func DeleteAuth(mobileNo string) (string, error) {
	var tbldbData jwtauth.JwtAuthMaster
	err := Db.Client.Where("mobile_no=?", mobileNo).First(&tbldbData).Error
	if err != nil {
		fmt.Println(err)
		return "", err
	} else {
		err := Db.Client.Where("mobile_no=?", mobileNo).Delete(&tbldbData).Error
		if err != nil {
			fmt.Println(err)
			return "", nil
		}
		return "success", nil
	}

}
func IsAlreadyRegister(mobileno string) (bool, int, int) {
	// var User clientmaster.JwtAuthMaster
	// err := Db.Client.Where("mobile_no=?", mobileno).First(&User).Error
	User, err := getJwtAuthMasterDB(helper.CLIENT_MOBILE_PARAM, mobileno)
	if err != nil {
		Zerologs.Error().Err(err).Msg("Mobile number not registered" + mobileno)
		return false, 0, 0
	}
	return true, User.PasswordFailedCount, User.MPINFailedCount
}

func IsUserAlreadyRegister(UserType int, mobileno string) (bool, int, int) {
	var User clientmaster.JwtAuthMaster

	if UserType == helper.CLIENT_MOBILE_PARAM { // UserType : Mobile  [AjayN]
		err := Db.Client.Where("mobile_no=?", mobileno).First(&User).Error
		if err != nil {
			Zerologs.Error().Err(err).Msg("Mobile number not registered" + mobileno)
			return false, 0, 0
		}

	} else if UserType == helper.CLIENT_EMAIL_PARAM { // UserType : Email  [AjayN]
		err := Db.Client.Where("email=?", mobileno).First(&User).Error
		if err != nil {
			Zerologs.Error().Err(err).Msg("Email Id not registered" + mobileno)
			return false, 0, 0
		}

	} else if UserType == helper.CLIENT_ID_PARAM { // UserType : Client Code [AjayN]
		err := Db.Client.Where("client_id=?", mobileno).First(&User).Error
		if err != nil {
			Zerologs.Error().Err(err).Msg("Client Code not registered" + mobileno)
			return false, 0, 0
		}
	}

	return true, User.PasswordFailedCount, User.MPINFailedCount
}

func IsEmailPresent(email string) (bool, int) {
	var User clientmaster.JwtAuthMaster
	err := Db.Client.Where("email=?", email).First(&User).Error
	if err != nil {
		Zerologs.Error().Err(err).Msg("Email not registered")
		return false, 0
	}
	return true, User.PasswordFailedCount
}

func VerifyUser(skey string) (string, error) {
	// libhttp.CoreHeader(c)
	// skey := c.Request.Header.Get("access_token")
	// fmt.Println("Skey => ", skey)
	if skey == "" {
		Zerologs.Error().Msg("VerifyUser() : AccessToken found empty")
		return "", errors.New("AccessToken not found")
	}
	var RedisLib *libredis.RedisClient
	err := container.Resolve(&RedisLib)
	if err != nil {
		// panic("RedisLib Lib Not Initialize" + err.Error())
		Zerologs.Error().Err(err).Msg("VerifyUser() : RedisLib Lib Not Initialize" + err.Error())
		return "", err
	}
	MobileNo, err := RedisLib.Client.Get(skey).Result()
	if err != nil {
		// fmt.Println("Error getting skey from redis : ")
		Zerologs.Error().Err(err).Msg("VerifyUser() : Mobile no not found in redis against access token:= " + skey)
		return "Unauthorized", err
	}
	// fmt.Println("MobileNo from redis is : " + MobileNo)
	return MobileNo, nil
}
func SendUrl(url string, model interface{}) error {
	jsonStr, err := json.Marshal(&model)
	if err != nil {
		Zerologs.Error().Err(err).Msg("SendUrl(): Error While marshalling model")
		// fmt.Println(err)
		return err
	}
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonStr))
	// req.Header.Set("X-Custom-Header", "myvalue")
	if err != nil {
		Zerologs.Error().Err(err).Msgf("SendUrl():Error While Sending POST Request %s", url)
		// fmt.Println(err)
		return err
	}
	req.Header.Set("Content-Type", "application/json")

	client := &http.Client{}
	rep, err := client.Do(req)
	if err != nil {
		Zerologs.Error().Err(err).Msgf("SendUrl():Error while Getting response from %s", url)
		return err
	}
	defer rep.Body.Close()
	// fmt.Println("response Status:", rep.Status)
	// fmt.Println("response Headers:", rep.Header)
	_, err = ioutil.ReadAll(rep.Body)
	if err != nil {
		// fmt.Println(err)
		Zerologs.Error().Err(err).Msg("SendUrl():Error While Reading Request body")
		return err
	}
	// fmt.Println("response Body:", string(body))
	return nil
}

// func AddUserData(facetrade.Tbl_UserData) (string, error) {

// 	var usermodel model.JwtMaster
// 	err := Db.Client.Where("mobile_no=?", mobileno).First(&usermodel).Error
// 	var tbl_userdata facetrade.Tbl_UserData
// 	guid, _ := StringToUuid(usermodel.UserGuid)
// 	tbl_userdata.GUID = guid
// 	tbl_userdata.Mobileno = usermodel.MobileNo
// 	err = Db.Client.Create(&tbl_userdata).Error
// 	if err != nil {
// 		Zerologs.Error().Msg("Error while add data in user data table")
// 		fmt.Println(err)
// 	}
// 	return mobileno, nil

// }

func AddWatchList(mobileNo string) error {

	sStage := os.Getenv("STAGE")
	Papertradepath := ""
	if sStage == "" {
		Papertradepath = "https://www.nuuu.com"
	} else {
		Papertradepath = "http://papertrade-" + sStage + "-service:8085"
	}

	var watchlistData model.Tbl_WatchList
	watchlistData.MwName = "Watchlist-1"
	watchlistData.Scrips = "nse_cm|11536,nse_cm|22,nse_cm|1330"
	watchlistData.UsrId = mobileNo

	// url := "http://localhost:8087/papertrade/api/htpl/userwatchlist/addusergroups"
	url := Papertradepath + "/papertrade/api/htpl/userwatchlist/addusergroups"
	// fmt.Println(Papertradepath)

	err := SendUrl(url, watchlistData)
	if err != nil {
		Zerologs.Error().Msg("AddWatchList():=User mobileNO:= " + mobileNo + "watchlistData  not added in db due to error occured in SendUrl function" + err.Error())
		return err
	}
	var limitdata model.Tbl_PaperTrade_limit
	limitdata.Uid = mobileNo
	limitdata.ContestId = 0
	limitdata.ActualLimit = 1000000
	limitdata.Utilized = 0
	limitdata.MarginActualLimit = 1000000
	limitdata.MarginUtilized = 0
	limitdata.MarginUtilized = 0
	limitdata.CollateralValue = 0
	limitdata.AuxAdhocMargin = 0
	limitdata.AdhocMargin = 0
	limitdata.RMSCollateral = 0
	limitdata.SpanMarginPrsnt = 0

	// url = "http://localhost:8087/papertrade/api/addlimit"
	url = Papertradepath + "/papertrade/api/addlimit"

	err = SendUrl(url, limitdata)
	if err != nil {
		Zerologs.Error().Msg("AddWatchList():=User mobileNO:= " + mobileNo + "limitdata  not added in db due to error occured in SendUrl function" + err.Error())
		return err
	}

	var WatchlistModel model.WatchListModel
	WatchlistModel.MwName = "Watchlist-1"
	WatchlistModel.Scrips = "nse_cm|11536,nse_cm|22,nse_cm|1330"
	WatchlistModel.UsrId = mobileNo
	WatchlistModel.Type = 1

	Watchlistpath := ""
	if sStage == "" {
		Watchlistpath = "https://www.nuuu.com"
	} else {
		Watchlistpath = "http://watchlist-" + sStage + "-service:8085"
	}

	// url = "http://localhost:8087/watchlist/api/htpl/userwatchlist/addusergroups"
	url = Watchlistpath + "/watchlist/api/htpl/userwatchlist/addusergroups"

	err = SendUrl(url, WatchlistModel)
	if err != nil {
		Zerologs.Error().Msg("AddWatchList():=User mobileNO:= " + mobileNo + "watchlistData  not added in db due to error occured in SendUrl function" + err.Error())
		return err
	}
	return nil
}

// func AddSociaInfo(data SocialModel) error {
// 	sStage := os.Getenv("STAGE")
// 	FaceTradepath := ""
// 	if sStage == "" {
// 		FaceTradepath = "https://www.nuuu.com"
// 	} else {
// 		FaceTradepath = "http://facetrade-" + sStage + "-service:8085"
// 	}
// 	url := FaceTradepath + "/facetrade/user/signup"
// 	err := SendUrl(url, data)
// 	if err != nil {
// 		Zerologs.Error().Msg("AddSociaInfo():=User mobileNO:= " + data.Mobileno + "social data not added in db due to error occured in SendUrl function" + err.Error())
// 		return err
// 	}
// 	return nil
// var tbl_userdata facetrade.Tbl_UserData
// err := fdb.FaceTrade.Where("mobileno=?", data.Mobileno).First(&tbl_userdata).Error
// if err == nil {
// 	Zerologs.Error().Msg("Data already exists")
// 	return err
// } else {
// 	tbl_userdata.ID = data.ID
// 	tbl_userdata.Name = data.Name
// 	tbl_userdata.Email = data.Email
// 	tbl_userdata.Username = data.Username
// 	tbl_userdata.Mobileno = data.Mobileno
// 	tbl_userdata.GUID = data.GUID
// 	err = fdb.FaceTrade.Create(&tbl_userdata).Error
// 	if err != nil {
// 		Zerologs.Error().Msg("Error while add data in user data table" + err.Error())
// 		return err
// 	}
// }
// var profileData facetrade.Profileinfo
// err = fdb.FaceTrade.Where("phone_number=?", data.Mobileno).First(&profileData).Error
// if err == nil {
// 	Zerologs.Error().Msg("error while get data from clientmaster database" + err.Error())
// 	fmt.Println(err)
// 	return err
// }
// profileData.UserName = data.Name
// profileData.PhoneNumber = data.Mobileno
// profileData.EmailId = data.Email
// profileData.GUID = data.GUID.String()
// profileData.ProfilePicPath = "https://homesite.s3.ap-south-1.amazonaws.com/social/image/" + profileData.GUID + "_profile.jpg"
// err = fdb.FaceTrade.Create(&profileData).Error
// if err != nil {
// 	Zerologs.Error().Msg(" Add profile db.FaceTrade Create during sign up request" + err.Error())
// 	return err
// }
// var m = make(map[string]interface{})
// m["Username"] = data.Name
// m["Mobileno"] = data.Mobileno
// m["Email"] = data.Email
// m["Name"] = data.Name
// m["Password"] = data.Password
// m["guid"] = data.GUID

// sGUID := UuidToString(data.GUID)
// RedisLib.Client.HMSet("up:"+sGUID, m)
// redisModel := model.RedisFriendModel{
// 	Name:      data.Name,
// 	Guid:      sGUID,
// 	UserImage: "https://homesite.s3.ap-south-1.amazonaws.com/social/image/" + sGUID + "_profile.jpg",
// }

// err = RedisLib.Client.ZAdd("af", redis.Z{
// 	Score:  float64(data.ID),
// 	Member: redisModel,
// }).Err()
// if err != nil {
// 	Zerologs.Error().Msg("NewUser RedisLib.Client.ZAdd af" + redisModel.ToString() + " " + err.Error())
// 	return err
// }
// settingdata, err := SettingModel()
// settingdata[0].UserID = data.ID
// settingdata[1].UserID = data.ID
// settingdata[0].GUID = data.GUID
// settingdata[1].GUID = data.GUID
// err = fdb.FaceTrade.Create(&settingdata).Error
// if err != nil {
// 	Zerologs.Error().Msg("db.FaceTrade.Create =" + err.Error())
// 	return err
// }
// return nil
// }

func GetUserData(mobile string) (interface{}, error) {
	// libhttp.CoreHeader(c)
	// var UserData clientmaster.JwtAuthMaster
	// err := Db.Client.Where("mobile_no=?", mobile).First(&UserData).Error
	UserData, err := getJwtAuthMasterDB(helper.CLIENT_MOBILE_PARAM, mobile)
	if err != nil {
		Zerologs.Error().Msg("GetUserData(): User data not found for mobileno=" + mobile + " and error is " + err.Error())
		return nil, err
	}
	return UserData, nil
}
func Encrypt(plaintext string, key string, iv string) string {
	bPlaintext := []byte(plaintext)
	h := sha256.New()
	bKey := []byte(key)
	h.Write(bKey)
	bsKey := h.Sum(nil)
	// fmt.Printf("%x\n", bsKey)
	skey := fmt.Sprintf("%x\n", bsKey)
	skey = string(skey[0:32])
	h = sha256.New()
	bIV := []byte(iv)
	h.Write(bIV)
	bsIV := h.Sum(nil)

	siv := fmt.Sprintf("%x\n", bsIV)
	siv = string(siv[0:16])
	bPlaintext = PKCS5Padding(bPlaintext, aes.BlockSize)

	block, err := aes.NewCipher([]byte(skey))
	if err != nil {
		Zerologs.Error().Msg("TaxBuddyHandler(): Error in creating newcipher blocks for skey length: " + strconv.Itoa(len([]byte(skey))) + err.Error())
		return err.Error()
	}

	ciphertext := make([]byte, len(bPlaintext))

	mode := cipher.NewCBCEncrypter(block, []byte(siv))

	mode.CryptBlocks(ciphertext, bPlaintext)

	// fmt.Printf("EncryptedText %v\n", string(ciphertext))
	strciphertext := base64.StdEncoding.EncodeToString(ciphertext)
	strciphertext = url.QueryEscape(strciphertext)
	// fmt.Println(strciphertext)
	return strciphertext
}

func PKCS5Padding(ciphertext []byte, blockSize int) []byte {
	padding := (blockSize - len(ciphertext)%blockSize)
	padtext := bytes.Repeat([]byte{byte(padding)}, padding)
	return append(ciphertext, padtext...)
}

func DeleteDataUrl(url string, model interface{}) error {
	jsonStr, err := json.Marshal(&model)
	if err != nil {
		Zerologs.Error().Err(err).Msg("DeleteDataUrl(): Error While marshalling model")
		return err
	}
	resp, err := http.Post(url, "application/json", bytes.NewBuffer(jsonStr))
	if err != nil {
		Zerologs.Error().Err(err).Msg("DeleteDataUrl(): Error While send request to url=" + url + " and error is " + err.Error())
		return err
	}
	defer resp.Body.Close()
	//Read the response body
	_, err = ioutil.ReadAll(resp.Body)
	if err != nil {
		Zerologs.Error().Err(err).Msg("DeleteDataUrl(): Error While read response body of url=" + url + " and error is " + err.Error())
		return err
	}
	return nil
}

type StrSlice []string

var UrlsArr = StrSlice{
	"https://www.nuuu.com/trade",
	"",
	"https://www.nuuu.com/trade/",
	"https://www.nuuu.com/sign/unblockuser",
	"https://www.nuuu.com/sign/setpassword",
	"https://www.nuuu.com/sign/setmpin",
	"https://www.nuuu.com/sign/forgotpass",
}

func (list StrSlice) CheckUrls(a string) bool {
	for _, b := range list {
		if strings.Contains(a, b) {
			return true
		}
	}
	return false
}
