package service

import (
	"bytes"
	"io"
	"path/filepath"

	"github.com/MACMREPO/libdb/clientmaster"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/credentials"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/gin-gonic/gin"
)

func AddProfilePicServcie(MobileNo string, c *gin.Context) (string, error) {
	type UploadProfileModel struct {
		FileName string
		Buff     *bytes.Buffer
		FileExt  string
		Filepath string
	}

	uploaddrainerModel := UploadProfileModel{}
	files, header, err := c.Request.FormFile("file")
	if err != nil {
		Zerologs.Error().Msg("AddProfile(): c.Request.FormFile " + err.Error())
		return "", err
	}
	defer files.Close()
	uploaddrainerModel.Buff = bytes.NewBuffer(nil)
	if _, err := io.Copy(uploaddrainerModel.Buff, files); err != nil {
		Zerologs.Error().Msg("AddProfile(): io.Copy " + err.Error())
		return "", err
	}
	uploaddrainerModel.FileName = header.Filename
	uploaddrainerModel.FileExt = filepath.Ext(uploaddrainerModel.FileName)
	uploaddrainerModel.Filepath = "https://homesite.s3.ap-south-1.amazonaws.com/gojwt/image/" + uploaddrainerModel.FileName

	session, err := session.NewSession(&aws.Config{
		Region:      aws.String(Env.AWS_S3_REGION),
		Credentials: credentials.NewEnvCredentials(),
	})
	if err != nil {
		Zerologs.Error().Msg("AddProfile(): error while session.NewSession " + err.Error())
	}
	err = uploadFile(session, uploaddrainerModel.Buff.Bytes(), uploaddrainerModel.FileName)
	if err != nil {
		Zerologs.Error().Msg("AddProfile(): error while uploadFile " + err.Error())
		return "", err

	}
	err = Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", MobileNo).Updates(clientmaster.JwtAuthMaster{Picture: uploaddrainerModel.Filepath}).Error
	if err != nil {
		Zerologs.Error().Msg(" AddProfile(): Update picture failed for user " + MobileNo + err.Error())
		return "", err
	}
	Zerologs.Info().Msg("AddProfile(): User " + MobileNo + " upload his profile picture successfully...!")
	return uploaddrainerModel.Filepath, nil
}
