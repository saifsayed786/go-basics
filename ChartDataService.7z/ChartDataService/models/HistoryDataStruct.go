package models

type NewChartRespModel struct {
	ExchID         int16            `json:"exId"`
	DateTime       string           `json:"dt"`
	ChartHLOCModel []ChartHLOCModel `json:"hloc"`
}

type ChartHLOCModel struct {
	ExchId        int16   `json:"exId"`
	NToken        int     `json:"tk"`
	NClosingPrice float64 `json:"cp"`
	NOpenPrice    float64 `json:"op"`
	NHighPrice    float64 `json:"hp"`
	NLowPrice     float64 `json:"lp"`
	NVolume       float64 `json:"vl"`
	DtLogDateTime string  `json:"dt"`
}

type ChartModel struct {
	ContractDetails ContractDetails
	StoreMap        map[string]*ChartMapModel
}
type ContractDetails struct {
	NContractDate   int64
	SInstrumentName string
	SSymbol         string
	NExpiryDate     int64
	SOptionType     string
	NStrikePrice    int64
	NToken          int64
	SFullName       string
}
type ChartMapModel struct {
	//ChartHLOCModel    []ChartHLOCModel
	// CSVMap            map[time.Time][]string
	// CSVMap            map[int16]*[]string
	CSVMap map[int16]*CSVModel
	// LastReferenceTime time.Time
	// TimeDiffernce     int16
	//CSVModelarr       []CSVModel
	KeySlice []int16
}

type FileWriterModel struct {
	CsvMap         map[string][]string
	ExchId         int16
	Ntoken         int
	DtLogTime      string
	ChartHLOCModel []ChartHLOCModel
}
type IndexMaster struct {
	Id          int16  `json:"id"`
	SIndexName  string `json:"sIndexName"`
	Ntoken      int64  `json:"nTokenNo"`
	NExchangeId int16  `json:"nExchangeId"`
	SSymbol     string `json:"s_Symbol"`
}

type ContractMapModel struct {
	Contracts map[string]*ContractDetails
}
type CSVModel struct {
	CSVarr string
	// DateTime time.Time
}

type FileCronInput struct {
	Crondate string
	ExchId   string
}

type MaxToken struct {
	Ntoken int64 `json:"n_token"`
}

type SlackMessage struct {
	Text string `json:"text"`
}

type TimeFrameModel struct {
	ExTFarr [][24][60]int16 //[Exchange ID][Hours][Minutes]value: store index
}

type GenerateTFFileModel struct {
	Date string
	ExId string
}
type SendToProdModel struct {
	FromDate string
	ToDate   string
	EcxhId   int16
}
type UploadFileModel struct {
	Data   []byte
	Path   string
	ExchId int16
}
type BulkUploadFileModel struct {
	Bulkdata []UploadFileModel
}

type CsvFileHLOC struct {
	Date          string  `json:"date"`
	Time          string  `json:"time"`
	NClosingPrice float64 `json:"cp"`
	NOpenPrice    float64 `json:"op"`
	NHighPrice    float64 `json:"hp"`
	NLowPrice     float64 `json:"lp"`
	NVolume       float64 `json:"vl"`
	Extra         int16   `json:"extra"`
}

type MinWiseData struct {
	MinData []string
	Date    string
}
type DeleteRequest struct {
	Exch      int16
	Symbol    string
	TimeFrame string
	Date      string
}
type CompanyDateWiseData struct {
	ComapanyDateWiseMap map[string]MinWiseData
}

// TCS
// 1Min:[]MinData,Date
// type CompanyData struct {
// 	ComapanyName string
// 	CompanyMap   CompanyDateWiseData
// }

type TrueDataChartModel struct {
	ChartDataModel ChartMapModel
	Tf             string
	Symbol         string
	Exch           int16
	Date           string
	Token          int
}

type ChartModel_New struct {
	//Contract Details Pointer
	ContractDetails *ContractDetails

	//Exchange Wise Array
	ExWiseChartDetails []ExchangeWiseChartDetailsModel
}

type ExchangeWiseChartDetailsModel struct {
	ChartMapModelarr []ChartMapModel_New
}

type ChartMapModel_New struct {
	CSVModelarr []CSVModel_New
	KeySlice    []int16
}

type CSVModel_New struct {
	CSVarr []string
	Index  int16
}

type ChangeFolderModel struct {
	Path string
}
