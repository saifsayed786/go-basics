package model

// The OCO GTT feature allows you to place both Stop Loss and Target legs in the same instruction with respective trigger prices. Whichever leg trigger price is reached first gets executed, and the other leg is automatically cancelled

type GttOrderEntryModel struct {
	ExchClientID    string `json:"exch_client_id,omitempty"`
	Quantity1       string `json:"quantity1,omitempty"`
	Triggerprice    string `json:"triggerprice,omitempty"`
	Quantity2       string `json:"quantity2,omitempty"`
	Targetprice     string `json:"targetprice,omitempty"`
	Securityid      string `json:"securityid,omitempty"`
	Source          string `json:"source,omitempty"`
	ClientID        string `json:"client_id,omitempty"`
	Productlist     string `json:"productlist,omitempty"`
	Buysell         string `json:"buysell,omitempty"`
	ExchSegment     string `json:"exch_segment,omitempty"`
	UserType        string `json:"user_type,omitempty"`
	OrderType       string `json:"OrderType,omitempty"`
	TokenID         string `json:"token_id,omitempty"`
	UserID          string `json:"user_id,omitempty"`
	Quantitytype    string `json:"quantitytype,omitempty"`
	Price1          string `json:"price1,omitempty"`
	Price2          string `json:"price2,omitempty"`
	Exchange        string `json:"exchange,omitempty"`
	OfflineFlag     string `json:"offline_flag,omitempty"`
	MarketProflag   string `json:"marketProflag,omitempty"`
	MarketProVal    string `json:"marketProVal,omitempty"`
	ParticipantType string `json:"ParticipantType,omitempty"`
	Settlor         string `json:"settlor,omitempty"`
	Gtcflag         string `json:"Gtcflag,omitempty"`
	EncashFlag      string `json:"EncashFlag,omitempty"`
	PanID           string `json:"pan_id,omitempty"`
	GTDdate         string `json:"GTDdate,omitempty"`
	GttFlag         string `json:"GttFlag,omitempty"`
}
