package service

import (
	"github.com/MACMREPO/libdb/clientmaster"
	"github.com/MACMREPO/libjwt/model"
)

func StockalHandlerService(stockalreq model.StockalRequest) (string, error) {
	var jwtUser clientmaster.JwtAuthMaster
	err := Db.Client.Where("mobile_no=?", stockalreq.MobileNo).First(&jwtUser).Error
	if err != nil {
		Zerologs.Error().Msg("StockalHandler(): user not found in  clientmaster.JwtAuthMaster table  " + stockalreq.MobileNo + err.Error())
		return "", err
	}
	err = Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", stockalreq.MobileNo).Update("stockal_customer_id", stockalreq.CustomerId).Error
	if err != nil {
		Zerologs.Error().Msg("StockalHandler(): Stockal customer Id update failed for user  " + stockalreq.MobileNo + err.Error())
		return "", err
	}
	Zerologs.Info().Msg("StockalHandler(): Stockal CustomerId  successfully updated for user  " + stockalreq.MobileNo)
	return "Success", nil
}
