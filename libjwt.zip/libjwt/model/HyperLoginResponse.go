package model

type HyperLoginResponse struct {
	Status string `json:"status"`
	Code   int    `json:"code"`
	Data   struct {
		Message       string `json:"message"`
		Devicempinkey string `json:"devicempinkey"`
	} `json:"data"`
}
