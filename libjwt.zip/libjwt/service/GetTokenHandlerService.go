package service

import (
	"net/http"

	"github.com/MACMREPO/libjwt/helper"
	"github.com/MACMREPO/libjwt/model"
)

func GetTokenHandlerservice(RetrievedState string) model.TokenHandlerResponseModel {
	var ResponseModel model.TokenHandlerResponseModel
	// val, err := RedisLib.Client.Get(RetrievedState).Result()
	val, err := getDataFromRedis(RetrievedState)
	if err != nil {
		Zerologs.Error().Msg("GetTokenHandler(): Val[guid] not getting from redis by using retrieved state" + RetrievedState + err.Error())
		ResponseModel.IsErr = true
		ResponseModel.Msg = err.Error()
		ResponseModel.StatusCode = http.StatusInternalServerError
		return ResponseModel
	}

	// RedirectUrl, err := RedisLib.Client.Get(RetrievedState + "-RedirectUrl").Result()
	// if err != nil {
	// 	Zerologs.Error().Msg("GetTokenHandler(): RedirectUrl not getting from redis by using retrieved state for user mobileNo:= " + RetrievedState + err.Error())
	// 	ResponseModel.IsErr = true
	// 	ResponseModel.Msg = err.Error()
	// 	ResponseModel.StatusCode = http.StatusInternalServerError
	// 	return ResponseModel
	// }
	//samir sir code commented
	// var clientdbData clientmaster.TblJwtMaster

	// var clientdbData clientmaster.JwtAuthMaster
	// err = Db.Client.Where("user_guid=?", val).First(&clientdbData).Error
	clientdbData, err := getJwtAuthMasterDB(helper.CLIENT_USERGUID, val)
	if err != nil {
		Zerologs.Error().Msg("GetTokenHandler(): User data not found in JwtAuthMaster where user_guid=  " + val + err.Error())
		ResponseModel.IsErr = true
		ResponseModel.Msg = err.Error()
		ResponseModel.StatusCode = http.StatusInternalServerError
		return ResponseModel
	}

	// if clientdbData.PasswordFailedCount >= Env.MAX_PASSWORD_ATTEMPT || clientdbData.MPINFailedCount >= Env.MAX_MPIN_ATTEMPT {
	// 	token["errMsg"] = "User is blocked.please unblock and try again"
	// 	c.JSON(http.StatusInternalServerError, token)
	// 	return
	// }
	//Login with Hypersync
	if clientdbData.IsPasswordReset {
		if clientdbData.KYCDone {
			sAccountcode := clientdbData.ClientID + "-" + "NIT" //Samir Pending
			if clientdbData.Activated {
				// loginData := model.HypersyncModel{
				// 	Uid: clientdbData.ClientID + "-" + "NIT",
				// 	// Pwd:        clientdbData.Password,
				// 	BrokerId: "NIT",
				// 	System:   "NIT",
				// 	// DeviceName: clientdbData.ClientID + "-NIT_1658594564770",
				// 	// DeviceInfo: "EDGE-CHROMIUM",
				// }

				// var tbl_mobEmail clientmaster.TblMobileEmailMapping
				// err = Db.Client.Where("mobile_no=? and email=?", clientdbData.MobileNo, clientdbData.Email).First(&tbl_mobEmail).Error
				tbl_mobEmail, err := getEmailAndMobFromEmailMapping(clientdbData.MobileNo, clientdbData.Email)
				if err != nil {
					Zerologs.Error().Msg("GetTokenHandler(): Data not found in clientmaster.TblMobileEmailMapping  where =  " + clientdbData.MobileNo + " And " + clientdbData.Email + err.Error())
					ResponseModel.IsErr = true
					ResponseModel.Msg = err.Error()
					ResponseModel.StatusCode = http.StatusInternalServerError
					return ResponseModel
				}
				if tbl_mobEmail.TotpStatus {
					ResponseModel.IsErr = false
					ResponseModel.StatusCode = http.StatusOK
					ResponseModel.Url = "/sign/entertotp?state=" + RetrievedState
					return ResponseModel
				}
				if clientdbData.IsMPIN_Reset == false {
					ResponseModel.IsErr = false
					ResponseModel.StatusCode = http.StatusOK
					ResponseModel.Url = "/sign/setmpin?state=" + RetrievedState
					return ResponseModel
				}
				// key, err := NewHyperSyncLogin(loginData)
				// if err == nil {
				// 	token["devicekey"] = key
				// 	if IsMPINRequired {
				ResponseModel.IsErr = false
				ResponseModel.StatusCode = http.StatusOK
				ResponseModel.Url = "/sign/mpin?state=" + RetrievedState
				return ResponseModel
				// 	}
				// 	c.JSON(http.StatusOK, token)
				// } else {
				// 	Zerologs.Error().Msg("HypersyncLogin err in GetTokenHandler()" + err.Error())
				// 	c.JSON(http.StatusOK, token)
				// }
			} else {
				if clientdbData.IsMPIN_Reset == false {
					ResponseModel.IsErr = false
					ResponseModel.StatusCode = http.StatusOK
					ResponseModel.Url = "/sign/setmpin?state=" + RetrievedState
					return ResponseModel
				}
				token, err := GenerateJWTWithRefresh(clientdbData.MobileNo, clientdbData.Email, sAccountcode)
				if err != nil {
					Zerologs.Error().Msg("GetTokenHandler():GenerateJWTWithRefresh ,Token not generated for mobileNo=  " + clientdbData.MobileNo + "AND email:=  " + clientdbData.Email + err.Error())
					ResponseModel.IsErr = true
					ResponseModel.Msg = err.Error()
					ResponseModel.StatusCode = http.StatusInternalServerError
					return ResponseModel
				}
				// if clientdbData.MobileNo == "9673780788" {
				// 	var greenWareReq model.GreenwareRequestModel
				// 	greenWareReq.SsoBy = "mobile+user_type"
				// 	greenWareReq.Param1 = clientdbData.MobileNo
				// 	greenWareReq.Param2 = 1
				// 	mfaccesstoken := GreenWareLoginService(greenWareReq)
				// 	if mfaccesstoken != "" {
				// 		Zerologs.Info().Msg("GetTokenHandler() : User " + clientdbData.MobileNo + " successfully login to greenware " + " AT " + time.Now().Format("2006-01-02 15:04:05"))
				// 		token["mftoken"] = mfaccesstoken
				// 	} else {
				// 		token["mftoken"] = mfaccesstoken
				// 	}
				// }
				// if RedirectUrl == "" || RedirectUrl == "https://www.nuuu.com/trade" || RedirectUrl == "https://www.nuuu.com/trade/" {
				// if UrlsArr.CheckUrls(RedirectUrl) {
				// 	token["hyperSyncAccessToken"] = ""
				// 	token["isActivated"] = "false"
				// 	Zerologs.Info().Msg("GetTokenHandler(): USER LOGIN SUCCESSFULLY FOR MOBILE NO:=  " + clientdbData.MobileNo + " AT " + time.Now().Format("2006-01-02 15:04:05"))
				// 	return token, nil
				// } else {
				// 	token["hyperSyncAccessToken"] = ""
				// 	token["isActivated"] = "false"
				// 	token["url"] = RedirectUrl
				// 	Zerologs.Info().Msg("GetTokenHandler(): USER LOGIN SUCCESSFULLY FOR MOBILE NO:=  " + clientdbData.MobileNo + " AT " + time.Now().Format("2006-01-02 15:04:05"))
				// 	return token, nil
				// }
				ResponseModel.IsErr = false
				ResponseModel.StatusCode = http.StatusOK
				ResponseModel.IsActivated = false
				ResponseModel.AccessToken = token.AccessToken
				ResponseModel.RefreshToken = token.RefreshToken
				ResponseModel.Url = token.Url
				return ResponseModel
			}
		} else {
			token, err := GenerateJWTWithRefresh(clientdbData.MobileNo, clientdbData.Email, "")
			if err != nil {
				Zerologs.Error().Msg("GetTokenHandler():GenerateJWTWithRefresh ,Token not generated for mobileNo=  " + clientdbData.MobileNo + "AND email:=  " + clientdbData.Email + err.Error())
				ResponseModel.IsErr = true
				ResponseModel.Msg = err.Error()
				ResponseModel.StatusCode = http.StatusInternalServerError
				return ResponseModel
			}
			// if RedirectUrl == "" || RedirectUrl == "https://www.nuuu.com/trade" || RedirectUrl == "https://www.nuuu.com/trade/" {
			// if UrlsArr.CheckUrls(RedirectUrl) {
			// 	Zerologs.Info().Msg("GetTokenHandler(): USER LOGIN SUCCESSFULLY FOR MOBILE NO:=  " + clientdbData.MobileNo + " AT " + time.Now().Format("2006-01-02 15:04:05"))
			// 	return nil, err
			// } else {
			// 	token["url"] = RedirectUrl
			// 	Zerologs.Info().Msg("GetTokenHandler(): USER LOGIN SUCCESSFULLY FOR MOBILE NO:=  " + clientdbData.MobileNo + " AT " + time.Now().Format("2006-01-02 15:04:05"))
			// 	return token, nil
			// }
			ResponseModel.IsErr = false
			ResponseModel.StatusCode = http.StatusOK
			ResponseModel.AccessToken = token.AccessToken
			ResponseModel.RefreshToken = token.RefreshToken
			ResponseModel.Url = token.Url
			return ResponseModel
		}
	} else {
		// token["refresh_token"] = clientdbData.Refreshtoken
		//token["login"] = "success" //for jmeter testing
		ResponseModel.IsErr = false
		ResponseModel.StatusCode = http.StatusOK
		ResponseModel.Url = "/sign/setpassword?state=" + RetrievedState
		return ResponseModel
	}
}
