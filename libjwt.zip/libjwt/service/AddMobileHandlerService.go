package service

import (
	"net/http"
	"time"

	"github.com/MACMREPO/libdb/clientmaster"
	"github.com/MACMREPO/libjwt/helper"
	"github.com/MACMREPO/libjwt/model"
	"github.com/google/uuid"
)

func AddMobileHandlerService(RetrievedState string, mobilemodel model.MobileModel) model.RegisterUserResponseModel {
	var ResponseModel model.RegisterUserResponseModel

	// val, err := RedisLib.Client.Get(RetrievedState).Result()
	val, err := getDataFromRedis(RetrievedState)
	if err != nil {
		Zerologs.Error().Msg("AddMobileHandler(): UserGUID[val] not getting from redis using retrivedState for mobileNo=  " + mobilemodel.Mobileno + err.Error())
		ResponseModel.IsErr = true
		ResponseModel.Msg = err.Error()
		ResponseModel.StatusCode = http.StatusInternalServerError
		return ResponseModel
	}
	// RedirectUrl, err := RedisLib.Client.Get(RetrievedState + "-RedirectUrl").Result()
	// if err != nil {
	// 	Zerologs.Error().Msg("AddMobileHandler(): RedirectUrl not getting from redis by using retrieved state for user mobileNo:= " + RetrievedState + err.Error())
	// 	return nil, err
	// }
	// var clientdbData clientmaster.JwtAuthMaster
	// err = Db.Client.Where("user_guid=?", val).First(&clientdbData).Error
	clientdbData, err := getJwtAuthMasterDB(helper.CLIENT_USERGUID, val)
	if err != nil {
		ResponseModel.IsErr = true
		ResponseModel.Msg = err.Error()
		ResponseModel.StatusCode = http.StatusInternalServerError
		return ResponseModel
	}
	// token := make(map[string]string)
	// var MobEmail clientmaster.TblMobileEmailMapping
	// err = Db.Client.Where("mobile_no=?", mobilemodel.Mobileno).First(&MobEmail).Error
	MobEmail, err := getTblMobileEmailMapping(helper.CLIENT_MOBILE_PARAM, mobilemodel.Mobileno)
	if err != nil {
		resp := Verify_OTP(mobilemodel.Mobileno, mobilemodel.OTP)
		if !resp.IsErr {
			// var emailMap clientmaster.TblMobileEmailMapping
			// err = Db.Client.Where("email= ?", clientdbData.Email).First(&emailMap).Error
			_, err := getTblMobileEmailMapping(helper.CLIENT_EMAIL_PARAM, clientdbData.Mobileno)
			if err == nil {
				Zerologs.Error().Msg("AddMobileHandler(): Email is already registered= " + clientdbData.Email + err.Error())
				// token["errMsg"] = "Email is already registered"
				ResponseModel.IsErr = true
				ResponseModel.Msg = "Email is already registered"
				ResponseModel.StatusCode = http.StatusInternalServerError
				return ResponseModel
			}
			MobEmail.MobileNo = mobilemodel.Mobileno
			MobEmail.Email = clientdbData.Email
			MobEmail.EmailVerified = true
			err = Db.Client.Create(&MobEmail).Error
			if err != nil {
				Zerologs.Error().Msg(" AddMobileHandler(): error while executing query : Db.Client.Create(&MobEmail)" + err.Error())
				ResponseModel.IsErr = true
				ResponseModel.Msg = err.Error()
				ResponseModel.StatusCode = http.StatusInternalServerError
				return ResponseModel
			}
			// val, err := RedisLib.Client.Get(RetrievedState).Result()
			val, err := getDataFromRedis(RetrievedState)
			if err != nil {
				Zerologs.Error().Msg("AddMobileHandler(): UserGUID[val] not getting from redis using retrivedState for mobileNo=  " + mobilemodel.Mobileno + err.Error())
				ResponseModel.IsErr = true
				ResponseModel.Msg = err.Error()
				ResponseModel.StatusCode = http.StatusInternalServerError
				return ResponseModel
			}

			// var clientdbData clientmaster.JwtAuthMaster
			// err = Db.Client.Where("user_guid=?", val).First(&clientdbData).Error
			clientdbData, err := getJwtAuthMasterDB(helper.CLIENT_USERGUID, val)
			if err != nil {
				Zerologs.Error().Msg("AddMobileHandler():User detalis not found where user_guid:= " + val + err.Error())
				ResponseModel.IsErr = true
				ResponseModel.Msg = err.Error()
				ResponseModel.StatusCode = http.StatusInternalServerError
				return ResponseModel
			}

			var UserGUID uuid.UUID
			// var guidData clientmaster.MobileGuidMaster
			// err = Db.Client.Where("mobile_no=?", mobilemodel.Mobileno).First(&guidData).Error
			guidData, err := getMobileGuidMaster(mobilemodel.Mobileno)
			if err != nil {
				UserGUID = uuid.New()
				guidData.UserGuid = UserGUID
				guidData.MobileNo = mobilemodel.Mobileno
				err = Db.Client.Create(&guidData).Error
				if err != nil {
					Zerologs.Error().Msg("AddMobileHandler():= Error occured in query Db.Client.Create(&guidData) " + err.Error())
					ResponseModel.IsErr = true
					ResponseModel.Msg = err.Error()
					ResponseModel.StatusCode = http.StatusInternalServerError
					return ResponseModel
				}
			} else {
				UserGUID = guidData.UserGuid
			}
			clientdbData.MobileNo = mobilemodel.Mobileno
			// err = Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("user_guid=?", val).Updates(clientmaster.JwtAuthMaster{MobileNo: mobilemodel.Mobileno, MobileVerified: true, Password: mobilemodel.Password, UserGuid: helper.UuidToString(UserGUID), IsPasswordReset: true}).Error
			clientmasterData := clientmaster.JwtAuthMaster{MobileNo: mobilemodel.Mobileno, MobileVerified: true, Password: mobilemodel.Password, UserGuid: helper.UuidToString(UserGUID), IsPasswordReset: true}
			err = updateJWTAuthMasterModel(helper.CLIENT_USERGUID, clientmasterData)
			if err != nil {
				Zerologs.Error().Msg(" AddMobileHandler():= Error in update query where user_guid:= " + val + err.Error())
				ResponseModel.IsErr = true
				ResponseModel.Msg = err.Error()
				ResponseModel.StatusCode = http.StatusInternalServerError
				return ResponseModel
			}

			// var jwtauthmaster clientmaster.JwtAuthMaster
			// err = Db.Client.Where("mobile_no=?", mobilemodel.Mobileno).First(&jwtauthmaster).Error
			_, err = getJwtAuthMasterDB(helper.CLIENT_MOBILE_PARAM, mobilemodel.Mobileno)
			if err != nil {
				Zerologs.Error().Msg(" AddMobileHandler(): User details not found in JwtAuthMaster where mobile_no:=  " + mobilemodel.Mobileno + err.Error())
				ResponseModel.IsErr = true
				ResponseModel.Msg = err.Error()
				ResponseModel.StatusCode = http.StatusInternalServerError
				return ResponseModel
			}

			var passwordhistory clientmaster.PasswordHistory
			passwordhistory.MobileNo = mobilemodel.Mobileno
			passwordhistory.LastPassword = mobilemodel.Password
			passwordhistory.LastPassword_UpdatedTime = time.Now()
			err = Db.Client.Create(&passwordhistory).Error
			if err != nil {
				Zerologs.Error().Msg("AddMobileHandler(): Db.Client.Create(&passwordhistory) failed for mobileNo: " + mobilemodel.Mobileno + err.Error())
				ResponseModel.IsErr = true
				ResponseModel.Msg = err.Error()
				ResponseModel.StatusCode = http.StatusInternalServerError
				return ResponseModel
			}

			// err = AddWatchList(mobilemodel.Mobileno)
			// if err != nil {
			// 	Zerologs.Error().Msg("AddMobileHandler(): Watchlist not added for mobileNo: " + mobilemodel.Mobileno + err.Error())
			// 	return ResponseModel, err
			// }

			// var socialData model.SocialModel
			// socialData.GUID = UserGUID
			// socialData.Mobileno = mobilemodel.Mobileno
			// socialData.Email = clientdbData.Email
			// socialData.ID = clientdbData.ID
			// if clientdbData.Name == "" {
			// 	socialData.Name = mobilemodel.Mobileno
			// } else {
			// 	socialData.Name = clientdbData.Name
			// }
			// socialData.Username = mobilemodel.Mobileno
			// socialData.Password = mobilemodel.Password
			// socialData.Avatar = ""

			// err = AddSociaInfo(socialData)
			// if err != nil {
			// 	Zerologs.Error().Msg("AddMobileHandler():Social data not added for mobileNo: " + mobilemodel.Mobileno + err.Error())
			// 	return
			// }

			// KycApi(mobilemodel.Mobileno, clientdbData.Email)

			if clientdbData.KYCDone {
				// if clientdbData.MobileNo == "9673780788" {
				// 	var greenWareReq model.GreenwareRequestModel
				// 	greenWareReq.SsoBy = "mobile+user_type"
				// 	greenWareReq.Param1 = clientdbData.MobileNo
				// 	greenWareReq.Param2 = 1
				// 	mfaccesstoken := GreenWareLoginService(greenWareReq)
				// 	if mfaccesstoken != "" {
				// 		Zerologs.Info().Msg("AddMobileHandler() : User " + clientdbData.MobileNo + " successfully login to greenware " + " AT " + time.Now().Format("2006-01-02 15:04:05"))
				// 		token["mftoken"] = mfaccesstoken
				// 	} else {
				// 		token["mftoken"] = mfaccesstoken
				// 	}
				// }
				if clientdbData.Activated {
					if clientdbData.IsMPIN_Reset == false {
						// token["url"] = "/sign/setmpin?state=" + RetrievedState
						ResponseModel.IsErr = false
						ResponseModel.Url = "/sign/setmpin?state=" + RetrievedState
						ResponseModel.StatusCode = http.StatusOK
						return ResponseModel
					}
					// loginModel := model.HyperLoginmodel{
					// 	UID:        clientdbData.ClientID,
					// 	Pwd:        mobilemodel.Pwd,
					// 	BrokerID:   mobilemodel.BrokerID,
					// 	Source:     mobilemodel.Source,
					// 	DeviceName: mobilemodel.DeviceName,
					// 	DeviceInfo: mobilemodel.DeviceInfo,
					// }
					// key, IsMPINRequired, err := HypersyncLogin(loginModel)
					// if err == nil {
					// token["devicekey"] = key
					// if IsMPINRequired {
					// token["url"] = "/sign/mpin?state=" + RetrievedState
					ResponseModel.IsErr = false
					ResponseModel.Url = "/sign/mpin?state=" + RetrievedState
					ResponseModel.StatusCode = http.StatusOK
					// }
					// }
					return ResponseModel
				} else {
					if clientdbData.IsMPIN_Reset == false {
						// token["url"] = "/sign/setmpin?state=" + RetrievedState
						ResponseModel.IsErr = false
						ResponseModel.Url = "/sign/setmpin?state=" + RetrievedState
						ResponseModel.StatusCode = http.StatusOK
						return ResponseModel
					}
					// token["url"] = "/sign/mpin?state=" + RetrievedState
					ResponseModel.IsErr = false
					ResponseModel.Url = "/sign/mpin?state=" + RetrievedState
					ResponseModel.StatusCode = http.StatusOK
					return ResponseModel
				}
			} else {
				token, err := GenerateJWTWithRefresh(mobilemodel.Mobileno, clientdbData.Email, "") //Samir Pending
				if err != nil {
					Zerologs.Error().Msg("AddMobileHandler(): GenerateJWTWithRefresh() token not generated for mobileNo:= " + mobilemodel.Mobileno + " AND email:= " + clientdbData.Email + err.Error())
					ResponseModel.IsErr = true
					ResponseModel.Msg = err.Error()
					ResponseModel.StatusCode = http.StatusInternalServerError
					return ResponseModel
				}
				// if RedirectUrl == "" || RedirectUrl == "https://www.nuuu.com/trade" || RedirectUrl == "https://www.nuuu.com/trade/" {
				// if UrlsArr.CheckUrls(RedirectUrl) {
				// 	token["url"] = Env.GOOGLE_MAIN_PAGE
				// 	// fmt.Println("KycFalse Redirect URL=", token["url"])
				// 	return token, nil
				// } else {
				// 	token["url"] = RedirectUrl
				// 	// fmt.Println("KycFalse Redirect URL=", token["url"])
				// 	return token, nil
				// }
				ResponseModel.IsErr = false
				ResponseModel.AccessToken = token.AccessToken
				ResponseModel.RefreshToken = token.RefreshToken
				ResponseModel.Url = token.Url
				ResponseModel.StatusCode = http.StatusOK
				return ResponseModel
			}
		} else {
			// token["errMsg"] = resp["errMsg"]
			ResponseModel.IsErr = true
			ResponseModel.Msg = resp.Msg
			ResponseModel.StatusCode = http.StatusInternalServerError
			return ResponseModel
		}
	} else {
		resp := Verify_OTP(mobilemodel.Mobileno, mobilemodel.OTP)
		if !resp.IsErr {
			// var emailMob clientmaster.TblMobileEmailMapping
			// err = Db.Client.Where("email=?", clientdbData.Email).First(&emailMob).Error
			emailMob, err := getTblMobileEmailMapping(helper.CLIENT_EMAIL_PARAM, clientdbData.Email)
			if err != nil {
				emailMob.MobileNo = mobilemodel.Mobileno
				emailMob.Email = clientdbData.Email
				emailMob.EmailVerified = true
				err = Db.Client.Create(&emailMob).Error
				if err != nil {
					Zerologs.Error().Msg("AddMobileHandler(): Error while executing query= Db.Client.Create(&MobEmail) for user mobileNo= " + mobilemodel.Mobileno + err.Error())
					ResponseModel.IsErr = true
					ResponseModel.Msg = err.Error()
					ResponseModel.StatusCode = http.StatusInternalServerError
					return ResponseModel
				}
				// var JwtUser clientmaster.JwtAuthMaster
				// Db.Client.Where("email=?", clientdbData.Email).Delete(&JwtUser)
				deleteJwtAuthMasterDB(helper.CLIENT_EMAIL_PARAM, clientdbData.Email)

				// refreshToken := token["refresh_token"]
				// err = Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", mobilemodel.Mobileno).Update("refreshtoken", refreshToken).Error
				// if err != nil {
				// 	Zerologs.Error().Msg("AddMobileHandler(): error in query for update refreshToken where mobile_no:  " + mobilemodel.Mobileno + err.Error())
				// 	return ResponseModel, err
				// }

				// var UserDetails clientmaster.JwtAuthMaster
				// err = Db.Client.Where("mobile_no=?", mobilemodel.Mobileno).First(&UserDetails).Error
				UserDetails, err := getJwtAuthMasterDB(helper.CLIENT_MOBILE_PARAM, mobilemodel.Mobileno)
				if err != nil {
					Zerologs.Error().Msg("AddMobileHandler(): UserDetails not found in JwtAuthMaster for mobile = " + mobilemodel.Mobileno + err.Error())
					ResponseModel.IsErr = true
					ResponseModel.Msg = err.Error()
					ResponseModel.StatusCode = http.StatusInternalServerError
					return ResponseModel
				}
				if UserDetails.KYCDone {
					// if clientdbData.MobileNo == "9673780788" {
					// 	var greenWareReq model.GreenwareRequestModel
					// 	greenWareReq.SsoBy = "mobile+user_type"
					// 	greenWareReq.Param1 = clientdbData.MobileNo
					// 	greenWareReq.Param2 = 1
					// 	mfaccesstoken := GreenWareLoginService(greenWareReq)
					// 	if mfaccesstoken != "" {
					// 		Zerologs.Info().Msg("AddMobileHandler() : User " + clientdbData.MobileNo + " successfully login to greenware " + " AT " + time.Now().Format("2006-01-02 15:04:05"))
					// 		token["mftoken"] = mfaccesstoken
					// 	} else {
					// 		token["mftoken"] = mfaccesstoken
					// 	}
					// }
					if UserDetails.Activated {
						if UserDetails.IsMPIN_Reset {
							// token["url"] = "/sign/setmpin?state=" + RetrievedState
							ResponseModel.IsErr = false
							ResponseModel.Url = "/sign/setmpin?state=" + RetrievedState
							ResponseModel.StatusCode = http.StatusOK
							return ResponseModel
						}
						// loginModel := model.HyperLoginmodel{
						// 	UID:        UserDetails.ClientID,
						// 	Pwd:        mobilemodel.Pwd,
						// 	BrokerID:   mobilemodel.BrokerID,
						// 	Source:     mobilemodel.Source,
						// 	DeviceName: mobilemodel.DeviceName,
						// 	DeviceInfo: mobilemodel.DeviceInfo,
						// }
						// key, IsMPINRequired, err := HypersyncLogin(loginModel)
						// if err == nil {
						// 	token["devicekey"] = key
						// if IsMPINRequired {
						// token["url"] = "/sign/mpin?state=" + RetrievedState
						ResponseModel.IsErr = false
						ResponseModel.Url = "/sign/mpin?state=" + RetrievedState
						ResponseModel.StatusCode = http.StatusOK
						// }
						// }
						return ResponseModel
					} else {
						if UserDetails.IsMPIN_Reset == false {
							// token["url"] = "/sign/setmpin?state=" + RetrievedState
							ResponseModel.IsErr = false
							ResponseModel.Url = "/sign/setmpin?state=" + RetrievedState
							ResponseModel.StatusCode = http.StatusOK
							return ResponseModel
						}
						// token["url"] = "/sign/mpin?state=" + RetrievedState
						ResponseModel.IsErr = false
						ResponseModel.Url = "/sign/mpin?state=" + RetrievedState
						ResponseModel.StatusCode = http.StatusOK
						return ResponseModel
					}
				} else {
					token, err := GenerateJWTWithRefresh(mobilemodel.Mobileno, clientdbData.Email, "")
					if err != nil {
						Zerologs.Error().Msg("AddMobileHandler():GenerateJWTWithRefresh ,Token not generated for mobileNo=  " + mobilemodel.Mobileno + "AND email:=  " + clientdbData.Email + err.Error())
						ResponseModel.IsErr = true
						ResponseModel.Msg = err.Error()
						ResponseModel.StatusCode = http.StatusInternalServerError
						return ResponseModel
					}
					// if RedirectUrl == "" || RedirectUrl == "https://www.nuuu.com/trade" || RedirectUrl == "https://www.nuuu.com/trade/" {
					// if UrlsArr.CheckUrls(RedirectUrl) {
					// 	token["url"] = Env.GOOGLE_MAIN_PAGE
					// 	// fmt.Println("KycFalse Redirect URL=", token["url"])
					// 	return token, nil
					// } else {
					// 	token["url"] = RedirectUrl
					// 	// fmt.Println("KycFalse Redirect URL=", token["url"])
					// 	return token, nil
					// }
					ResponseModel.IsErr = false
					ResponseModel.AccessToken = token.AccessToken
					ResponseModel.RefreshToken = token.RefreshToken
					ResponseModel.Url = token.Url
					ResponseModel.StatusCode = http.StatusOK
					return ResponseModel
				}
			} else {
				// token["errMsg"] = "Mobile Number is already registered with same email"
				ResponseModel.IsErr = true
				ResponseModel.Msg = "Mobile Number is already registered with same email"
				ResponseModel.StatusCode = http.StatusInternalServerError
				return ResponseModel
			}
		} else {
			// token["errMsg"] = resp["errMsg"]
			ResponseModel.IsErr = true
			ResponseModel.Msg = resp.Msg
			ResponseModel.StatusCode = http.StatusInternalServerError
			return ResponseModel
		}
	}
}
