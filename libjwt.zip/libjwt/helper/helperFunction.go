package helper

import (
	"net/mail"
	"strconv"

	"github.com/google/uuid"
)

func UIntToString(ID uint) string {
	return strconv.FormatUint(uint64(ID), 10)
}

func UuidToString(ID uuid.UUID) string {
	return ID.String()
}

func StringToUuid(guid string) (uuid.UUID, error) {
	return uuid.Parse(guid)
}
func CheckUserType(UserName string) (int, error) {
	if _, err := strconv.Atoi(UserName); err == nil {
		return CLIENT_MOBILE_PARAM, err
	} else {
		if _, err := mail.ParseAddress(UserName); err == nil {
			return CLIENT_EMAIL_PARAM, err
		} else {
			return CLIENT_ID_PARAM, err

		}
	}
}
