package controller

import (
	"net/http"
	"strconv"

	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/gin"
)

func FingerPrint_Login(c *gin.Context) {
	libhttp.CoreHeader(c)
	skey := c.Request.Header.Get("refresh_token")
	// MobileNo, err := service.RedisLib.Client.Get(skey).Result()
	// if err != nil {
	// 	// fmt.Println(err)
	// 	service.Zerologs.Error().Err(err).Msg("FingerPrint_Login(): Error in Getting data from redis for skey = " + skey)
	// 	c.JSON(http.StatusUnauthorized, "Unauthorized")
	// 	return
	// }
	c.Request.Header.Set("Authorization", "Bearer "+skey)
	MobileNo, err := service.GetUser(c)
	if err != nil {
		service.Zerologs.Error().Err(err).Msg("GetAccessToken(): Error in GetUser")
		c.JSON(http.StatusUnauthorized, "Unauthorized")
		return
	}
	mobileno := strconv.FormatUint(uint64(MobileNo), 10)
	response := service.FingerPrintLoginService(mobileno)
	c.JSON(response.StatusCode, response)
}
