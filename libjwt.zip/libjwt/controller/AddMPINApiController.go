package controller

import (
	"github.com/gin-gonic/gin"
)

func AddMPINApiHandler(c *gin.Context) {
	// libhttp.CoreHeader(c)
	// session := sessions.Default(c)
	// retrievedState := session.Get("state")
	// cquery := c.Query("state")
	// if retrievedState != cquery {
	// 	// fmt.Println("add MPINHAndeler " + retrievedState.(string) + " -- " + cquery)
	// 	service.Zerologs.Error().Msg("AddMPINApiHandler():retrievedState and cquery is not equal:=  " + retrievedState.(string) + " -- " + cquery)
	// 	// c.AbortWithError(http.StatusUnauthorized, fmt.Errorf("Invalid session state: %s", retrievedState))
	// 	// return
	// }
	// var mpinmodel model.MpinModel
	// err := c.BindJSON(&mpinmodel)
	// if err != nil {
	// 	service.Zerologs.Error().Msg("AddMPINApiHandler():Error while json binding model= " + mpinmodel.BrokerID + mpinmodel.Mpin + mpinmodel.UID + mpinmodel.DeviceInfo + mpinmodel.DeviceName + err.Error())
	// 	c.JSON(http.StatusBadRequest, err.Error())
	// 	return
	// }
	// if retrievedState == nil {
	// 	service.Zerologs.Info().Msg("AddMPINApiHandler(): RetrievedState is null ")
	// 	return
	// }
	// RetrievedState := retrievedState.(string)

	// response, err := service.AddMPINApiHandlerService(RetrievedState, mpinmodel)
	// if err != nil {
	// 	c.JSON(http.StatusInternalServerError, err.Error())
	// 	return
	// }
	// result, ok := response["errMsg"]
	// if ok {
	// 	c.JSON(500, result)
	// 	return
	// }
	// c.JSON(200, response)

}
