package model

import "github.com/google/uuid"

type MobileGuidModel struct {
	MobileNo string    `json:"mobile_no"`
	UserGuid uuid.UUID `json:"user_guid"`
}
