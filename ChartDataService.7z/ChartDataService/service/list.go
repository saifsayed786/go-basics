package service

type Node struct {
	value interface{}
	next  *Node
	fp    func(interface{})
}
type LinkedList struct {
	head *Node
	last *Node
}

func (l *LinkedList) Insert(val interface{}, fp func(interface{})) {
	n := Node{}
	n.value = val
	n.fp = fp
	if l.head == nil {
		l.head = &n
		l.last = &n
		return
	}
	l.last.next = &n
	l.last = &n
}
