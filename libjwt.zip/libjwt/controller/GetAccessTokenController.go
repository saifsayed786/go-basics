package controller

import (
	"net/http"

	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/gin"
)

func GetAccessToken(c *gin.Context) {
	libhttp.CoreHeader(c)
	refreshToken := c.Request.Header.Get("refresh_token")

	response, err := service.GetAccessTokenService(c, refreshToken)
	if err != nil {
		c.JSON(http.StatusInternalServerError, err)
		return
	}
	if response["errMsg"] != "" {
		c.JSON(http.StatusInternalServerError, response)
		return
	}
	c.JSON(http.StatusOK, response)

}

func GetAccessTokenOnRefreshToken(c *gin.Context) {
	libhttp.CoreHeader(c)
	refreshToken := c.Request.Header.Get("refresh_token")
	response, err := service.GetAccessTokenOnRefreshTokenService(c, refreshToken)
	if err != nil {
		c.JSON(http.StatusInternalServerError, err)
		return
	}
	if response["errMsg"] != "" {
		c.JSON(http.StatusInternalServerError, response)
		return
	}
	c.JSON(http.StatusOK, response)
}
