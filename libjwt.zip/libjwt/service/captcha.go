package service

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"image/png"
	"net/http"
	"os"

	"github.com/MACMREPO/libdb/clientmaster"
	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/model"
	"github.com/dchest/captcha"
	"github.com/gin-gonic/contrib/sessions"
	"github.com/gin-gonic/gin"
)

var (
	// ErrNotFound = errors.New("captcha: id not found")
	store = captcha.NewMemoryStore(captcha.CollectNum, captcha.Expiration)
)

func CreateCaptcha(input string) string {
	rndmNum := captcha.RandomDigits(6)
	id := input
	store.Set(id, rndmNum)
	captcha.SetCustomStore(store)
	image := captcha.NewImage(id, rndmNum, 280, 40)
	var buf bytes.Buffer
	png.Encode(&buf, image)
	imgBase64Str := base64.StdEncoding.EncodeToString(buf.Bytes())
	return imgBase64Str
}

func VerifyCaptcha_Web(c *gin.Context) {
	libhttp.CoreHeader(c)
	session := sessions.Default(c)
	retrievedState := session.Get("state")
	if retrievedState == nil {
		Zerologs.Info().Msg("VerifyCaptcha_Web(): RetriveState is Nil")
		return
	}
	cquery := c.Query("state")
	if retrievedState != cquery {
		// Zerologs.Info().Msg("VerifyCaptcha_Web(): Invalid session state " + retrievedState.(string))
	}
	RetrievedState := retrievedState.(string)
	// id := RetrievedState
	var digitmodel model.VerifyCaptchaReqModel_Web
	err := c.BindJSON(&digitmodel)
	if err != nil {
		Zerologs.Error().Msg("VerifyCaptcha_Web(): Error while json binding model " + err.Error())
		c.JSON(http.StatusBadRequest, "")
		return
	}
	if digitmodel.Digits == "" {
		Zerologs.Error().Msg("VerifyCaptcha_Web(): captcha not entered" + err.Error())
		c.JSON(http.StatusInternalServerError, gin.H{"errMsg": "Please enter a captcha number"})
		return
	}

	// flag := captcha.VerifyString(digitmodel.MobileNo, digitmodel.Digits)
	flag := captcha.VerifyString(RetrievedState, digitmodel.Digits)
	if !flag {
		c.JSON(http.StatusInternalServerError, gin.H{"errMsg": "Invalid captcha"})
		return
	} else {
		updateOtpCount := make(map[string]interface{})
		updateOtpCount["otp_attempt"] = 0
		err = Db.Client.Model(&clientmaster.TblMobileOtp{}).Where("mobile_no=?", digitmodel.MobileNo).Updates(updateOtpCount).Error
		if err != nil {
			Zerologs.Error().Msg("VerifyCaptcha_Web():otp_attempt not set to zero, update query failed where mobile_no:=   " + digitmodel.MobileNo + err.Error())
			return
		}
		var OtpModel model.GenerateOTPModel
		OtpModel.MobileNo = digitmodel.MobileNo
		OtpModel.Type = uint(digitmodel.Type)
		json_data, err := json.Marshal(OtpModel)
		if err != nil {
			Zerologs.Error().Msg("VerifyCaptcha_Web(): json.Marshal(OtpModel) failed for user " + OtpModel.MobileNo + err.Error())
			return
		}
		sStage := os.Getenv("STAGE")
		Ssopath := ""
		if sStage == "" {
			Ssopath = BaseUrl
		} else {
			Ssopath = "http://gojwtservice-" + sStage + "-service:8085"
		}
		resp, err := http.Post(Ssopath+"/sign/sendmobileotp", "application/json", //hardcoded url need to be changed
			bytes.NewBuffer(json_data))
		if err != nil {
			Zerologs.Error().Msg("VerifyCaptcha_Web(): Generate api call failed for user " + OtpModel.MobileNo + err.Error())
			c.JSON(http.StatusInternalServerError, err)
			return
		}
		var res map[string]interface{}
		err = json.NewDecoder(resp.Body).Decode(&res)
		if err != nil {
			Zerologs.Error().Msg("VerifyCaptcha_Web(): json.NewDecoder(resp.Body).Decode(&res) failed for user " + OtpModel.MobileNo + err.Error())
			c.JSON(http.StatusInternalServerError, err)
			return
		}
		if resp.StatusCode == http.StatusOK {
			c.JSON(http.StatusOK, res)
		} else {
			c.JSON(500, res)
		}
	}

}
func ReloadCaptcha_Web(c *gin.Context) {
	libhttp.CoreHeader(c)
	// var reloadCaptcha model.ReloadCaptchaReqModel_Web
	// err := c.BindJSON(&reloadCaptcha)
	// if err != nil {
	// 	Zerologs.Error().Msg("ReloadCaptcha_Web(): Error while json binding model " + err.Error())
	// 	c.JSON(http.StatusBadRequest, "")
	// 	return
	// }
	session := sessions.Default(c)
	retrievedState := session.Get("state")
	if retrievedState == nil {
		Zerologs.Info().Msg("ReloadCaptcha(): RetriveState is Nil")
		return
	}

	// cquery := c.Query("state")
	// if retrievedState != cquery {
	// 	Zerologs.Info().Msg("ReloadCaptcha(): Invalid session state " + retrievedState.(string))
	// 	// c.AbortWithError(http.StatusUnauthorized, fmt.Errorf("Invalid session state: %s", retrievedState))
	// 	// return
	// }
	RetrievedState := retrievedState.(string)
	imgBase64Str := CreateCaptcha(RetrievedState)
	// imgBase64Str := CreateCaptcha(reloadCaptcha.MobileNo)
	c.JSON(http.StatusOK, gin.H{"newimg": imgBase64Str})
}

func VerifyCaptcha_Mob(c *gin.Context) {
	libhttp.CoreHeader(c)
	var reqModel model.VerifyCaptchaReqModel_Mob
	err := c.BindJSON(&reqModel)
	if err != nil {
		Zerologs.Error().Msg("VerifyCaptcha_Mob(): Error while json binding model " + err.Error())
		c.JSON(http.StatusBadRequest, "")
		return
	}
	if reqModel.Digits == "" {
		Zerologs.Error().Msg("VerifyCaptcha_Mob(): captcha not entered" + err.Error())
		c.JSON(http.StatusInternalServerError, gin.H{"errMsg": "Please enter a captcha number"})
		return
	}

	flag := captcha.VerifyString(reqModel.DeviceId, reqModel.Digits)
	if !flag {
		c.JSON(http.StatusInternalServerError, gin.H{"errMsg": "Invalid captcha"})
		return
	} else {
		updateOtpCount := make(map[string]interface{})
		updateOtpCount["otp_attempt"] = 0
		err = Db.Client.Model(&clientmaster.TblMobileOtp{}).Where("mobile_no=?", reqModel.MobileNo).Updates(updateOtpCount).Error
		if err != nil {
			Zerologs.Error().Msg("VerifyCaptcha_Mob():otp_attempt not set to zero, update query failed where mobile_no:=   " + reqModel.MobileNo + err.Error())
			return
		}
		var OtpModel model.GenerateOTPModel
		OtpModel.MobileNo = reqModel.MobileNo
		OtpModel.Type = uint(reqModel.Type)
		bytejson, err := json.Marshal(OtpModel)
		if err != nil {
			Zerologs.Error().Msg("VerifyCaptcha_Mob(): json.Marshal(OtpModel) failed for user " + OtpModel.MobileNo + err.Error())
			return
		}
		sStage := os.Getenv("STAGE")
		Ssopath := ""
		if sStage == "" {
			Ssopath = BaseUrl
		} else {
			Ssopath = "http://gojwtservice-" + sStage + "-service:8085"
		}
		resp, err := http.Post(Ssopath+"/sign/sendmobileotp", "application/json", //hardcoded url need to be changed
			bytes.NewBuffer(bytejson))
		if err != nil {
			Zerologs.Error().Msg("VerifyCaptcha_Mob(): Generate api call failed for user " + OtpModel.MobileNo + err.Error())
			c.JSON(http.StatusInternalServerError, err)
			return
		}
		var res map[string]interface{}
		err = json.NewDecoder(resp.Body).Decode(&res)
		if err != nil {
			Zerologs.Error().Msg("VerifyCaptcha_Mob():json.NewDecoder(resp.Body).Decode(&res) failed for user " + OtpModel.MobileNo + err.Error())
			c.JSON(http.StatusInternalServerError, err)
			return
		}
		if resp.StatusCode == http.StatusOK {
			c.JSON(http.StatusOK, res)
		} else {
			c.JSON(500, res)
		}
	}
}

func ReloadCaptcha_Mob(c *gin.Context) {
	libhttp.CoreHeader(c)
	var reloadModel model.ReloadCaptchaReqModel_Mob
	err := c.BindJSON(&reloadModel)
	if err != nil {
		Zerologs.Error().Msg("ReloadCaptcha_Mob(): c.BindJSON(&reloadModel) failed " + err.Error())
		c.JSON(http.StatusBadRequest, "")
		return
	}
	imgBase64Str := CreateCaptcha(reloadModel.DeviceId)
	c.JSON(http.StatusOK, gin.H{"newimg": imgBase64Str})
}
