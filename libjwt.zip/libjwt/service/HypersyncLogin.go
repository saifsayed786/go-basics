package service

import (
	"bytes"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"errors"
	"io/ioutil"
	"net/http"

	"github.com/MACMREPO/libjwt/model"
)

var (
	hash   = sha256.New()
	random = rand.Reader
)

func NewHyperSyncLogin(logindata model.HypersyncModel) (string, error) {
	// var obj HypersyncModel
	// obj.Uid = logindata.UID           // "ABC001-NIT"
	// obj.BrokerId = logindata.BrokerID // "NIT"
	// obj.System = logindata.BrokerID   // "NIT"

	msg, _ := json.Marshal(logindata)
	// fmt.Println(string(msg))
	Zerologs.Info().Msg("NewHyperSyncLogin(): HypersyncModel = " + string(msg) + " for UserId = " + logindata.Uid)
	decodestr, err := base64.StdEncoding.DecodeString(Env.HS_PUBLIC_KEY)
	if err != nil {
		Zerologs.Error().Msg("NewHyperSyncLogin(): Error in Publickey DecodeString is " + err.Error())
		return "", err
	}

	pubKeyBlock, _ := pem.Decode(decodestr)
	pub, err := x509.ParsePKCS1PublicKey(pubKeyBlock.Bytes)
	if err != nil {
		Zerologs.Error().Msg("NewHyperSyncLogin(): Error in Publickey ParsePKCS1PublicKey is " + err.Error())
		// fmt.Println("Load public key error")
		// panic(err)
		return "", err
	}
	encryptedData, encryptErr := rsa.EncryptOAEP(hash, random, pub, msg, nil)
	if encryptErr != nil {
		Zerologs.Error().Msg("NewHyperSyncLogin(): Error in EncryptOAEP data is " + err.Error())
		// fmt.Println("Encrypt data error")
		// panic(encryptErr)
		return "", err
	}
	base64str := base64.URLEncoding.EncodeToString(encryptedData)
	// fmt.Println(base64str)
	// Zerologs.Info().Msg("NewHyperSyncLogin(): base64str = " + base64str)

	var HyperReq model.HyperSyncReqModel
	HyperReq.SystemName = logindata.BrokerId // "NIT"
	HyperReq.EncryptedData = base64str

	json_data, err := json.Marshal(HyperReq)
	if err != nil {
		Zerologs.Error().Msg("NewHyperSyncLogin(): Error in model.HyperSyncReqModel Marshal is " + err.Error())
		// fmt.Println(err)
		return "", err
	}
	// Zerologs.Info().Msg("NewHyperSyncLogin(): model.HyperSyncReqModel = " + string(json_data))

	req, err := http.NewRequest("POST", "http://192.168.5.170:8086/system/login", bytes.NewBuffer(json_data))
	if err != nil {
		Zerologs.Error().Err(err).Msg("NewHyperSyncLogin(): Http NewRequest Error is " + err.Error())
		// fmt.Print(err.Error())
		return "", err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("api-key", Env.HS_AUTH_KEY)

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		Zerologs.Error().Err(err).Msg("NewHyperSyncLogin(): Client DO error is " + err.Error())
		// fmt.Println(err)
		return "", err
	}

	jsonString, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		Zerologs.Error().Err(err).Msg("NewHyperSyncLogin(): Client DO response read error is " + err.Error())
		// fmt.Println(err)
		return "", err
	}
	// fmt.Println(string(jsonString))

	var HyperRes model.HyperResModel
	err = json.Unmarshal(jsonString, &HyperRes)
	if err != nil {
		Zerologs.Error().Err(err).Msg("NewHyperSyncLogin(): Error in model.HyperResModel Unmarshal is " + err.Error())
		// fmt.Println(err)
		return "", err
	}
	if HyperRes.Code != 200 {
		var HyperErrRes model.HyperErrResModel
		err = json.Unmarshal(jsonString, &HyperErrRes)
		if err != nil {
			Zerologs.Error().Err(err).Msg("NewHyperSyncLogin(): Error in model.HyperErrResModel Unmarshal is " + err.Error())
			// fmt.Println(err)
			return "", err
		}
		// fmt.Println(HyperErrRes)
		Zerologs.Info().Msg("NewHyperSyncLogin(): HyperErrRes message is " + HyperErrRes.Message + " for UserId = " + logindata.Uid)
		return "", errors.New(HyperErrRes.Message)
	}
	// Zerologs.Info().Msg("NewHyperSyncLogin(): HyperRes status is " + HyperRes.Data.Status + " and SessionKey is " + HyperRes.Data.SessionKey)
	return HyperRes.Data.SessionKey, nil
}
