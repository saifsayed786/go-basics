package controller

import (
	"net/http"

	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/model"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/gin"
)

func TaxBuddyHandler(c *gin.Context) {
	libhttp.CoreHeader(c)
	var SsbaModel model.SSBAModel
	err := c.BindJSON(&SsbaModel)
	if err != nil {
		service.Zerologs.Error().Msg("TaxBuddyHandler(): Error in BindJSON() SSBAModel: " + err.Error())
		c.JSON(http.StatusBadRequest, err)
		return
	}
	response, err := service.TaxBuddyHandlerService(SsbaModel)
	if err != nil {
		c.JSON(http.StatusInternalServerError, err)
		return
	}
	c.JSON(http.StatusOK, response)
}
