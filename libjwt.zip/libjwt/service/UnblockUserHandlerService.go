package service

import (
	"net/http"
	"time"

	"github.com/MACMREPO/libjwt/helper"
	"github.com/MACMREPO/libjwt/model"
)

func UnblockUserHandlerService(usermodel model.UnblockUser) model.UnblockUserResponse {
	var responseModel model.UnblockUserResponse
	resp := Verify_OTP(usermodel.MobileNo, usermodel.OTP)
	if resp.Msg == "Success" {
		response, _, _ := IsAlreadyRegister(usermodel.MobileNo)
		if !response {
			responseModel.IsErr = true
			responseModel.Msg = "Invalid username or password"
			responseModel.StatusCode = http.StatusInternalServerError
			return responseModel

		}
		// var EmailMap clientmaster.TblMobileEmailMapping
		// err := Db.Client.Where("mobile_no=? AND email=?", usermodel.MobileNo, usermodel.Email).First(&EmailMap).Error
		_, err := getEmailAndMobFromEmailMapping(usermodel.MobileNo, usermodel.Email)
		if err != nil {
			Zerologs.Error().Msg("UnblockUserHandler(): User email data not found for MobileNo=" + usermodel.MobileNo + " and Email=" + usermodel.Email + "and error is " + err.Error())
			responseModel.IsErr = true
			responseModel.Msg = "Wrong Email"
			responseModel.StatusCode = http.StatusInternalServerError
			return responseModel
		}
		// var User clientmaster.JwtAuthMaster
		// err = Db.Client.Where("mobile_no=?", usermodel.MobileNo).First(&User).Error
		_, err = getJwtAuthMasterDB(helper.CLIENT_MOBILE_PARAM, usermodel.MobileNo)
		if err != nil {
			Zerologs.Error().Msg("UnblockUserHandler(): user data not found in jwtauthmaster for mobileno=  " + usermodel.MobileNo + err.Error())
			responseModel.IsErr = true
			responseModel.Msg = "User Not Found"
			responseModel.StatusCode = http.StatusInternalServerError
			return responseModel

		}
		// if User.KYCDone {
		// 	if User.Pan == usermodel.Pan {
		updateData := make(map[string]interface{})
		updateData["password_failed_count"] = 0
		updateData["mpin_failed_count"] = 0
		// err = Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", usermodel.MobileNo).Updates(updateData).Error
		err = updateJWTAuthMaster(helper.CLIENT_MOBILE_PARAM, usermodel.MobileNo, updateData)
		if err != nil {
			Zerologs.Error().Msg("UnblockUserHandler(): Error in Update PasswordFailedCount in JwtAuthMaster for mobileno=" + usermodel.MobileNo + " and error is " + err.Error())
			responseModel.IsErr = true
			responseModel.Msg = err.Error()
			responseModel.StatusCode = http.StatusInternalServerError
			return responseModel
		}
		Zerologs.Info().Msg(" Mobileno: " + usermodel.MobileNo + "is unblock at = " + time.Now().Format("2006-01-02 15:04:05"))
		responseModel.IsErr = false
		responseModel.Msg = "User unblock successfully"
		responseModel.Url = "/sign/glogin"
		responseModel.StatusCode = http.StatusInternalServerError
		return responseModel

		// 	} else {
		// 		token["errMsg"] = "Wrong pan number entered"
		// 		return token,nil
		// 		return
		// 	}
		// } else {
		// 	err = Db.Client.Model(&clientmaster.JwtAuthMaster{}).Where("mobile_no=?", usermodel.MobileNo).Update("password_failed_count", 0).Error
		// 	if err != nil {
		// 		Zerologs.Error().Msg("UnblockUserHandler(): Error in Update PasswordFailedCount in JwtAuthMaster for mobileno=" + usermodel.MobileNo + " and error is " + err.Error())
		// 	}
		// 	Zerologs.Info().Msg("User unblock successfully for mobileno=  " + usermodel.MobileNo)
		// 	token["Msg"] = "User unblock successfully"
		// 	token["url"] = "/sign/glogin"
		// 	c.JSON(http.StatusOK, token)
		// }

	} else {
		// if token["otpCnt"] == "2" {
		// 	imgBase64Str := CreateCaptcha(usermodel.MobileNo)
		// 	token["img64"] = imgBase64Str
		// 	token["isOtp"] = "1"
		// 	return token,nil
		// 	return
		// } else {
		responseModel.IsErr = false
		responseModel.Msg = "User Not Registered"
		responseModel.StatusCode = http.StatusInternalServerError
		return responseModel
		// }
	}
}
