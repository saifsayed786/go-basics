package service

import (
	"bytes"
	"fmt"
	"io/ioutil"
	"log"
	"math/rand"
	"net/http"
	"os"
	"text/template"
	"time"

	"github.com/MACMREPO/libjwt/model"
	"github.com/golang-jwt/jwt"
	"github.com/golobby/container/v3"
	"github.com/rs/zerolog"
)

const OTPtemplateforNewNumber = "Use {{.OTP}} as OTP mobile verification code to complete NUUU KYC process. Please do not share your OTP with anyone. Regards, NUUU Team."

func RandomInt(n int) string {
	var letters = []rune("123456789")

	s := make([]rune, n)
	for i := range s {
		s[i] = letters[rand.Intn(len(letters))]
	}
	return string(s)
}

func SendSMSService(smstemplate string, receiver string, objSMSdata interface{}) error {
	var Zerologs zerolog.Logger
	if err := container.NamedResolve(&Zerologs, "zerologs"); err != nil {
		fmt.Println(err)
	}
	Zerologs.Info().Msg("In Send SendSMSService")
	buf := &bytes.Buffer{}
	err := template.Must(template.New("").Parse(smstemplate)).Execute(buf, objSMSdata)
	msg := buf.String()
	if err != nil {
		fmt.Println(err)
	}
	// data := url.Values{
	// 	"user":     {"mangalk"},
	// 	"password": {"mangal09a"},
	// 	"msisdn":   {receiver},
	// 	"sid":      {"MKFSLP"},
	// 	"msg":      {msg},
	// 	"fl":       {"0"},
	// 	"gwid":     {"2"},
	// }
	//uncomment after
	// smslink := ""
	// smslink := "https://mobile1.ssexpertsystem.com/vendorsms/pushsms.aspx"
	// smslink := fmt.Sprintf("http://api.ssexpertsystem.com/api/v2/SendSMS?SenderId=MKFSLP&Message=%s&MobileNumbers=%s&ApiKey=mangal09a&ClientId=mangalk", msg, receiver)
	smslink := fmt.Sprintf("http://api.ssexpertsystem.com/api/v2/SendSMS?SenderId=NUINTR&Message=%s&MobileNumbers=%s&ApiKey=hL88dikbBsX6heRwyhfPiMVHH7Rf4aJPYH2Mu87EVwQ=&ClientId=6c50df0d-1f9f-4dda-b558-86c08174299d", msg, receiver)
	// proxyReq, err := http.PostForm(smslink, data)

	// proxyReq, err := http.Get(smslink)
	// body, err := ioutil.ReadAll(proxyReq.Body)
	// if err != nil {
	// 	log.Fatalln(err)
	// }
	// //Convert the body to type string
	// sb := string(body)
	// log.Printf(sb)
	// fmt.Println(proxyReq)
	client := &http.Client{}
	req, err := http.NewRequest(http.MethodGet, smslink, nil)
	if err != nil {
		Zerologs.Error().Err(err).Msg("failed to read request Response body")

		log.Fatal(err)
	}

	// appending to existing query args
	q := req.URL.Query()

	// assign encoded query string to http request
	req.URL.RawQuery = q.Encode()

	resp, err := client.Do(req)
	if err != nil {
		fmt.Println("resp -->", resp)
		Zerologs.Error().Err(err).Msg("Errored when sending request to the server")

		fmt.Println("Errored when sending request to the server")

	}
	if resp != nil {
		defer resp.Body.Close()
		responseBody, err := ioutil.ReadAll(resp.Body)
		// Zerologs.Info().Msg("In ioutil.ReadAll")

		if err != nil {

			// log.Println(err)
			// fmt.Println(err)
			// fmt.Println(string(responseBody))
			Zerologs.Error().Err(err).Msg("failed to read request Response body")
			log.Fatal(err)
		}
		// Zerologs.Info().Msg("Out ioutil.ReadAll")

		// fmt.Println(resp.Status)
		fmt.Println(string(responseBody))
		Zerologs.Info().Msg("Out Send SendSMSService")
	}
	// fmt.Println(proxyReq.StatusCode, proxyReq.Status, proxyReq.Proto)
	return nil
}

func CreateToken(userid int, mobileno string) (*model.TokenDetails, error) {
	td := &model.TokenDetails{}
	td.AtExpires = time.Now().Add(time.Hour * 24).Unix()
	var err error
	//Creating Access Token
	os.Setenv("ACCESS_SECRET", "jdnfksdmfksd")
	atClaims := jwt.MapClaims{}
	atClaims["authorized"] = true
	// atClaims["access_uuid"] = td.AccessUuid
	atClaims["user_id"] = userid
	atClaims["mobile_no"] = mobileno
	atClaims["exp"] = td.AtExpires
	at := jwt.NewWithClaims(jwt.SigningMethodHS256, atClaims)
	td.AccessToken, err = at.SignedString([]byte(os.Getenv("ACCESS_SECRET")))
	if err != nil {
		return nil, err
	}
	return td, nil
}
