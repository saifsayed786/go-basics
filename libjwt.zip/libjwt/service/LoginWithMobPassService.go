package service

import (
	"net/http"
	"strconv"
	"time"

	"github.com/MACMREPO/libjwt/helper"
	"github.com/MACMREPO/libjwt/model"
)

func Login_Mobile(mobilemodel model.NormalLoginmodel) model.Login_Web {
	var responseModel model.Login_Web
	UserType, er := helper.CheckUserType(mobilemodel.UserName)
	if er == nil {
		res, count, mpincount := IsUserAlreadyRegister(UserType, mobilemodel.UserName)

		if !res {
			responseModel.IsKyc = false
			responseModel.IsActivated = false
			responseModel.IsErr = true
			if UserType == helper.CLIENT_MOBILE_PARAM {
				responseModel.Msg = "Mobile number " + mobilemodel.UserName + " not registered"
			} else if UserType == helper.CLIENT_EMAIL_PARAM {
				responseModel.Msg = "Email ID " + mobilemodel.UserName + " not registered"
			} else if UserType == helper.CLIENT_ID_PARAM {
				responseModel.Msg = "Client Code " + mobilemodel.UserName + " not registered"
			}
			return responseModel
		}
		if count >= Env.MAX_PASSWORD_ATTEMPT || mpincount >= Env.MAX_MPIN_ATTEMPT {
			responseModel.IsErr = false
			responseModel.Msg = "User is blocked"
			return responseModel
		}
		clientdbData, err := getClientByUserType(UserType, mobilemodel.UserName, mobilemodel.Password)
		if err != nil {
			Totalcount := count + 1
			updateData := make(map[string]interface{})
			updateData["password_failed_count"] = Totalcount
			err := updateJWTAuthMaster(UserType, mobilemodel.UserName, updateData)
			if err != nil {
				Zerologs.Error().Msg("password_failed_count update failed for UserName=" + mobilemodel.UserName + " and error is " + err.Error())
				responseModel.IsErr = true
				responseModel.Msg = err.Error()
				responseModel.StatusCode = http.StatusInternalServerError
				return responseModel
			}
			remainingAttemptCount := Env.MAX_PASSWORD_ATTEMPT - Totalcount
			if remainingAttemptCount == 0 {
				responseModel.IsErr = true
				responseModel.Msg = "User blocked, please unblock and try again "
				responseModel.StatusCode = http.StatusInternalServerError
			} else {
				responseModel.IsErr = true
				responseModel.Msg = "Invalid username or password. " + strconv.Itoa(remainingAttemptCount) + " attempts remaining "
				responseModel.StatusCode = http.StatusInternalServerError
			}
			return responseModel
		} else {

			if clientdbData.PasswordFailedCount > 0 || clientdbData.MPINFailedCount > 0 {
				updateData := make(map[string]interface{})
				updateData["password_failed_count"] = 0
				updateData["mpin_failed_count"] = 0
				err := updateJWTAuthMaster(UserType, mobilemodel.UserName, updateData)
				if err != nil {
					Zerologs.Error().Msg("password_failed_count and mpin_failed count not set to zero, update query failed where mobile_no:=  " + mobilemodel.UserName + err.Error())
					responseModel.IsErr = true
					responseModel.Msg = "password_failed_count and mpin_failed count not set to zero, update query failed where mobile_no:=  " + mobilemodel.UserName + err.Error()
					responseModel.StatusCode = http.StatusInternalServerError
					return responseModel
				}
			}
			// Need to Commnent Start [AjayN]
			sAccountcode := clientdbData.ClientID + "-" + "NIT" //Samir Pending
			token, err := GenerateJWTWithRefresh(mobilemodel.Mobileno, clientdbData.Email, sAccountcode)
			if err != nil {
				Zerologs.Error().Msg("Login_Web(): Error in GenerateJWTWithRefresh for mobileno=" + mobilemodel.Mobileno + " and email=" + clientdbData.Email + " is " + err.Error())
				responseModel.IsErr = true
				responseModel.Msg = err.Error()
				responseModel.StatusCode = http.StatusInternalServerError
				return responseModel
			}
			// Need to Commnent End [AjayN]

			if clientdbData.IsPasswordReset {
				if clientdbData.KYCDone {
					if clientdbData.Activated {
						responseModel.IsErr = false
						responseModel.IsActivated = true
						responseModel.IsKyc = true
						responseModel.IsPasswordReset = true
						responseModel.Msg = "Login Success"
						responseModel.StatusCode = http.StatusOK
						// Need to Commnent Start [AjayN]
						responseModel.AccessToken = token.AccessToken
						responseModel.RefreshToken = token.RefreshToken
						responseModel.Url = token.Url
						// Need to Commnent End [AjayN]
						return responseModel

					} else {
						responseModel.IsErr = false
						responseModel.IsActivated = false
						responseModel.IsKyc = true
						responseModel.IsPasswordReset = true
						responseModel.Msg = "Login Success"
						responseModel.StatusCode = http.StatusOK
						return responseModel
					}
				} else {
					Zerologs.Info().Msg("UserName: " + mobilemodel.UserName + "IS LOGIN SUCCESSFULLy AT :=  " + time.Now().Format("2006-01-02 15:04:05"))

					responseModel.IsPasswordReset = true
					responseModel.IsKyc = false
					responseModel.IsActivated = false
					responseModel.Msg = "Login Success"
					responseModel.IsErr = false
					responseModel.StatusCode = http.StatusOK
					return responseModel
				}
			} else {

				responseModel.IsErr = false
				responseModel.Msg = "Show change password screen"
				responseModel.IsPasswordReset = false
				responseModel.StatusCode = http.StatusOK
				return responseModel
			}
		}
	} else {

		responseModel.IsKyc = false
		responseModel.IsActivated = false
		responseModel.IsErr = true
		responseModel.Msg = "User Not Found"
		return responseModel

	}

}
