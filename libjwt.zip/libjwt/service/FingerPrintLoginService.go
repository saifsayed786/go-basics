package service

import (
	"net/http"

	"github.com/MACMREPO/libjwt/helper"
	"github.com/MACMREPO/libjwt/model"
)

func FingerPrintLoginService(mobileno string) model.FingerPrintLoginResponseModel {
	var ResponseModel model.FingerPrintLoginResponseModel
	// var userData clientmaster.JwtAuthMaster
	// err := Db.Client.Where("mobile_no=?", mobileno).First(&userData).Error
	userData, err := getJwtAuthMasterDB(helper.CLIENT_MOBILE_PARAM, mobileno)
	if err != nil {
		Zerologs.Error().Msg("FingerPrint_Login(): User data not found for mobileno=" + mobileno + " and error is " + err.Error())
		ResponseModel.IsErr = true
		ResponseModel.Msg = "User details not available"
		ResponseModel.StatusCode = http.StatusInternalServerError
		return ResponseModel
	}
	token, err := GenerateJWTWithRefresh(userData.MobileNo, userData.Email, "") //Samir Pending
	if err != nil {
		// fmt.Println("GenerateJWTWithRefresh Erro = " + err.Error())
		Zerologs.Error().Msg("FingerPrint_Login(): Error in GenerateJWTWithRefresh for mobileno=" + userData.MobileNo + " and email=" + userData.Email + " is " + err.Error())
		ResponseModel.IsErr = true
		ResponseModel.Msg = err.Error()
		ResponseModel.StatusCode = http.StatusInternalServerError
		return ResponseModel
	}
	// if mobileno == "9673780788" {
	// 	var greenWareReq model.GreenwareRequestModel
	// 	greenWareReq.SsoBy = "mobile+user_type"
	// 	greenWareReq.Param1 = mobileno
	// 	greenWareReq.Param2 = 1
	// 	mfaccesstoken := GreenWareLoginService(greenWareReq)
	// 	if mfaccesstoken != "" {
	// 		Zerologs.Info().Msg("FingerPrint_Login() : User " + mobileno + " successfully login to greenware " + " AT " + time.Now().Format("2006-01-02 15:04:05"))
	// 		token["mftoken"] = mfaccesstoken
	// 	} else {
	// 		token["mftoken"] = mfaccesstoken
	// 	}
	// }
	// var key string
	// if userData.Activated {
	// 	mpinModel := model.HypersyncModel{
	// 		Uid:      userData.ClientID + "-NIT", // + mpinmodel.BrokerID,
	// 		BrokerId: "NIT",                      // mpinmodel.BrokerID, //NIT
	// 		System:   "NIT",                      // mpinmodel.BrokerID, //NIT
	// 	}
	// 	key, err = NewHyperSyncLogin(mpinModel)
	// 	if err != nil {
	// 		// fmt.Println("GenerateJWTWithRefresh Erro = " + err.Error())
	// 		Zerologs.Error().Msg("FingerPrint_Login(): Error in NewHyperSyncLogin() for mobileno=" + userData.MobileNo + " and email=" + userData.Email + " and error is " + err.Error())
	// 		token["hyperSyncAccessToken"] = ""
	// 	}
	// }

	//user verify and redirect to main page.
	ResponseModel.IsErr = false
	ResponseModel.Msg = "Login successfully"
	ResponseModel.StatusCode = http.StatusOK
	ResponseModel.AccessToken = token.AccessToken
	ResponseModel.RefreshToken = token.RefreshToken
	ResponseModel.Url = token.Url
	return ResponseModel
}
