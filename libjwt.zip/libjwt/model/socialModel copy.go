package model

import "github.com/google/uuid"

type SocialModel struct {
	ID       uint      `json:"id"`
	GUID     uuid.UUID `json:"guid"`
	Mobileno string    `json:"Mobileno" binding:"required"`
	Email    string    `json:"Email" binding:"required"`
	Name     string    `json:"Name" binding:"required"`
	Avatar   string    `json:"Avatar" binding:"required"`
	Password string    `json:"Password" binding:"required"`
	Username string    `json:"Username" binding:"required"`
}
