package controller

import (
	"errors"
	"net/http"

	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/model"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/contrib/sessions"
	"github.com/gin-gonic/gin"
)

func VerifyOTPWeb(c *gin.Context) {
	libhttp.CoreHeader(c)
	session := sessions.Default(c)
	retrievedState := session.Get("state")
	if retrievedState == nil {
		service.Zerologs.Info().Msg("VerifyOTPWeb(): RetriveState is Nil")
		c.JSON(http.StatusInternalServerError, errors.New("RetriveState is Nil"))
		return
	}
	cquery := c.Query("state")
	if retrievedState != cquery {
		//Pending
		//c.AbortWithError(http.StatusUnauthorized, fmt.Errorf("Invalid session state: %s", retrievedState))
		//return
	}
	RetriveState := retrievedState.(string)
	var VerifyModel model.OtpVerifyModel
	if err := c.BindJSON(&VerifyModel); err != nil {
		// fmt.Println(err)
		service.Zerologs.Error().Err(err).Msg("VerifyOTP(): error BindJSON " + err.Error())
		c.JSON(http.StatusBadRequest, err)
		return
	}
	response, err := service.VerifyOTPWebService(RetriveState, VerifyModel)
	if err != nil {
		c.JSON(http.StatusInternalServerError, err)
		return
	}
	if response["errMsg"] != "" {
		c.JSON(http.StatusInternalServerError, response)
		return
	}
	c.JSON(http.StatusOK, response)
}
