package controller

import (
	"net/http"

	"github.com/MACMREPO/libhttp"
	"github.com/MACMREPO/libjwt/model"
	"github.com/MACMREPO/libjwt/service"
	"github.com/gin-gonic/gin"
)

func GenerateOTP(c *gin.Context) {
	libhttp.CoreHeader(c)
	var OtpModel model.GenerateOTPModel
	if err := c.BindJSON(&OtpModel); err != nil {
		service.Zerologs.Error().Err(err).Msg("GenerateOTP(): error BindJSON " + err.Error())
		c.JSON(http.StatusBadRequest, err)
		return
	}
	mobileno := OtpModel.MobileNo
	if mobileno == "" {
		service.Zerologs.Error().Msg("GenerateOTP(): Mobile number found empty")
		c.JSON(http.StatusInternalServerError, "Mobile number not found")
		return
	}
	response, err := service.GenerateOTPService(OtpModel, mobileno)
	if err != nil {
		c.JSON(http.StatusInternalServerError, err.Error())
		return
	}
	result, ok := response["errMsg"]
	if ok {
		c.JSON(500, result)
		return
	}
	c.JSON(200, response)

}

func GenerateOTP_NEW(c *gin.Context) {
	libhttp.CoreHeader(c)
	var OtpModel model.GenerateOTPModel
	if err := c.BindJSON(&OtpModel); err != nil {
		service.Zerologs.Error().Err(err).Msg("GenerateOTP(): error BindJSON " + err.Error())
		c.JSON(http.StatusBadRequest, err)
		return
	}
	mobileno := OtpModel.MobileNo
	if mobileno == "" {
		service.Zerologs.Error().Msg("GenerateOTP(): Mobile number found empty")
		c.JSON(http.StatusInternalServerError, "Mobile number not found")
		return
	}
	response, err := service.GenerateOTPService_NEW(OtpModel, mobileno)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"errMsg": err.Error()})
		return
	}
	// if len(response.ErrMsg) != 0 || response.ErrMsg != "" {
	// 	c.JSON(http.StatusInternalServerError, response)
	// 	return
	// }
	c.JSON(http.StatusOK, response)
}
